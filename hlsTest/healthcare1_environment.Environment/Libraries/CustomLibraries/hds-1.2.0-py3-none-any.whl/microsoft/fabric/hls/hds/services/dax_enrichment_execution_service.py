# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------

from microsoft.fabric.hls.hds.dax.data_models.dax_conversations_usecase import DaxConversationsUseCase
from microsoft.fabric.hls.hds.dax.dax_data_enrichment_orchestrator import DaxDataEnrichmentOrchestrator
import json
import os

# from pyspark.sql.utils import AnalysisException
from pyspark.sql import SparkSession, types as T, functions as F

from microsoft.fabric.hls.hds.utils.parameter_service import ParameterService
from microsoft.fabric.hls.hds.utils.utils import FolderPath, Utils
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.telemetry_reporter import TelemetryReporter
from microsoft.fabric.hls.hds.global_constants.global_constants import (
    GlobalConstants as GC,
)
from microsoft.fabric.hls.hds.global_constants.logging_constants import (
    LoggingConstants as LC,
)
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import (
    MSSparkUtilsClientBase,
)
from microsoft.fabric.hls.hds.openai.data_models.openai_model_settings import OpenAIModelSettings
from microsoft.fabric.hls.hds.openai.data_models.openai_connection_config import OpenAIConnectionConfig

telemetry_reporter = TelemetryReporter()


class DaxEnrichmentExecutionService:
    def __init__(
        self,
        spark: SparkSession,
        workspace_name: str,
        solution_name: str,
        admin_lakehouse_name: str,
        inline_params: dict = None,
        one_lake_endpoint: str = GC.DEFAULT_ONE_LAKE_ENDPOINT,
        mssparkutils_client: MSSparkUtilsClientBase | None = None
    ) -> None:       
        
        """
        Initializes the DaxEnrichmentExecutionService.
        Args:
            - spark: spark session
            - workspace_name: Name of the Fabric Workspace
            - solution_name: Name of the HDS-Healthcare data solutions OneLake workload solution
            - admin_lakehouse_name (str): The lakehouse name of where the administration configurations are located
            - inline_params (dict): Inline parameters that will overwrite and take precedence over the parameters in the administration lakehouse configuration
            - one_lake_endpoint (str): The one lake endpoint. Default is `onelake.dfs.fabric.microsoft.com`
            - mssparksutils_client (MSSparkUtilsClientBase): The mssparkutils client
        """
        self.spark = spark
        self.workspace_name = workspace_name
        self.solution_name = solution_name
        self.one_lake_endpoint = one_lake_endpoint
        self.mssparkutils_client = Utils.get_mssparkutils_client(mssparkutils_client)
        
        # Initialize the ParameterService to manage parameters and secrets
        self.parameter_service = ParameterService(
            spark=spark,
            workspace_name=workspace_name,
            admin_lakehouse_name=admin_lakehouse_name,
            one_lake_endpoint=self.one_lake_endpoint,
            mssparkutils_client=self.mssparkutils_client,
            inline_params=inline_params
        )

        # Retrieve the silver lakehouse name from the foundation configuration
        self.source_lakehouse_name = self.parameter_service.get_foundation_config_value(GC.SILVER_LAKEHOUSE_ID_KEY)

        # Retrieve the Key Vault name from the foundation configuration
        self.kv_name = self.parameter_service.get_foundation_config_value(GC.KEYVAULT_NAME_KEY)

        # Set the Key Vault name in the Spark session for further use
        Utils.set_key_vault_name(spark, self.kv_name)

        # Construct the Key Vault URI using the Key Vault name
        self.kv_uri = FolderPath.get_key_vault_uri(self.kv_name)

        try:
            # Retrieve OpenAI configuration settings from Key Vault and Parameter Service
            self.open_ai_config = OpenAIConnectionConfig(
            api_key=self.mssparkutils_client.credentials_getSecret(self.kv_uri, GC.OPENAI_KEY_SECRET_NAME),
            azure_endpoint=self.mssparkutils_client.credentials_getSecret(self.kv_uri, GC.OPENAI_API_ENDPOINT_SECRET_NAME),
            api_version=self.parameter_service.get_activity_config_value(GC.DAX_AZURE_OPENAI_API_VERSION_KEY),
            model_name=self.parameter_service.get_activity_config_value(GC.DAX_AZURE_OPENAI_MODEL_NAME_KEY)
            )
        except Exception as e:
            # Log an error message if there is an issue retrieving the OpenAI configuration
            self._logger.error(f"{LC.DAX_DATA_OPEN_AI_CONFIG_RETRIEVAL_ERR_MSG}: {e}")
            raise
        
        # no record limit by default
        self.record_limit = self.parameter_service.get_activity_config_value(
            GC.DAX_RECORD_LIMIT_KEY,
            GC.DEFAULT_DAX_RECORD_LIMIT,
            "int"
        )

        self.source_table_name = self.parameter_service.get_activity_config_value(
            GC.DAX_SOURCE_TRANSCRIPT_TABLE_NAME_KEY, 
            GC.DEFAULT_DAX_TRANSCRIPT_SILVER_TABLE_NAME
        )

        self.execution_threads = self.parameter_service.get_activity_config_value(
                    GC.DAX_EXECUTION_THREADS_LIMIT_KEY,
                    GC.DEFAULT_DAX_EXECUTION_THREADS,
                    "int"
                )
        
        self.use_case_name = None

        self.open_ai_settings = OpenAIModelSettings()

        self._logger = LoggingHelper.get_dax_conversation_data_enrichment_logger(
            self.spark, self.__class__.__name__, GC.LOGGING_LEVEL
        )

        try:
            self.config_files_root_path = FolderPath.get_fabric_workload_files_root_path(
                workspace_name=self.workspace_name,
                one_lake_endpoint=self.one_lake_endpoint,
                solution_name=self.solution_name,
                )
            
            self.settings_file = self.parameter_service.get_activity_config_value(
                GC.DAX_CONFIG_PATH_KEY,
                f"{self.config_files_root_path}/{GC.DEFAULT_DAX_ENRICHMENT_CONFIG_PATH}"
            )

            self.status_table_name = f"{GC.DEFAULT_DAX_TRANSCRIPT_STATUS_TABLE_NAME}"

            self.source_tables_path = self.parameter_service.get_activity_config_value(
                GC.SOURCE_TABLES_PATH_KEY,
                FolderPath.get_fabric_tables_path(workspace_name=self.workspace_name,
                    one_lake_endpoint=self.one_lake_endpoint,
                    lakehouse_name=self.source_lakehouse_name)
            )

            self.source_table_full_path = (
                f"{self.source_tables_path}/{self.source_table_name}"
            )

            self.status_table_full_path = (
                f"{self.source_tables_path}/{self.status_table_name}"
            )
            
            self.max_retry_count = self.parameter_service.get_activity_config_value(
                GC.DAX_MAX_RETRY_COUNT_KEY, 
                GC.DAX_ENRICHMENT_MAX_RETRY_COUNT,
                "int"
            )

        except Exception as ex:
            self._logger.error(
                f"{LC.DAX_DATA_ENRICHMENT_EXECUTE_SERVICE_ERROR}: {ex}"
            )
            raise

    def execute(self) -> None:
        """
        Execute the data from the source lakehouse,
        processes it using the OpenAI API, and writes the results to the output lakehouse.
        """

        telemetry_reporter.report_usage(
            feature_name=GC.LIBRARY_USAGE_FEATURE_NAME,
            activity_name=GC.DAX_ENRICHMENT_EXECUTION_ACTIVITY_NAME,
        )

        self._logger.info(f"{LC.DAX_ENRICHMENT_EXECUTION_START_INFO_MSG}")

        settings_str = Utils.load_config_file(self.spark, self.settings_file)
        use_case_configs= json.loads(settings_str)

        for use_case in use_case_configs:
            if (
                self.use_case_name
                and use_case[GC.DAX_TRANSCRIPT_CONFIG_CASE_NAME] != self.use_case_name
            ):
                continue
            self._process_use_case(use_case)

        
    def _read_schema_from_file(self, schema_file_path):
        try:
            schema_str = Utils.load_config_file(self.spark, schema_file_path)
            schema_dict = json.loads(schema_str)
            return schema_dict
        except Exception as e:
            self._logger.error(
                f"{LC.DAX_DATA_ENRICHMENT_SCHEMA_FILE_ERROR.format(schema_file_path=schema_file_path)}: {e}"
            )
            raise e

    def _read_and_filter_table(self, use_case):
        """
        Reads the source table and filters it based on the status table and use case.
        Args:
            use_case (dict): A dictionary containing information about the use case.
        Returns:
            DataFrame: A filtered DataFrame based on the use case.
        """
        try:
            progress_df = self.spark.read.format("delta").load(self.status_table_full_path)
            df = self.spark.read.format("delta").load(self.source_table_full_path)
            filter_condition = (
                F.col("status").isNull()
            ) | (
                (F.col("status") != "success") & 
                (F.col("use_case") == use_case["use_case_name"]) &
                (
                    (F.col("retriable") == True) &
                    (F.col("retries_count").cast("int") <= self.max_retry_count)
                )
            )

            df = df.join(progress_df, on=["transcriptId"], how="left").filter(filter_condition)
            df = df.orderBy("createdDatetime", ascending=True)
            return df.limit(self.record_limit) if self.record_limit > 0 else df
        except Exception as e:
            self._logger.info(f"{LC.DAX_DATA_ENRICHMENT_USE_CASE_FILTERING_ERROR.format(use_case_name=use_case['use_case_name'])}-{e}")
            raise e


    def _process_use_case(self, use_case):
        """
        Process a use case.
        Args:
            use_case (dict): A dictionary containing information about the use case.
            Based on the configuration.
        Returns:
            None
        """
        df = self._read_and_filter_table(use_case)
        if df.count() == 0:
            self._logger.info(f"{LC.DAX_DATA_ENRICHMENT_NO_RECORDS_INFO_MSG.format(use_case_name=use_case['use_case_name'])}")
            return
        self._logger.info(f"{LC.DAX_DATA_ENRICHMENT_USE_CASE_START_INFO_MSG.format(use_case_name=use_case['use_case_name'])}")
        dax_enrichment_orchestrator = self._initiate_enrichment_orchestrator(use_case)
        dax_enrichment_orchestrator.execute_enrichment(df)
        
    def _initiate_enrichment_orchestrator(self, use_case):
        schema_file_path = os.path.join(
            os.path.dirname(self.settings_file), f'{use_case["table_schema"]}'
        )
        
        table_schema = self._read_schema_from_file(schema_file_path)
        model_config = use_case.get("openai_model", {}).get("configuration", {})
  
        case_open_ai_config = OpenAIConnectionConfig(
            azure_endpoint=model_config.get(
                "azure_endpoint", self.open_ai_config.azure_endpoint
            ),
            api_key=model_config.get("api_key", self.open_ai_config.api_key),
            api_version=model_config.get(
                "api_version", self.open_ai_config.api_version
            ),
            model_name=model_config.get("model_name", self.open_ai_config.model_name),
        )
        openai_model = use_case.get("openai_model", {})
        use_case_settings= DaxConversationsUseCase(
            use_case_name=use_case.get("use_case_name"),
            open_ai_config=case_open_ai_config,
            system_message=openai_model.get("system_message"),
            examples=openai_model.get("examples"),
            response_format=table_schema
        )
        dax_enrichment_orchestrator=DaxDataEnrichmentOrchestrator(
            self.spark,use_case_settings,self.mssparkutils_client,
            execution_threads=self.execution_threads
        )
        return dax_enrichment_orchestrator

