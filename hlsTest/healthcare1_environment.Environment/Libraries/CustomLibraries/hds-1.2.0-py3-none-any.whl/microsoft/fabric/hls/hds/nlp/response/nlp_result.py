# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from datetime import datetime


@dataclass
class NLPResult:
    """
    Represents the NLP result structure for a single document returned by the Text Analytics for Health API.

    Attributes:
        id (str): The document ID.
        is_error (bool): Indicates if the result is an error.
        error (Optional[Dict[str, Any]]): The error information if is_error is True, otherwise None.
        warnings (Optional[List[Dict[str, Any]]]): A list of warning information, or None if no warnings.
        entities (Optional[List[Dict[str, Any]]]): A list of entity information, or None if no entities.
        entity_relations (Optional[List[Dict[str, Any]]]): A list of entity relation information, or None if no entity relations.
        statistics (Optional[Dict[str, Any]]): The result statistics, or None if not available.
        nlp_last_executed (datetime): The timestamp when the NLP result was last executed.
        fhir_bundle (Optional[str]): The FHIR bundle in JSON format saved as string, or None if not available.
    """
    id: str  # pylint: disable=invalid-name
    is_error: bool
    error: Optional[Dict[str, Any]] = None
    warnings: Optional[List[Dict[str, Any]]] = None
    entities: Optional[List[Dict[str, Any]]] = None
    entity_relations: Optional[List[Dict[str, Any]]] = None
    statistics: Optional[Dict[str, Any]] = None
    nlp_last_executed: datetime = field(default_factory=datetime.now)
    fhir_bundle: Optional[str] = None
