# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
from microsoft.fabric.hls.hds.openai.data_models.openai_response_status import OpenAIResponseStatus


class DaxConversationsEnrichmentData:
    def __init__(self, **kwargs):
        """
        Initialize a DaxConversationsEnrichmentData instance.

        Args:
            params (dict): Dictionary containing the parameters.
                - transcript_id (str): ID of the transcript.
                - patient_id (str): ID of the patient.
                - encounter_id (str): ID of the encounter.
                - practitioner_name (str): Name of the practitioner.
                - model_name (str): Name of the model.
                - model_version (str): Version of the model.
                - use_case_name (str): Name of the use case.
                - status (str): Status of the enrichment.
                - value (str): Result of the conversation enrichment.
        """
        self.transcript_id = kwargs.get('transcript_id')
        self.patient_id = kwargs.get('patient_id')
        self.encounter_id = kwargs.get('encounter_id')
        self.practitioner_name = kwargs.get('practitioner_name')
        self.model_name = kwargs.get('model_name')
        self.model_version = kwargs.get('model_version')
        self.use_case_name = kwargs.get('use_case_name')
        self.status = kwargs.get('status')
        self.value = kwargs.get('value')
        

    def to_dict(self):
        """
        Convert the DaxConversationsEnrichmentData instance to a dictionary.

        Returns:
            dict: A dictionary representation of the instance.
        """  
        return {  
            'transcriptId': self.transcript_id,  
            'patientId': self.patient_id,  
            'encounterId': self.encounter_id,
            'practitionerName': self.practitioner_name,
            'model_name': self.model_name,  
            'model_version': self.model_version,  
            'use_case_name': self.use_case_name,  
            'status': self.status.to_dict() if self.status else None,  
            'value': self.value
        }
