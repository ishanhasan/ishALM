# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------

import json, uuid
from microsoft.fabric.hls.hds.sdoh.generate_dtt_configurations.generate_dtt_mapping import DTTMappingGenerator
from microsoft.fabric.hls.hds.sdoh.generate_dtt_configurations.sdoh_datatables_mapping import SDOHdataTablesMapping
from microsoft.fabric.hls.hds.sdoh.generate_dtt_configurations.sdoh_metadatatables_mapping import SDOHMetaDataTablesMapping
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.sdoh.bronze_ingestion.constants import SdohConstants
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.utils.utils import Utils as PlatformCommonUtil

class DTTAdapterConfigurationGenerator:
    """
    A class used to process tables in a Spark database.

    ...

    Attributes
    ----------
    spark : SparkSession
        a SparkSession object to interact with the Spark cluster
    bronze_database_name : str
        the name of the database to process
    sdoh_config_file_path   
        Location of all the sdoh configuration files
    sdoh_table_prefix : str
        the prefix of the tables to process
    target_strings : list
        a list of target strings
    arrSDOHsourceToTargetMapping : list
        a list of mappings from source to target
    adapterContent : str
        a string of adapter content
    exclude_tables : list
        a list of tables to exclude from processing
    df_2 : DataFrame
        a DataFrame of the SdohLayout table
    tables : list
        a list of tables in the database
    processed_tables : list
        a list of tables to process
    json_structure : list
        a list to store the JSON structure
    json_array_dtt : list
        a list to store the DTT mapping

    Methods
    -------
    process_tables():
        Processes all the tables in the database that have the given prefix.
    process_table(df_1, table):
        Processes a single table.
    generate_queries(matching_array, location_array, lowest_unit, table):
        Generates SQL queries for a table.
    generate_dtt_metadata_mapping():
        Generates DTT mapping for a sdoh metadata tables.
    finalize():
        Completes the processing of DTT adapter configuration for all the sdoh tables and modifies the adapter content.
    """
    
    def __init__(self, 
                 spark, 
                 source_lakehouse_name, 
                 target_lakehouse_name, 
                 bronze_database_name,
                 sdoh_config_file_path,
                 adapterContent,
                 business_events_ingestion_service):
        
        self.spark = spark
        self._logger = LoggingHelper.get_sdoh_silveringestion_logger(
            self.spark, self.__class__.__name__, GlobalConstants.LOGGING_LEVEL
        )
        self.source_lakehouse_name=source_lakehouse_name,
        self.target_lakehouse_name=target_lakehouse_name,
        self.bronze_database_name = bronze_database_name
        self.sdoh_config_file_path = sdoh_config_file_path
        self.sdoh_table_prefix = SdohConstants.SD_PREFIX
        self.adapterContent = adapterContent
        self.exclude_tables = ['SdohLayout', 'SdohDataSetMetadata']
        self.exclude_tables = [table.lower() for table in self.exclude_tables]
        self.df_2 = self.spark.sql(f"SELECT * FROM SdohLayout")
        self.df_meta_data = spark.sql("SELECT * FROM SdohDataSetMetadata")
        self.tables = self.spark.sql(f"SHOW TABLES IN `{self.bronze_database_name}`").collect()
        self.processed_tables = [table for table in self.tables if self.sdoh_table_prefix.lower() in table.tableName.lower()]
        self.processed_tables.sort(key=lambda x: x[0])
        self.json_structure=[]
        self.json_array_dtt = []
        self.business_events_ingestion_service= business_events_ingestion_service

   # Processes all the tables in the database that have the given prefix.
    def process_tables(self):
        # Generate DTT metadata mapping
        self.json_array_dtt = self.generate_dtt_metadata_mapping()
        tables_with_datasetid=self.filter_tables_with_column("DataSetMetadataId")
        # Process each table
        for table in tables_with_datasetid:
            # Skip excluded tables
            if table.tableName.lower() in self.exclude_tables:
                continue
            
            # Retrieve table data
            self._logger.info(LC.SDOH_TABLES_PROCESSING.format(
                        table_name=table.tableName)) 
            df_1 = self.spark.sql(f"SELECT * FROM {table.tableName}")
            # Process the table
            self.process_table(df_1, table)
            self._logger.info(LC.SDOH_TABLES_PROCESSING_COMPLETED.format(
                        table_name=table.tableName)) 
            

    #Processes a single table.
    def process_table(self, df_1, table):
        location_columns=[]
        column_named_struct_parts = []
        link_to_socialdeterminant = None
        link_to_socialdeterminant_type = None

        # Get the columns of df_1 and the SocialDeterminantName column from df_2
        df_1_columns_set = set(df_1.columns)
        df_2_variable_codes_set = set(self.df_2.select("SocialDeterminantName").rdd.flatMap(lambda x: x).collect())
        
        # Find the common columns between df_1 and df_2
        matching_array = list(df_1_columns_set & df_2_variable_codes_set)
        dataset_id= df_1.select("DataSetMetaDataId").first()[0]
        if dataset_id:
            df_filtered_meta_data = self.df_meta_data.filter(self.df_meta_data.DataSetMetadataId == dataset_id)
            configurations=df_filtered_meta_data.select("LocationConfiguration").first()[0]
            if configurations:
                config = json.loads(configurations)
                for column in config:
                    if column[SdohConstants.LOC_CONFIG_COLUMN_NAME] in df_1_columns_set:
                        location_columns.append(f"{column[SdohConstants.LOC_CONFIG_COLUMN_NAME]}")
                        column_named_struct_parts.append(f"'{column[SdohConstants.LOC_CONFIG_STANDARD_COLUMN_NAME]}', {column[SdohConstants.LOC_CONFIG_COLUMN_NAME]}")
                # Find the columns in df_1 that are also in the target_strings list
                lowercase_target_strings = set(target.lower() for target in location_columns)
                location_array = list(lowercase_target_strings)
                location_array.sort()
                for c in config:
                    if c[SdohConstants.LOC_CONFIG_ASSOCIATED_WITH_SDOH_VALUE] and c[SdohConstants.LOC_CONFIG_COLUMN_NAME] in df_1_columns_set:
                        link_to_socialdeterminant = c[SdohConstants.LOC_CONFIG_COLUMN_NAME]
                        link_to_socialdeterminant_type = c[SdohConstants.LOC_CONFIG_STANDARD_COLUMN_NAME]
                        break  # Pick the first encountered one
                # Generate queries using the matching_array, location_array, lowest_unit, and table
                self.generate_queries(matching_array, location_array, link_to_socialdeterminant, table,link_to_socialdeterminant_type,column_named_struct_parts)\
            
            else:
                message = LC.SDOH_TABLES_LOCATION_CONFIGURATION_NOT_FOUND.format(table_name=table.tableName)
                self._logger.error(message)
                
                new_row = self.business_events_ingestion_service.create_new_business_event_row(id=str(uuid.uuid4()), activityName=GlobalConstants.SDOH_SILVER_INGESTION_ACTIVITY_NOTEBOOK, 
                    targetLakehouseName= self.target_lakehouse_name, targetTableName=SdohConstants.TABLE_SOCIAL_DETERMINANT,
                    sourceTableName=table.tableName, sourceLakehouseName= self.source_lakehouse_name, severity= GlobalConstants.ERROR, 
                    eventType= GlobalConstants.SDOH_PROCESS_TABLES_FROM_BRONZE_TO_SILVER, message= message, active=True)
                self.business_events_ingestion_service.insert_business_events([new_row])
                
                
        else:
            self._logger.error(LC.SDOH_TABLES_DATASETMETADATAID_NOT_FOUND.format(
                        table_name=table.tableName))
            
            new_row = self.business_events_ingestion_service.create_new_business_event_row(id=str(uuid.uuid4()), activityName=GlobalConstants.SDOH_SILVER_INGESTION_ACTIVITY_NOTEBOOK, 
                targetLakehouseName= self.target_lakehouse_name, targetTableName=SdohConstants.TABLE_SOCIAL_DETERMINANT,
                sourceLakehouseName= self.source_lakehouse_name, severity= GlobalConstants.ERROR, 
                eventType= GlobalConstants.SDOH_PROCESS_TABLES_FROM_BRONZE_TO_SILVER, message= message, active=True)
            self.business_events_ingestion_service.insert_business_events([new_row])

    #Generates DTT mapping for a sdoh metadata tables.
    def generate_dtt_metadata_mapping(self):
        self._logger.info(LC.SDOH_TABLES_METADATA_DTT_MAPPING_PROCESSING)
        # Create an instance of SDOHMetaDataTablesMapping with the SDOH config file path
        sdoh_metadata_mapping = SDOHMetaDataTablesMapping(self.spark,f"{self.sdoh_config_file_path}/{GlobalConstants.SDOH_META_DATA_TABLES_MAPPING}")

        # Get the SDOH metadata mapping
        arr_sdoh_metadata = sdoh_metadata_mapping.get_mapping()

        # Define SQL queries for different metadata tables
        queries = {
            'SdohDataSetMetadata': f"SELECT DatasetName as Dataset_Name, PublisherName as Publisher_Name, PublishedDate as Published_Date, ValidUntil as Valid_Until, {GlobalConstants.DEFAULT_BRONZE_CREATED_DATE_COL} as modifiedon, DataSetMetaDataId as Target_PK from SdohDataSetMetadata",
            'SdohLayout_UOM': f"SELECT DISTINCT units, {GlobalConstants.DEFAULT_BRONZE_CREATED_DATE_COL} as modifiedon, units as Target_PK FROM SdohLayout",
            'SdohLayout_Category': f"SELECT Category as Social_Determinant_Category_Name, Category as Target_PK, {GlobalConstants.DEFAULT_BRONZE_CREATED_DATE_COL} as modifiedon FROM SdohLayout",
            'SdohLayout_SubCategory': f"SELECT SubCategory as Sub_Category, concat_ws('',SubCategory, Category) as Target_PK, Category as Social_Determinant_Category_Id, {GlobalConstants.DEFAULT_BRONZE_CREATED_DATE_COL} as modifiedon FROM SdohLayout"
        }

        # Create an instance of DTTMappingGenerator with the SDOH metadata and queries
        generate_dtt_mapping = DTTMappingGenerator(arr_sdoh_metadata, queries)
        
        self._logger.info(LC.SDOH_TABLES_METADATA_DTT_MAPPING_PROCESSED)

        # Generate the DTT mapping and convert it to a list before returning
        return list(generate_dtt_mapping.generate_dtt_mapping())

    #Generates SQL queries for a table.
    def generate_queries(self, matching_array, location_array, link_to_socialdeterminant, table,link_to_socialdeterminant_type,location_named_struct_parts):
        # Get SDOH data tables mapping
        self._logger.info(LC.SDOH_TABLES_DATA_DTT_MAPPING_PROCESSING)
        sdoh_mapping = SDOHdataTablesMapping(self.spark, f"{self.sdoh_config_file_path}/{GlobalConstants.SDOH_DATA_TABLES_MAPPING}")
        arr_sdoh_data = sdoh_mapping.get_mapping()

        location_column_names_str = ", ".join(location_array)
        named_struct_str = ", ".join(location_named_struct_parts)
        sdoh_queries = dict()
        
        # Generate social determinant SQL query
        sql_query_social_determinant = f"SELECT s1.location_json as Location_JSON_String,s1.location_value as Location_Value,'{link_to_socialdeterminant_type}' as Location_type,concat_ws('',s1.row_id,s1.SocialDeterminantCode,m.DataSetMetadataId) as Social_Determinant_Id,m.DataSetMetadataId as DataSet_Metadata_Id, l.SocialDeterminantDescription as Social_Determinant_Description, s1.SocialDeterminantCode as Social_Determinant_Name, s1.SocialDeterminantValue as Social_Determinant_Value, concat_ws('',l.SubCategory, l.Category) as Social_Determinant_SubCategory_Id,l.Units as Unit_Of_Measure,l.HarmonizationKey as Harmonization_Key, s1.ModifiedOn as modifiedon FROM Sdohlayout l INNER JOIN (SELECT s.SocialDeterminantCode, s.SocialDeterminantValue, s.ModifiedOn,concat({location_column_names_str}) as row_id, LocationType,s.location_json,s.location_value FROM (SELECT {location_column_names_str},to_json(named_struct({named_struct_str})) as location_json,{GlobalConstants.DEFAULT_BRONZE_CREATED_DATE_COL} as ModifiedOn,{link_to_socialdeterminant} as location_value, STACK({len(matching_array)}, " + ", ".join([f"{column} , '{column}'" for column in matching_array]) + f") AS (SocialDeterminantValue, SocialDeterminantCode) FROM {table.tableName}) s LATERAL VIEW explode(array({link_to_socialdeterminant})) exploded_table AS LocationType )s1 ON l.SocialDeterminantName = s1.SocialDeterminantCode Inner join SdohDataSetMetadata m on l.DataSetMetadataId=m.DataSetMetadataId"
        sdoh_queries['SocialDeterminant'] = sql_query_social_determinant
        
        # Generate DTT mapping
        mapping_generator = DTTMappingGenerator(arr_sdoh_data, sdoh_queries, table.tableName)
        json_array_sdoh = mapping_generator.generate_dtt_mapping()
        self.json_array_dtt.extend(json_array_sdoh)
        self._logger.info(LC.SDOH_TABLES_DATA_DTT_MAPPING_PROCESSED)

    #Completes the processing of DTT adapter configuration for all the sdoh tables and modifies the adapter content.
    def finalize(self):
        # Process the tables
        self.process_tables()

        # Convert the JSON array to a string with indentation for readability
        json_output = json.dumps(self.json_array_dtt, indent=4)

        # Replace 'null' in the adapter content with the JSON output
        # This assumes that 'null' is a placeholder for the JSON output in the adapter content
        self.adapterContent = self.adapterContent.replace('null', json_output)

        # Return the updated adapter content
        return self.adapterContent
    
    def has_column(self,table_name, col_name):
        """
        Check if a specified column exists in a given table.

        Args:
            table_name (str): The name of the table to check.
            col_name (str): The name of the column to look for.

        Returns:
            bool: True if the column exists in the table, False otherwise.
        """
        df = self.spark.table(table_name)
        normalized_columns = [col.strip().lower() for col in df.columns]
        return col_name.strip().lower() in normalized_columns
 
    def filter_tables_with_column(self,column_name):
        """
        Filters the processed tables to find those that contain a specific column.

        Args:
            column_name (str): The name of the column to search for in the tables.

        Returns:
            list: A list of tables that contain the specified column. If no tables are found, returns an empty list.
        """
        tables_with_column = [table for table in self.processed_tables if self.has_column(f"`{self.bronze_database_name}`.{table.tableName}", column_name)]
        return tables_with_column if tables_with_column else []