 # -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# -------------------------------------------------------------------------
import base64
from collections import namedtuple
import json
import os
from typing import List
import numpy as np
from pyspark.sql import SparkSession
from microsoft.fabric.hls.hds.ai_enrichments.core.clients.client_retry_management.retry_client_manager import RetryClientManager
from microsoft.fabric.hls.hds.ai_enrichments.core.clients.med_image_client_orchestrator import MedImageClientOrchestrator
from microsoft.fabric.hls.hds.ai_enrichments.core.clients.models.enrichment_api_response import EnrichmentAPIResponse
from microsoft.fabric.hls.hds.ai_enrichments.core.errors.model_processor_error import ModelProcessError
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_context import EnrichmentContext
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_response import EnrichmentResponse
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.constants.enrichment_use_case_logging_constants import EnrichmentUseCaseLoggingConstants as ELC
from microsoft.fabric.hls.hds.utils.data_manager_logger import DataManagerLogger
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import MSSparkUtilsClientBase

ImageAnalysisData = namedtuple('ImageAnalysisData', ['metadata', 'rle', 'height', 'width'])

class EnrichmentModelUtils:
      
    def save_model_raw_response(mssparkutils_client:MSSparkUtilsClientBase,enrichment_generation_id: str, enrichment_response: EnrichmentResponse, output_path: str, file_format: str = "json") -> None:
        """
        Writes the raw json output to a file.

        Args:
            enrichment_generation_id (str): Unique identifier for the enrichment generation.
            enrichment_response (EnrichmentResponse): EnrichmentResponse object containing the analysis result.
            output_path (str): Path where the JSON output will be saved.
            file_format (str): The type of the file to be saved (e.g., 'json'). Defaults to 'json'.
        """
        try:
            final_output_path = os.path.join(output_path, f"raw_{enrichment_generation_id}_{enrichment_response.id}.{file_format}")
            mssparkutils_client.fs_mkdirs(os.path.dirname(final_output_path))
            raw_content_string = json.dumps(enrichment_response.content, indent=4)
            mssparkutils_client.fs_put(final_output_path, raw_content_string, overwrite=True)
        except Exception as err:
            raise ModelProcessError(f"{ELC.AI_ENRICHMENT_RAW_ENRICHMENT_SAVE_ERROR}: {err}")
        
        
    def initialize_med_image_client(spark:SparkSession,model_config: dict,logger:DataManagerLogger) -> None:
        """
        Initializes the MedImage client.

        Args:
            model_config (dict): Configuration for the MedImageInsights model.
        """
        api_endpoint = model_config.get('api_endpoint',None)
        api_key = model_config.get('api_key',None)
        system_instructions = model_config.get('system_instructions',None)
        
        med_image_client = MedImageClientOrchestrator(spark=spark,api_endpoint=api_endpoint,api_key=api_key,
                                          system_instructions=system_instructions,logger=logger)
        
        return med_image_client
    
    
    def extract_content_from_documents(document_inputs: List[EnrichmentContext]) -> List[str]:
        """
        Extracts the file content from each document's references.
        """
        return [
            image_file.content
            for enrichment_context in document_inputs
            for image_file in enrichment_context.enrichment_input.image_file_references
        ]
        
        
    def analyze_images(client_manager:RetryClientManager, file_path_list: List[str]) -> List[dict]:
        """
        Calls the configured MedImageInsight model to process images and returns
        the model responses.
        
        Args:
        file_path_list (List[str]): A list of image file paths to be processed by the model.

        Returns:
            List[dict]: A list of dictionaries containing the model responses for each image.
        """       
        results = []

        execute_analyze = client_manager.execute_client()
        
        for file_path in file_path_list:
            results.append(execute_analyze(file_path=file_path))

        return results
    
    def format_analysis_results(
        mssparkutils_client:MSSparkUtilsClientBase,
        enrichment_generation_id: str,
        document_inputs: List[EnrichmentContext],
        start_index: int,
        results: List[EnrichmentAPIResponse],
        should_save_raw_response: bool,
        raw_response_output_path: str
    ) -> List[EnrichmentResponse]:
        """
        Converts raw model responses into EnrichmentResponse objects and
        saves them if required.
        """
        formatted_responses = []
        for i, result in enumerate(results):
            if not result is None and result.is_completed:
                response_data=result.data
                enrichment_response = EnrichmentResponse(
                    id=document_inputs[start_index + i].enrichment_input.image_file_references[0].id,
                    content=response_data
                )
                if should_save_raw_response:
                    EnrichmentModelUtils.save_model_raw_response(
                        mssparkutils_client,
                        enrichment_generation_id,
                        enrichment_response,
                        raw_response_output_path
                    )
                formatted_responses.append(enrichment_response)   
        return formatted_responses
    
    
    def mask_to_rle(flattened_mask):
        """
        Convert a flattened mask to Run-Length Encoding (RLE).
        
        Args:
            flattened_mask (list or numpy array): Flattened binary mask (1s and 0s).
        
        Returns:
            list: RLE encoded mask.
        """
        rle = []
        try:
            last_val = 0
            run_start = -1

            for i, val in enumerate(flattened_mask):
                if val == 1 and last_val == 0:
                    run_start = i
                elif val == 0 and last_val == 1:
                    rle.extend([run_start, i - run_start])
                last_val = val

            if last_val == 1:
                rle.extend([run_start, len(flattened_mask) - run_start])
        except Exception as e:
            print(f"Error in mask_to_rle: {e}")   
        return rle
        

    def retrieve_image_analysis_data(entity: dict) -> List[ImageAnalysisData] | None:
        """
        Retrieve image analysis data from the given entity.

        Args:
            entity (dict): The entity containing image features and metadata.

        Returns:
            ImageAnalysisData | None: The image analysis data or None if data is missing.
        """
        image_features_metadata = json.loads(entity.get("image_features", "{}"))
        shape = image_features_metadata.get("shape", [])
        dtype = image_features_metadata.get("dtype", "float32")
        base64_data = image_features_metadata.get("data", "")
        text_features = entity.get("text_features", [])
        
        if not (shape and base64_data):
            return None
      
        height, width = (shape[1], shape[2]) if len(shape) > 2 else (0, 0)
        shaped_array = np.frombuffer(base64.b64decode(base64_data), dtype=dtype).reshape(shape)
        image_analysis_data = []
        for i,mask in enumerate(shaped_array):
            metadata = {
                "text_feature": text_features[i]
            }
            rle=EnrichmentModelUtils.mask_to_rle(mask.flatten())
            image_analysis_data.append(ImageAnalysisData(metadata=metadata, rle=rle, height=height, width=width))
        
        return image_analysis_data


