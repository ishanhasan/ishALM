from typing import Any, Dict, List, Optional, get_type_hints
from pyspark.sql import SparkSession
from concurrent.futures import ThreadPoolExecutor, as_completed
from microsoft.fabric.hls.hds.ai_enrichments.core.errors.model_transformer_error import ModelTransformerError
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.terminology import Terminology
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.conversational.models.conversational_enrichment_result import ConversationalEnrichmentResult
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_context import EnrichmentContext
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_output import EnrichmentOutput
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_response import EnrichmentResponse
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_result import EnrichmentResult
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.types.text_output import TextOutput
from microsoft.fabric.hls.hds.ai_enrichments.core.utils.ai_enrichments_utils import AIEnrichmentsUtils
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import MSSparkUtilsClientBase
from microsoft.fabric.hls.hds.utils.utils import Utils
from microsoft.fabric.hls.hds.ai_enrichments.core.constants.ai_enrichments_constants import AIEnrichmentsConstants as EC
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.constants.enrichment_use_case_constants import EnrichmentUseCaseConstants as EUC
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.constants.enrichment_use_case_logging_constants import EnrichmentUseCaseLoggingConstants as ELC

class ConversationalDataTransformer:
    """
    Transforms conversational enrichment data by mapping raw AI responses
    to structured enrichment objects.
    """

    def __init__(self, spark: SparkSession, mssparkutils_client: Optional[MSSparkUtilsClientBase] = None) -> None:
        """
        Initializes the transformer with Spark session and an optional MSSparkUtils client.

        Args:
            spark (SparkSession): The SparkSession instance.
            mssparkutils_client (Optional[MSSparkUtilsClientBase]): An optional MSSparkUtils client.
        """
        self.spark = spark
        self.mssparkutils_client = Utils.get_mssparkutils_client(mssparkutils_client)
        self._logger = LoggingHelper.get_ai_enrichment_conversationaldata_execution__logger(
            self.spark,
            self.__class__.__name__,
            GC.LOGGING_LEVEL
        )

    def transform(
        self,
        enrichment_generation_id: str,
        enrichment_contexts: List[EnrichmentContext],
        raw_response_data: List[EnrichmentResponse]
    ) -> List[EnrichmentResult]:
        """
        Transforms raw enrichment responses into EnrichmentResult objects using a thread pool.

        Args:
            enrichment_generation_id (str): A unique identifier for this enrichment run.
            enrichment_contexts (List[EnrichmentContext]): A list of enrichment contexts.
            raw_response_data (List[EnrichmentResponse]): A list of raw AI responses.

        Returns:
            List[EnrichmentResult]: Structured enrichment results.
        """
        try:
            self._logger.info(ELC.AI_ENRICHMENT_TRANSFORMATION_RECORDS_INFO.format(records_count=len(raw_response_data)))
            context_map = {
                c.enrichment_input.text_file_references[0].id: c
                for c in enrichment_contexts
                if c.enrichment_input and c.enrichment_input.text_file_references
            }

            def parse_response(response: EnrichmentResponse) -> Optional[EnrichmentResult]:
                ctx = context_map.get(response.id)
                if not ctx:
                    return None
                ref = ctx.enrichment_input.text_file_references[0]
                ref.content = AIEnrichmentsUtils.get_base64_encoded_string(ref.content)
                outputs: List[EnrichmentOutput] = []
                self._perform_data_transformation(response.content, outputs)
                return EnrichmentResult(
                        context=ctx,
                        outputs=outputs,
                        enrichment_generation_id=enrichment_generation_id
                    )

            results = []
            with ThreadPoolExecutor(max_workers=EUC.DEFAULT_AI_ENRICHMENT_EXECUTION_THREADS) as executor:
                future_to_response = {executor.submit(parse_response, response): response for response in raw_response_data}
                for future in as_completed(future_to_response):
                    try:
                        result = future.result()
                        if result:
                            results.append(result)
                    except Exception as e:
                        self._logger.error(EC.ENRICHMENT_UNEXPECTED_ERROR.format(method="transform", error=e))
            return results
        except Exception as e:
            raise ModelTransformerError(EC.ENRICHMENT_UNEXPECTED_ERROR.format(method="transform", error=e)) from e

    def _perform_data_transformation(self, item: Dict[str, Any], outputs: List[EnrichmentOutput]) -> None:
        """
        Iterates over the enrichment data and appends text outputs to the list.

        Args:
            item (Dict[str, Any]): A dictionary containing enrichment data.
            outputs (List[EnrichmentOutput]): A list to store resulting outputs.
        """
        for entity in (x for x in item.get(EUC.CONVERSATIONAL_DATA_OUTPUT_KEY, []) if x and x.get('value')):
            outputs.append(
                EnrichmentOutput(
                    type='text',
                    value=self._create_text_output(entity),
                    confidence_score=entity.get('confidence_score'),
                    description=''
                )
            )

    def _create_text_output(self, entity: Dict[str, Any]) -> TextOutput:
        """
        Creates a TextOutput object using the provided entity data.

        Args:
            entity (Dict[str, Any]): A dictionary representing an enrichment entity.

        Returns:
            TextOutput: A text-based enrichment output.
        """
        keys = list(get_type_hints(ConversationalEnrichmentResult).keys())
        terminology = self._get_terminology(entity)
        return TextOutput(**{k: entity.get(k, '') for k in keys}, terminology=terminology)

    def _get_terminology(self, entity: Dict[str, Any]) -> Optional[list[Terminology]]:
        """
        Retrieves the terminology for the given entity based on the use case configuration.

        Args:
            entity (Dict[str, Any]): A dictionary representing an enrichment entity.

        Returns:
            Optional[Terminology]: The terminology object if found, otherwise None.
        """
        use_case_config = EUC.CONVERSATIONAL_DATA_ENRICHMENT_USE_CASES.get(entity.get('domain'))
        if not use_case_config:
            return []

        terminology_config = use_case_config.get("terminology")
        if not terminology_config:
            return []

        code_value = terminology_config.get("code_mappings", {}).get(entity.get('value'), EUC.UNSPECIFIED_MAPPING)
        return [Terminology(
            system=terminology_config.get("system"),
            name=terminology_config.get("name"),
            value=code_value
        )]

