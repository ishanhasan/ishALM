# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
from dataclasses import dataclass, field
from microsoft.fabric.hls.hds.openai.constants import OpenAIConstants

@dataclass
class OpenAIModelSettings:
    """
    Class representing the settings for OpenAI Model API Settings.
    """
    temperature: float = OpenAIConstants.DEFAULT_TEMPERATURE  # Temperature setting for the model
    top_p: float = OpenAIConstants.DEFAULT_TOP_P  # Top-p (nucleus sampling) setting for the model
    frequency_penalty: float = OpenAIConstants.DEFAULT_FREQUENCY_PENALTY  # Frequency penalty setting for the model
    presence_penalty: float = OpenAIConstants.DEFAULT_PRESENCE_PENALTY  # Presence penalty setting for the model
    stop: str = OpenAIConstants.DEFAULT_STOP  # Stop sequence setting for the model
    stream: bool = OpenAIConstants.DEFAULT_STREAM  # Stream setting for the model
    response_format: dict = field(default_factory=lambda: {})  # Response format setting for the model, defaulting to an empty dictionary
