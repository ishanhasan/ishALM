# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------

from concurrent.futures import ThreadPoolExecutor
import json
import os
from pyspark.sql import SparkSession, Row
from pyspark.sql.functions import *
from microsoft.fabric.hls.hds.openai.data_models.openai_connection_config import OpenAIConnectionConfig
from microsoft.fabric.hls.hds.openai.data_models.openai_model_response import OpenAIModelResponse
from microsoft.fabric.hls.hds.openai.data_models.openai_model_settings import OpenAIModelSettings
from microsoft.fabric.hls.hds.openai.openai_client_orchestrator import OpenAIOrchestrator
from microsoft.fabric.hls.hds.dax.data_models.dax_conversations_enrichmentdata import DaxConversationsEnrichmentData
from microsoft.fabric.hls.hds.dax.data_models.dax_conversations_metadata import DaxConversationsMetadata
from microsoft.fabric.hls.hds.dax.data_models.dax_conversations_usecase import DaxConversationsUseCase
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import MSSparkUtilsClientBase

class DaxDataEnrichmentOrchestrator:
    """
    DaxDataEnrichmentOrchestrator class represents executing logic for DAX Conversations enrichment with LLM models.
    """
   
    def __init__(self, spark: SparkSession, use_case_settings: DaxConversationsUseCase, mssparkutils_client: MSSparkUtilsClientBase,execution_threads:int,**kwargs):
        """
        Initializes the DaxDataEnrichmentOrchestrator.

        Args:
            spark (SparkSession): The Spark session.
            use_case_settings (DaxConversationsUseCase): The use case specific settings.
            mssparkutils_client (MSSparkUtilsClientBase): The MSSparkUtils client.
            **kwargs: Additional arguments.
        """
        self.open_ai_settings = kwargs.get("open_ai_settings", OpenAIModelSettings())
        self.spark = spark
        self.use_case_settings = use_case_settings
        self.mssparkutils_client = mssparkutils_client
        self.execution_threads = execution_threads
        self._logger = LoggingHelper.get_dax_conversation_data_enrichment_logger(self.spark, self.__class__.__name__, GC.LOGGING_LEVEL)
        self.open_ai_client_orchestrator = self._create_open_ai_client_orchestrator(use_case_settings)

    def execute_enrichment(self, conversations_df: DataFrame):
        """
        Executes the enrichment process for the given DataFrame.

        Args:
            conversations_df (DataFrame): The DataFrame to enrich.
        """
        try:
            if not self.open_ai_client_orchestrator.validate_openai_connection_config():
                self._logger.error(LC.DAX_DATA_OPEN_AI_CONFIG_ERROR.format(use_case_name=self.use_case_settings.use_case_name))
                return
            if not self.open_ai_client_orchestrator.validate_api_key():
                self._logger.error(LC.DAX_DATA_OPEN_AI_KEY_ERROR.format(use_case_name=self.use_case_settings.use_case_name))
                return
            conversations_records = conversations_df.collect()
            self._logger.info(LC.DAX_DATA_ENRICHMENT_EXECUTION_INFO_MSG.format(records_count=len(conversations_records)))
            self._enrich_data(conversations_records)
        except Exception as e:
            self._logger.error(f"{LC.DAX_DATA_ENRICHMENT_USE_CASE_EXECUTION_ERROR.format(use_case=self.use_case_settings.use_case_name)}-{e}")
            
    def _create_open_ai_client_orchestrator(self, use_case_settings: DaxConversationsUseCase) -> OpenAIOrchestrator:
        """
        Creates an instance of the OpenAI client Manager.

        Args:
            use_case_settings (DaxConversationsUseCase): The Use Case Settings.

        Returns:
            OpenAIOrchestrator: The OpenAI client orchestrator instance.
        """
        return OpenAIOrchestrator(self.spark, 
                                  open_ai_conn_config=use_case_settings.open_ai_config, 
                                  openai_settings= self.open_ai_settings,
                                  system_message=use_case_settings.system_message,
                                  examples=use_case_settings.examples)
                
    def _enrich_data(self, conversations_records: list[Row]):
        """
        Analyzes the input data using the OpenAI client and saves the analyzed data.

        Args:
            conversations_records (list[Row]): The metadata of the DAX Conversation.
        """
        try:
            with ThreadPoolExecutor(max_workers=self.execution_threads) as executor:
                conversation_results = [
                    executor.submit(self._execute_enrichment_with_llm, row)
                    for row in conversations_records
                    if row['content'] and row['content'].strip() != ""
                ]
                for output_result in conversation_results:
                    output_result.result()
        except Exception as e:
            self._logger.error(f"{LC.DAX_DATA_ENRICHMENT_USE_CASE_PROCESS_ERROR.format(use_case=self.use_case_settings.use_case_name)}-{e}")

    def _execute_enrichment_with_llm(self, record: Row):
        """
        Analyzes the input data using the OpenAI client and saves the analyzed data.

        Args:
            record (Row): The metadata of the DAX Conversation.
        """
        try:
            retries_count=int(record["retries_count"] or 0)
            dax_conversations_metadata = DaxConversationsMetadata(
                transcript_id=record["transcriptId"],
                conversation=record["content"],
                patient_id=record["patientId"],
                encounter_id = record["encounterId"],
                practitioner_name = record["practitionerName"],
                target_path=self._get_enrichment_path(record["transcriptId"], record["full_file_path"],retries_count),
            )
            response_content = self.open_ai_client_orchestrator.get_completion_json(
                user_query=dax_conversations_metadata.conversation, 
                schema_format=self.use_case_settings.response_format,
                retry_count= retries_count
            )
            
            self._logger.info(LC.DAX_DATA_ENRICHMENT_MSG_COMPLETED.format(recording_id=dax_conversations_metadata.transcript_id))
            self._save_enrichments_as_file(dax_conversations_metadata, response_content)
        except Exception as e:
           self._logger.error(f"{LC.DAX_DATA_ENRICHMENT_RECORD_PROCESS_ERROR.format(recording_id=record['transcriptId'])}-{e}")  
 
    def _save_enrichments_as_file(self, dax_conversations_metadata: DaxConversationsMetadata, model_response: OpenAIModelResponse):  
        """  
        Saves content to a JSON file in the specified directory with the given recording ID.  

        Args:
            dax_conversations_metadata (DaxConversationsMetadata): Metadata to save.
            model_response (OpenAIModelResponse): The response from the OpenAI client.
        """ 
        dax_conversation_enriched_data = DaxConversationsEnrichmentData(
            transcript_id=dax_conversations_metadata.transcript_id,
            patient_id=dax_conversations_metadata.patient_id, 
            encounter_id=dax_conversations_metadata.encounter_id,
            practitioner_name=dax_conversations_metadata.practitioner_name,
            model_name=self.use_case_settings.open_ai_config.model_name,
            model_version=self.use_case_settings.open_ai_config.api_version,
            status=model_response.status,
            use_case_name=self.use_case_settings.use_case_name,
            value=model_response.response,
        )  
        try:
            filepath = dax_conversations_metadata.target_path
            self._save_as_json_file(filepath, dax_conversation_enriched_data)
            self._logger.info(LC.DAX_DATA_ENRICHMENT_EXECUTION_COMPLETED_MSG.format(recording_id=dax_conversations_metadata.transcript_id, file_path=filepath))
        except Exception as e:
            self._logger.error(f"{LC.DAX_DATA_ENRICHMENT_RECORD_SAVE_ERROR}: {e}")

    def _get_enrichment_path(self, transcript_id: str, full_file_path: str,retries_count:int) -> str:  
        """  
        Gets the enrichment path.  

        Args:  
            transcript_id (str): The transcript ID.  
            full_file_path (str): The full file path. 
            retries_count (int): The number of retries.  
        Returns:  
            str: The enrichment path.  
        """  
        folder_path = os.path.join(  
            os.path.dirname(full_file_path),  
            GC.DAX_ENRICHMENT_RESOURCE_TYPE,  
        )  
        return os.path.join(  
            folder_path,  
            f'{self.use_case_settings.use_case_name}-{transcript_id}-{retries_count}.json',  
        )
    
    def _save_as_json_file(self, file_path: str, dax_enrichment_data: DaxConversationsEnrichmentData) -> None:
        """
        Save the object as a JSON string to a specified file.

        Args:
            file_path (str): The path of the file where the JSON data will be saved.
            dax_enrichment_data (DaxConversationsEnrichmentData): The enrichment data to save.
        """
        try:
            # we shouldn't write the json as multiline for the spark read to work
            json_data = json.dumps(dax_enrichment_data.to_dict(), separators=(',', ':'))
            # for local execution
            self.mssparkutils_client.fs_mkdirs(os.path.dirname(file_path))
            self.mssparkutils_client.fs_put(file_path, json_data, overwrite=True)
        except Exception as e:
            self._logger.error(f"{LC.DAX_DATA_ENRICHMENT_SAVE_ERROR_MSG.format(recording_id=dax_enrichment_data.transcript_id, file_path=file_path)}-{e}")
