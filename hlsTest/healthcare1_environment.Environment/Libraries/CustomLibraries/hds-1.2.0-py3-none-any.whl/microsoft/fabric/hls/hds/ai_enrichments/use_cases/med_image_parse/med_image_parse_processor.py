import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Optional
from pyspark.sql import SparkSession
from microsoft.fabric.hls.hds.ai_enrichments.core.clients.client_retry_management.retry_client_manager import RetryClientManager
from microsoft.fabric.hls.hds.ai_enrichments.core.errors.enrichment_api_response_error import EnrichmentAPIResponseError
from microsoft.fabric.hls.hds.ai_enrichments.core.errors.model_processor_error import ModelProcessError
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_context import EnrichmentContext
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_response import EnrichmentResponse
from microsoft.fabric.hls.hds.ai_enrichments.core.base_classes.enrichment_model_processor_base import EnrichmentModelProcessorBase
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import MSSparkUtilsClientBase
from microsoft.fabric.hls.hds.ai_enrichments.core.constants.ai_enrichments_constants import AIEnrichmentsConstants as EC
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.constants.enrichment_use_case_constants import EnrichmentUseCaseConstants as EUC
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.utils.enrichment_model_utils import EnrichmentModelUtils as ModelUtils
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.constants.enrichment_use_case_logging_constants import EnrichmentUseCaseLoggingConstants as ELC

class MedImageParseProcessor(EnrichmentModelProcessorBase):
    """
    Handles segmentation of healthcare images using the MedImageParse model.
    """

    def __init__(
        self,
        spark: SparkSession,
        mssparkutils_client: Optional[MSSparkUtilsClientBase] = None
    ):
        """
        Initialize the MedImageParseProcessor.

        Args:
            spark (SparkSession): Active Spark session.
            mssparkutils_client (MSSparkUtilsClientBase, optional): Spark utilities client.
        """
        super().__init__(mssparkutils_client)
        self.spark = spark
        self.client_manager = None
        self._logger = LoggingHelper.get_ai_enrichment_mip_execution__logger(
            self.spark,
            self.__class__.__name__,
            GC.LOGGING_LEVEL
        )

    def process(
        self,
        enrichment_generation_id: str, model_config:dict, 
        document_inputs: List[EnrichmentContext],
        should_save_raw_response: bool,
        output_path: str
    ) -> List[EnrichmentResponse]:
        """
        Segment input healthcare images and optionally save raw outputs.

        Args:
            enrichment_generation_id (str): Unique identifier for the enrichment run.
            model_config (dict): Model configuration dictionary.
            document_inputs (List[EnrichmentContext]): List of image references.
            should_save_raw_response (bool): Flag to save raw response if True.
            output_path (str): Target folder path for JSON outputs.

        Returns:
            List[EnrichmentResponse]: Contains segmentation results.
        """
        try:
            enrichment_responses = []
            self.model_config = model_config
            self._initialize_med_image_parse_client(self.model_config)
            raw_response_path = os.path.join(output_path, EC.ENRICHMENT_LANDING_ZONE_RAW_RESPONSE_PATH)
 
            with ThreadPoolExecutor(max_workers=EC.DEFAULT_AI_ENRICHMENT_MII_EXECUTION_THREADS) as executor:
                futures = [
                    executor.submit(
                        self._process_documents_batch,
                        enrichment_generation_id,
                        document_inputs,
                        i,
                        should_save_raw_response,
                        raw_response_path
                    )
                    for i in range(0, len(document_inputs), EUC.DEFAULT_AI_ENRICHMENT_EXECUTION_BATCH_SIZE)
                ]
                for future in as_completed(futures):
                   if future.exception() is None:
                        result= future.result()
                        if result is not None:
                            enrichment_responses.extend(future.result())
                   else:
                       exception_message=future.exception()
                       api_response_error = EnrichmentAPIResponseError(f"{ELC.AI_ENRICHMENT_ENRICHMENT_MODEL_EXECUTION_ERROR}: { type(exception_message).__name__}:{exception_message} ")
                       self._logger.error(api_response_error) 

            return enrichment_responses

        except Exception as ex:
            raise ModelProcessError(str(ex)) from ex

    def _initialize_med_image_parse_client(self, model_config: dict) -> None:
        """
        Create and store a managed MedImageParse client instance.

        Args:
            model_config (dict): Configuration for the MedImagesParse model.
        """
        med_image_client = ModelUtils.initialize_med_image_client(self.spark, model_config, self._logger)
        self.client_manager = RetryClientManager(med_image_client)

    def _process_documents_batch(
        self,
        enrichment_generation_id: str,
        document_inputs: List[EnrichmentContext],
        start_index: int,
        should_save_raw_response: bool,
        raw_response_output_path: str
    ) -> List[EnrichmentResponse]:
        """
        Process a subset of documents in a batch, extracting and analyzing images.

        Args:
            enrichment_generation_id (str): Identifier for the current run.
            document_inputs (List[EnrichmentContext]): Full list of documents.
            start_index (int): Starting index of the batch within the document list.
            should_save_raw_response (bool): Flag to save the raw response.
            raw_response_output_path (str): Destination path for the raw response files.

        Returns:
            List[EnrichmentResponse]: Processed enrichment results.
        """
        document_batch = document_inputs[
            start_index : start_index + EUC.DEFAULT_AI_ENRICHMENT_EXECUTION_BATCH_SIZE
        ]
        file_path_contents = ModelUtils.extract_content_from_documents(document_batch)
        
        results = ModelUtils.analyze_images(self.client_manager, file_path_contents)
        
        self._logger.info(f"{ELC.AI_ENRICHMENT_MODEL_PROCESS_COMPLETED_BATCH_INFO.format(start_index=start_index, end_index=start_index + len(document_batch))}")
        
        return ModelUtils.format_analysis_results(
            self.mssparkutils_client,
            enrichment_generation_id,
            document_inputs,
            start_index,
            results,
            should_save_raw_response,
            raw_response_output_path
        )
