"""
AI Enrichment package initializer.

This module initializes the ai_enrichment package by importing
all necessary classes,and services.
"""

# Consolidated data model imports
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.metadata import (
    EnrichmentView,
    Enrichment,
    EnrichmentViewDefinition,
    EnrichmentViewExpression,
    EnrichmentDefinition,
    EnrichmentInputMapping,
    EnrichmentFileReference
)

# Core service imports for AI-based enrichment:
from microsoft.fabric.hls.hds.ai_enrichments.core.services import (
    AIEnrichmentsService
)

# Use case imports for specialized transformations:
from microsoft.fabric.hls.hds.ai_enrichments.use_cases import (
    TA4HModelProcessor,
    TA4HTransformer,
    ConversationalDataTransformer,
    ConversationalDataModelProcessor,
    MedImageInsightTransformer,
    MedImageInsightProcessor,
    MedImageParseTransformer,
    MedImageParseProcessor
)

__all__ = [
    'EnrichmentView',
    'Enrichment',
    'EnrichmentViewDefinition',
    'EnrichmentViewExpression',
    'EnrichmentDefinition',
    'EnrichmentInputMapping',
    'EnrichmentFileReference',
    'AIEnrichmentsService',
    'TA4HModelProcessor',
    'TA4HTransformer',
    'ConversationalDataTransformer',
    'ConversationalDataModelProcessor',
    'MedImageInsightTransformer',
    'MedImageInsightProcessor',
    'MedImageParseTransformer',
    'MedImageParseProcessor'
]
