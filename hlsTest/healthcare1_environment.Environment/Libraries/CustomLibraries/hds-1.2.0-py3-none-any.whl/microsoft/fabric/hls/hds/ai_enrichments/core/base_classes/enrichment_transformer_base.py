from typing import Any, Dict, List
from abc import ABC, abstractmethod
from microsoft.fabric.hls.hds.ai_enrichments.core.constants.ai_enrichments_logging_constants import AIEnrichmentsLoggingConstants as LC
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_context import EnrichmentContext
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_result import EnrichmentResult

# Abstract base class for enrichment transformers
class EnrichmentTransformerBase(ABC):
    
    @abstractmethod
    def transform(self, enrichment_generation_id: str, enrichment_contexts: List[EnrichmentContext], raw_response_data: List[Dict[str, Any]]) -> List[EnrichmentResult]:
        """
        Transform the given input data to an output JSON schema.

        Args:
            enrichment_generation_id (str): The generation ID of the enrichment process.
            enrichment_contexts (List[EnrichmentContext]): The enrichment inputs.
            raw_response_data (List[Dict[str, Any]]): The data to be transformed to the JSON schema.

        Returns:
            List[EnrichmentResult]: The transformed data in the form of a list of EnrichmentResult objects.
        """
        # Raise an error if the method is not implemented in the subclass
        raise NotImplementedError(LC.AI_ENRICHMENT_MODEL_EXECUTION_IMPLEMENTATION_ERROR)
       
