# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
class NLPDataLoadError(Exception):
    """Exception raised for errors when loading data from a specified path.

    This exception is raised when there is a failure during the data loading process,
    such as incorrect file paths, unsupported file formats, or issues encountered
    while reading the data.

    Attributes:
        message (str): explanation of the error
    """

    def __init__(self, message="NLP data load failed."):
        self.message = message
        super().__init__(self.message)