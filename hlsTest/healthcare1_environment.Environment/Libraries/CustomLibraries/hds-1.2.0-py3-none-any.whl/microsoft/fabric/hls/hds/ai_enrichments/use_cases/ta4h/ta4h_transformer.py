# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# -------------------------------------------------------------------------
import json
import os
from typing import Any, Dict, List
from pyspark.sql import SparkSession
from concurrent.futures import ThreadPoolExecutor
from microsoft.fabric.hls.hds.ai_enrichments.core.errors.model_transformer_error import ModelTransformerError
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_context import EnrichmentContext
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_output import EnrichmentOutput
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_response import EnrichmentResponse
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_result import EnrichmentResult
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.evidence import Evidence
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.evidence_metadata import EvidenceMetadata
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.evidence_region import EvidenceRegion
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.terminology import Terminology
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.text_span import TextSpan
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.types.object_output import ObjectOutput
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.types.text_output import TextOutput
from microsoft.fabric.hls.hds.ai_enrichments.core.utils.ai_enrichments_utils import AIEnrichmentsUtils
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import MSSparkUtilsClientBase
from microsoft.fabric.hls.hds.utils.utils import Utils
from microsoft.fabric.hls.hds.ai_enrichments.core.constants.ai_enrichments_constants import AIEnrichmentsConstants as EC
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.constants.enrichment_use_case_constants import EnrichmentUseCaseConstants as EUC
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.constants.enrichment_use_case_logging_constants import EnrichmentUseCaseLoggingConstants as ELC

class TA4HTransformer:
    """
    TA4HTransformer is responsible for transforming raw response data into enriched results
    based on provided model and enrichment definitions.
    """

    def __init__(self, spark: SparkSession, mssparkutils_client: MSSparkUtilsClientBase = None) -> None:
        """
        Initializes the TA4HTransformer with an optional MSSparkUtilsClientBase client.

        Args:
            spark (SparkSession): The Spark session.
            mssparkutils_client (MSSparkUtilsClientBase, optional): An instance of MSSparkUtilsClientBase.
        """
        self.spark = spark
        self.mssparkutils_client = Utils.get_mssparkutils_client(mssparkutils_client)
        self._logger = LoggingHelper.get_ai_enrichment_ta4h_execution__logger(
            self.spark, self.__class__.__name__, GC.LOGGING_LEVEL
        )

    def transform(self, enrichment_generation_id: str, enrichment_contexts: List[EnrichmentContext], raw_response_data: List[EnrichmentResponse]) -> List[EnrichmentResult]:
        """
        Transforms raw response data into enriched results based on the provided model and enrichment definitions.

        Args:
            enrichment_generation_id (str): The ID of the enrichment generation.
            enrichment_contexts (List[EnrichmentContext]): The input definitions for the enrichment process.
            raw_response_data (List[EnrichmentResponse]): The raw response data to be transformed.

        Returns:
            List[EnrichmentResult]: The result of the enrichment process.
        """
        try:
            self._logger.info(ELC.AI_ENRICHMENT_TRANSFORMATION_RECORDS_INFO.format(records_count=len(raw_response_data)))
            def parse_response(response: EnrichmentResponse) -> EnrichmentResult:
                """
                Parse a single raw response into an EnrichmentResult.

                Args:
                    response (EnrichmentResponse): The raw response data.

                Returns:
                    EnrichmentResult: The transformed enrichment result.
                """
                enrichment_context = next((x for x in enrichment_contexts if x.enrichment_input.text_file_references[0].id == response.id), None)
                if enrichment_context:
                    enrichment_context.enrichment_input.text_file_references[0].content = AIEnrichmentsUtils.get_base64_encoded_string(
                        enrichment_context.enrichment_input.text_file_references[0].content
                    )
                    outputs = []
                    self._transform_result(response.content, outputs)
                    return EnrichmentResult(
                        context=enrichment_context,
                        outputs=outputs,
                        enrichment_generation_id=enrichment_generation_id
                    )
                return None

            with ThreadPoolExecutor(max_workers=EUC.DEFAULT_AI_ENRICHMENT_EXECUTION_THREADS) as executor:
                results = list(executor.map(parse_response, raw_response_data))
            return [result for result in results if result is not None]
        except Exception as e:
            raise ModelTransformerError(EC.ENRICHMENT_UNEXPECTED_ERROR.format(method="transform", error=e)) from e

    def _transform_result(self, item: Dict[str, Any], outputs: List[EnrichmentOutput]) -> None:
        """
        Transforms a single item from the raw response data into enrichment outputs.

        Args:
            item (Dict[str, Any]): The item from the raw response data to be transformed.
            outputs (List[EnrichmentOutput]): The list to which the transformed outputs will be appended.
        """
        try:
            self._transform_entities_and_relations(item, outputs)
        except Exception as e:
            self._logger.error(EC.ENRICHMENT_UNEXPECTED_ERROR.format(method="_transform_result", error=e))

    def _transform_entities_and_relations(self, item: Dict[str, Any], outputs: List[EnrichmentOutput]) -> None:
        """
        Transforms entities and relations from the raw response data into enrichment outputs.

        Args:
            item (Dict[str, Any]): The item from the raw response data containing entities and relations.
            outputs (List[EnrichmentOutput]): The list to which the transformed outputs will be appended.
        """
        # Transform entities
        for entity in item.get('entities', []):
            text_output = self._create_text_output(entity)
            output_schema = EnrichmentOutput(
                type='text',
                value=text_output,
                confidence_score=entity.get('confidence_score'),
                description=""
            )
            outputs.append(output_schema)

        # Transform relations
        for relation in item.get('relations', []):
            object_output = self._create_object_output(relation)
            output_schema = EnrichmentOutput(
                type='object',
                value=object_output
            )
            outputs.append(output_schema)

    def _create_text_output(self, entity: Dict[str, Any]) -> TextOutput:
        """
        Creates a TextOutput object from an entity dictionary.

        Args:
            entity (Dict[str, Any]): The entity dictionary containing information about the entity.

        Returns:
            TextOutput: The created TextOutput object.
        """
        # Extract data sources from the entity
        data_sources = entity.get("data_sources", [])

        # Create a list of Terminology objects from the data sources
        terminology = [
            Terminology(name=source["name"], value=source["entity_id"], system="")
            for source in data_sources
        ]

        # Create an Evidence object with text span information
        evidence = Evidence(
            type="text_span",
            evidence=EvidenceMetadata(
                document_id="",
                evidence_region=EvidenceRegion(
                    text_span=TextSpan(
                        start_position=entity.get('offset'),
                        end_position=entity.get('offset') + entity.get('length')
                    )
                )
            )
        )

        # Return the created TextOutput object
        return TextOutput(
            value=entity.get('text'),
            domain=entity.get('category'),
            reasoning="",
            evidence=[evidence],
            terminology=terminology
        )

    def _create_object_output(self, relation: Dict[str, Any]) -> ObjectOutput:
        """
        Creates an ObjectOutput object from a relation dictionary.

        Args:
            relation (Dict[str, Any]): The relation dictionary containing information about the relation.

        Returns:
            ObjectOutput: The created ObjectOutput object.
        """
        return ObjectOutput(
            type=relation.get('relation_type'),
            value=relation.get('roles'),
            reasoning="",
            evidence=[],
            terminology=[]
        )
