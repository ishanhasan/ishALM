# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# -------------------------------------------------------------------------

from typing import List
from pydantic import BaseModel

from microsoft.fabric.hls.hds.ai_enrichments.use_cases.conversational.models.conversational_enrichment_result import ConversationalEnrichmentResult

class ConversationalEnrichmentOutput(BaseModel):
    """
    Collects multiple enrichment results in a single place.
    Each instance includes:
      - enrichmentResult: a list of individual enrichment items
    """
    enrichmentResult: List[ConversationalEnrichmentResult]