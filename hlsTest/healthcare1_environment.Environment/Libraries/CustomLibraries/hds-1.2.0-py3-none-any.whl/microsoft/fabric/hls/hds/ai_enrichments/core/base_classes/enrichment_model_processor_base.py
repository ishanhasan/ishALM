from abc import ABC, abstractmethod
from typing import List
from microsoft.fabric.hls.hds.ai_enrichments.core.constants.ai_enrichments_logging_constants import AIEnrichmentsLoggingConstants as LC
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_context import EnrichmentContext
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_response import EnrichmentResponse
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import MSSparkUtilsClientBase
from microsoft.fabric.hls.hds.utils.utils import Utils

class EnrichmentModelProcessorBase(ABC):
    """
    Abstract base class for executing enrichment models.
    This class should be inherited by any class that implements a specific model execution.
    """
    
    def __init__(self,mssparkutils_client: MSSparkUtilsClientBase = None):
        """
        Initializes the EnrichmentModelProcessorBase.
            mssparkutils_client (MSSparkUtilsClientBase, optional): Spark utils client. Defaults to None.
        """
        self.mssparkutils_client = Utils.get_mssparkutils_client(mssparkutils_client)
        
    @abstractmethod
    def process(
        self, 
        enrichment_generation_id: str, model_config:dict,
        input_records: List[EnrichmentContext], 
        should_save_raw_response: bool, 
        output_path: str
    ) -> List[EnrichmentResponse]:
        """
        Process the enrichment with model configuration and list of input records.

        Args:
            enrichment_generation_id (str): Unique identifier for the enrichment generation process.
            model_config (dict): Configuration for the model.
            input_records (List[EnrichmentContext]): Inputs containing references to files.
            should_save_raw_response (bool): Flag indicating whether to save the raw response.
            output_path (str): Path to save the output.

        Returns:
            List[EnrichmentResponse]: List of responses after model execution.
        """
        raise NotImplementedError(LC.AI_ENRICHMENT_MODEL_EXECUTION_IMPLEMENTATION_ERROR)
