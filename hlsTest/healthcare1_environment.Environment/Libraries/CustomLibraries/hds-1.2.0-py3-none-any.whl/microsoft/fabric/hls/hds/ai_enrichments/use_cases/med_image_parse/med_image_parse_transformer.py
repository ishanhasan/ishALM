from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional
from pyspark.sql import SparkSession
from microsoft.fabric.hls.hds.ai_enrichments.core.errors.model_transformer_error import ModelTransformerError
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_context import EnrichmentContext
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_response import EnrichmentResponse
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_result import EnrichmentResult, EnrichmentOutput
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.types.segmentation.segmentation_mask import SegmentationMask
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.types.segmentation_2d_output import Segmentation2DOutput
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.utils import Utils
from microsoft.fabric.hls.hds.ai_enrichments.core.constants.ai_enrichments_constants import AIEnrichmentsConstants as EC
from microsoft.fabric.hls.hds.ai_enrichments.core.constants.ai_enrichments_logging_constants import AIEnrichmentsLoggingConstants as ELC
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC
from typing import Dict, Any
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.utils.enrichment_model_utils import EnrichmentModelUtils as ModelUtils

class MedImageParseTransformer:
    """
    MedImageParseTransformer is responsible for transforming raw response data into enriched results
    based on the MedImageParse model and enrichment definitions.
    """

    def __init__(self, spark: SparkSession, mssparkutils_client: Optional[Any] = None) -> None:
        """
        Initializes the transformer with Spark session and an optional MSSparkUtils client.

        Args:
            spark (SparkSession): The SparkSession instance.
            mssparkutils_client (Optional[Any]): An optional MSSparkUtils client.
        """
        self.spark = spark
        self.mssparkutils_client = Utils.get_mssparkutils_client(mssparkutils_client)
        self._logger = LoggingHelper.get_ai_enrichment_mip_execution__logger(
            self.spark, self.__class__.__name__, GC.LOGGING_LEVEL
        )

    def transform(
        self,
        enrichment_generation_id: str,
        enrichment_inputs: List[EnrichmentContext],
        raw_response_data: List[Dict[str, Any]]
    ) -> List[EnrichmentResult]:
        """
        Transforms raw enrichment responses into EnrichmentResult objects using a thread pool.

        Args:
            enrichment_generation_id (str): A unique identifier for this enrichment run.
            enrichment_inputs (List[EnrichmentContext]): A list of enrichment contexts.
            raw_response_data (List[Dict[str, Any]]): A list of raw AI responses.

        Returns:
            List[EnrichmentResult]: Structured enrichment results.
        """
        try:
            context_map = {
                c.enrichment_input.image_file_references[0].id: c
                for c in enrichment_inputs
                if c.enrichment_input and c.enrichment_input.image_file_references
            }

            def parse_response(response: EnrichmentResponse) -> Optional[EnrichmentResult]:
                ctx = context_map.get(response.id)
                if not ctx:
                    self._logger.warning(f"Context not found for response id: {response.id}")
                    return None
                outputs: List[EnrichmentOutput] = []
                self._transform_result(response.content, outputs)
                return EnrichmentResult(
                    context=ctx,
                    outputs=outputs,
                    enrichment_generation_id=enrichment_generation_id
                )

            results = []
            with ThreadPoolExecutor(max_workers=EC.DEFAULT_AI_ENRICHMENT_EXECUTION_THREADS) as executor:
                future_to_response = {executor.submit(parse_response, response): response for response in raw_response_data}
                for future in as_completed(future_to_response):
                    try:
                        result = future.result()
                        if result:
                            results.append(result)
                    except Exception as e:
                        self._logger.error(EC.ENRICHMENT_UNEXPECTED_ERROR.format(method="transform", error=e))
                        raise e
            return results
        except Exception as e:
            raise ModelTransformerError(EC.ENRICHMENT_UNEXPECTED_ERROR.format(method="transform", error=e)) from e

    def _transform_result(self, item: Dict[str, Any], outputs: List[EnrichmentOutput]) -> None:
        """
        Transforms a single response item into domain-specific outputs.

        Args:
            item (Dict[str, Any]): The raw response content.
            outputs (List[EnrichmentOutput]): A list to store resulting outputs.
        """
        try:
            self._transform_segmentation_response(item, outputs)
        except Exception as e:
            self._logger.error(EC.ENRICHMENT_UNEXPECTED_ERROR.format(method="_transform_result", error=e))

    def _transform_segmentation_response(self, item: Dict[str, Any], outputs: List[EnrichmentOutput]) -> None:
        """
        Iterates over the enrichment data and appends segmentation outputs to the list.

        Args:
            item (Dict[str, Any]): A dictionary containing enrichment data.
            outputs (List[EnrichmentOutput]): A list to store resulting outputs.
        """
        if isinstance(item, list):
            for entity in item:
                if isinstance(entity, dict):
                    for output in self._create_segmentation_outputs(entity):
                        outputs.append(EnrichmentOutput(type="segmentation_2d", value=output))
        else:
            self._logger.warning(ELC.MED_IMAGE_INSIGHT_OUTPUT_RESPONSE_WARNING.format(response=item))

    def _create_segmentation_outputs(self, entity: Dict[str, Any]) -> List[Segmentation2DOutput]:
        """
        Returns a List of Segmentation2DOutput by decoding base64-data into a NumPy array,
        then creating a 2D mask and flattening it.

        Args:
            entity (Dict[str, Any]): The raw model result.

        Returns:
            Segmentation2DOutput: The segmentation output.
        """
        image_meta_data_list = ModelUtils.retrieve_image_analysis_data(entity)
        return [
            Segmentation2DOutput(
                segmentation_mask=SegmentationMask(
                    rle=image_meta_data.rle
                ),
                height=image_meta_data.height,
                width=image_meta_data.width,
                metadata=image_meta_data.metadata
            )
            for image_meta_data in image_meta_data_list
        ]
        