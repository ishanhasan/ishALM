from typing import Any
from abc import ABC, abstractmethod
from microsoft.fabric.hls.hds.utils.data_manager_logger import DataManagerLogger
from microsoft.fabric.hls.hds.ai_enrichments.core.constants.ai_enrichments_logging_constants import AIEnrichmentsLoggingConstants as LC

class EnrichmentModelClientBase(ABC):
    """
    Abstract base client for making API calls for enrichment models.
    This class provides a template for creating clients that interact with
    enrichment model APIs, handling common setup tasks such as logging and
    header generation.
    """

    def __init__(self, api_endpoint: str, api_key: str, logger: DataManagerLogger, **kwargs):
        """
        Initialize the ClientBase with endpoint, key, and logger.

        Args:
            api_endpoint (str): The API endpoint URL.
            api_key (str): The authentication key.
            logger (DataManagerLogger): A DataManagerLogger instance for logging.
            kwargs: Additional attributes to set on the client.

        """
        self.api_endpoint = api_endpoint
        self.api_key = api_key
        self._logger = logger
        
        # Dynamically add extra attributes
        for k, v in kwargs.items():
            setattr(self, k, v)
            
        self._logger.info(f"{LC.AI_ENRICHMENT_CLIENT_ORCHESTRATOR_INIT_INFO.format(Type=self.__class__.__name__)}")
        self.create(**kwargs)

    def create(self, **kwargs) -> Any:
        """
        Abstract method to create or configure the client before submission.
        This method optional to be implemented by subclasses to perform additional setup.

        Args:
            kwargs: Additional attributes to set on the client.
        """
        pass

    @abstractmethod
    def execute(self, method: str = "POST", **kwargs) -> Any:
        """
        Abstract method to execute the request to the API.

        Args:
            method (str): The HTTP method to use for the request (default is "POST").
            kwargs: Additional parameters to include in the request.
        """
        raise NotImplementedError()

    def _get_headers(self) -> dict:
        """
        Generate default headers for API calls.

        Returns:
            dict: A dictionary containing the default headers.
        """
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
