# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
class NLPDataSaveError(Exception):
    """
    Exception raised for errors when saving data to a specified path.

    This exception is raised when there is a failure during the data saving process,
    such as incorrect file paths, unsupported file formats, or issues encountered
    while writing the data.

    Attributes:
        message (str): explanation of the error
    """

    def __init__(self, message="NLP results data save failed."):
        self.message = message
        super().__init__(self.message)