# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
"""
Module with a class containing validation steps for bronze ingestion
"""
import os
import pandas
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.sdoh.bronze_ingestion.constants import SdohConstants
from microsoft.fabric.hls.hds.sdoh.bronze_ingestion.utils import SdohUtils 
from microsoft.fabric.hls.hds.utils.business_events_ingestion_handler import BusinessEventsIngestion
from microsoft.fabric.hls.hds.sdoh.bronze_ingestion.validator import Validator
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import MSSparkUtilsClientBase
from microsoft.fabric.hls.hds.utils.data_manager_logger import DataManagerLogger
from delta import DeltaTable
from pathlib import Path, PosixPath
import uuid

class CoreProcess:

    def __init__(self,
                 spark: SparkSession,
                 source_lakehouse_name: str,
                 target_lakehouse_name: str,
                 bronze_tables_path: str,
                 sdoh_failed_folder_path: str,
                 business_events_ingestion_service: BusinessEventsIngestion,
                 logger: DataManagerLogger,
                 mssparkutils_client: MSSparkUtilsClientBase,
                 collect_source_and_target_metrics_fn) -> None:
        """
        Class to process the SDOH files.

        Args:
            - spark: Spark session
            - bronze_tables_path: Path for the bronze target tables
            - logger: Logger instance
            - mssparkutils_client: MSSpark client instance or test instance
        """
        self.spark: SparkSession = spark
        self.source_lakehouse_name = source_lakehouse_name
        self.target_lakehouse_name = target_lakehouse_name
        self.bronze_tables_path = bronze_tables_path
        self.sdoh_failed_folder_path = sdoh_failed_folder_path
        self.mssparkutils_client = mssparkutils_client
        self._logger = logger
        self.bronze_validator = Validator()
        self.utils = SdohUtils()
        self.business_events_ingestion_service = business_events_ingestion_service
        self._collect_source_and_target_metrics_fn = collect_source_and_target_metrics_fn
        self.exceptions = list()
        self.ingest_exception_excel = None
        self.ingest_exception_csv = None

    def ingest_excel(self, df, list_processed_files) -> bool:
        """
        Ingests an Excel file into the system.

        Args:
        - df_excel_file: The Excel file as a pandas DataFrame.
        - list_processed_files (list): List of processed files.

        Returns:
            bool: True if all files sucessfully ingested, False otherwise.
        """
        bool_excel_ingested = True
        for row in df.collect():
            try:
                rowPath = Path(row.path)
                datasetName = rowPath.parent.name
                file_name = os.path.basename(row.path)
                self._logger.info(f"{LC.DATASET_INGESTION_START.format(dataset_name=datasetName)}")
                try:
                    df_excel_file = pandas.ExcelFile(bytes(row.content))
                except Exception as ex:
                    message = f"{LC.EXCEL_READ_FAILURE.format(file_path=row.path,error_message=str(ex))}"
                    self._logger.error(message)
                    new_row = self.business_events_ingestion_service.create_new_business_event_row(id=str(uuid.uuid4()), activityName=GlobalConstants.SDOH_BRONZE_INGESTION_ACTIVITY_NOTEBOOK, 
                        targetFilePath= self.bronze_tables_path, targetLakehouseName= self.target_lakehouse_name, targetTableName=GlobalConstants.SDOH_NA,
                        sourceFilePath= rowPath, sourceLakehouseName= self.source_lakehouse_name, severity= GlobalConstants.ERROR, 
                        eventType= GlobalConstants.SDOH_READ_EXCEL_FILE_FROM_PATH, message= message, exception= str(ex), active=True)
                    self.ingest_exception_excel = new_row
                    raise Exception(message)

                # Validate the excel dataframe
                validationError = self.bronze_validator.validate_excel_dataset(df_excel_file, row.path)
                if validationError is not None:
                    new_row = self.business_events_ingestion_service.create_new_business_event_row(id=str(uuid.uuid4()), activityName=GlobalConstants.SDOH_BRONZE_INGESTION_ACTIVITY_NOTEBOOK, 
                        targetFilePath= self.bronze_tables_path, targetLakehouseName= self.target_lakehouse_name, targetTableName=GlobalConstants.SDOH_NA,
                        sourceFilePath= rowPath, sourceLakehouseName= self.source_lakehouse_name, severity= GlobalConstants.ERROR, 
                        eventType= GlobalConstants.SDOH_VALIDATE_EXCEL_DATASET_FOR_REQUIRED_SHEETS_AND_COLUMNS, message= validationError, exception= validationError, active=True)
                    self.ingest_exception_excel = new_row
                    raise Exception(validationError)

                # Ingest metadata
                loc_conf_df = df_excel_file.parse(SdohConstants.SHEETNAME_LOCCONFIG)
                if not self.bronze_validator.validate_loc_conf_df(loc_conf_df):
                    message = f"{LC.INVALID_LOC_CONFIG_INFORMATION.format(file_name=row.path)}"
                    new_row = self.business_events_ingestion_service.create_new_business_event_row(id=str(uuid.uuid4()), activityName=GlobalConstants.SDOH_BRONZE_INGESTION_ACTIVITY_NOTEBOOK, 
                        targetFilePath= self.bronze_tables_path, targetLakehouseName= self.target_lakehouse_name, targetTableName=GlobalConstants.SDOH_META_DATA_TABLE,
                        sourceFilePath= rowPath, sourceLakehouseName= self.source_lakehouse_name, severity= GlobalConstants.ERROR, 
                        eventType= GlobalConstants.SDOH_VALIDATE_LOCATION_CONFIGURATION_DATAFRAME, message= message, exception= message, active=True)
                    self.ingest_exception_excel = new_row
                    raise Exception(message)
                loc_conf = self.utils.prepare_location_configuration(loc_conf_df)
                loc_columns = self.utils.get_locationColumns(loc_conf_df)
                hash_sdmd = self._ingest_metadata(df_excel_file.parse(SdohConstants.SHEETNAME_METADATA, parse_dates=[
                                                    SdohConstants.PUBLISHED_DATE, SdohConstants.VALIDITY_DATE]), loc_conf, row.path)
                # Ingest data
                self._logger.info(f"{LC.DATASETMETADATA_INGESTION_COMPLETE.format(metadata_id=hash_sdmd, file_name=file_name)}")
                file_name_prefix =self.utils.check_filename(file_name)
                file_name_original = file_name.replace(f"{file_name_prefix}_", "", 1)
                for sheet_name in df_excel_file.sheet_names:
                    if sheet_name not in SdohConstants.NON_DATA_SHEET_LIST:
                        table_name = f"{SdohConstants.SD_PREFIX}{file_name_original.split(SdohConstants.DOT)[0]}{SdohConstants.UNDERSCORE}{sheet_name}"
                        sheet_data = df_excel_file.parse(sheet_name,dtype=str)
                        self._ingest_data(sheet_data, table_name, row.path + "/" + sheet_name, hash_sdmd, loc_columns)

                # Ingest layout
                # We ingest layout after data ingestion to make sure failure during data ingestion does not leave the layout table with unused rows
                self._ingest_layout(df_excel_file.parse(SdohConstants.SHEETNAME_LAYOUT), hash_sdmd)
                self._logger.info(f"{LC.LAYOUT_INGESTION_COMPLETE.format(file_name=file_name)}")
                self._logger.info(f"{LC.DATASET_INGESTION_COMPLETE.format(dataset_name=datasetName)}")
                list_processed_files.append(row.path)
                
            except Exception as error:
                bool_excel_ingested = False
                exception_message = f"{LC.DATASET_INGESTION_FAILURE.format(dataset_name=datasetName, error_message=str(error))}"
                self._logger.error(exception_message)
                message = f"{LC.MOVE_FAILED_FILES_FAILED_FOLDER}"
                self._logger.error(message)
                
                if isinstance(self.ingest_exception_excel['sourceFilePath'], PosixPath):
                    self.ingest_exception_excel['sourceFilePath'] = str(self.ingest_exception_excel['sourceFilePath'])
                self.exceptions.append(self.ingest_exception_excel)
                self.utils._move_folder_to_failed_folder(self.utils.get_directory(row.path), self.sdoh_failed_folder_path, self.mssparkutils_client)
        
        return bool_excel_ingested

    def ingest_csv(self, df, timestamp, list_processed_files) -> bool:
        """
        Ingests a CSV file into the system.

        Args:
        - df (DataFrame): The DataFrame containing the data to be ingested.
        - timestamp (str): Timestamp of the ingestion which is prefixed to the file.
        - list_processed_files (list): List of processed files.

        Returns:
            bool: True if all files sucessfully ingested, False otherwise.
        """
        bool_csv_ingested = True
        csv_datasets = {}
        # Validate path and Group CSV files as per the dataset
        for datafile in df.rdd.toLocalIterator():
            rowPath = Path(datafile["path"])
            datasetname = rowPath.parent.name
            if datasetname in csv_datasets.keys():
                continue
            csv_datasets[datasetname] = df.filter(df.path.contains("/" +datasetname + "/"))

        for datasetName, dataset in csv_datasets.items():
            datasetFolder = self.utils.get_directory(dataset.first().path)
            try:
                self._logger.info(f"{LC.DATASET_INGESTION_START.format(dataset_name=datasetName)}")
                # Validate the CSV Dataset
                dataset.cache()
                validationError = self.bronze_validator.validate_csv_dataset(datasetFolder,
                                                                             timestamp,
                                                                             self.mssparkutils_client)
                if validationError is not None:
                    new_row = self.business_events_ingestion_service.create_new_business_event_row(id=str(uuid.uuid4()), activityName=GlobalConstants.SDOH_BRONZE_INGESTION_ACTIVITY_NOTEBOOK, 
                        targetFilePath= self.bronze_tables_path, targetLakehouseName= self.target_lakehouse_name, targetTableName= GlobalConstants.SDOH_NA,
                        sourceFilePath= datasetFolder, sourceLakehouseName= self.source_lakehouse_name, severity= GlobalConstants.ERROR, 
                        eventType= GlobalConstants.SDOH_VALIDATE_CSV_DATASET_FOR_REQUIRED_SHEETS_AND_COLUMNS, message= validationError, exception= validationError, active=True)
                    self.ingest_exception_csv = new_row
                    raise Exception(validationError)

                metadata_file = dataset.filter(dataset.path.contains(SdohConstants.SHEETNAME_METADATA)).first()
                loc_conf_file = dataset.filter(dataset.path.contains(SdohConstants.SHEETNAME_LOCCONFIG)).first()
                layout_file = dataset.filter(dataset.path.contains(SdohConstants.SHEETNAME_LAYOUT)).first()
                data_df = dataset.filter(~dataset.path.contains(SdohConstants.SHEETNAME_LAYOUT)
                                    & ~dataset.path.contains(SdohConstants.SHEETNAME_METADATA)
                                    & ~dataset.path.contains(SdohConstants.SHEETNAME_LOCCONFIG))

                metadata_df = self.utils.read_csv_stream(bytes(metadata_file.content), metadata_file.path)
                loc_conf_df = self.utils.read_csv_stream(bytes(loc_conf_file.content), loc_conf_file.path)
                layout_df = self.utils.read_csv_stream(bytes(layout_file.content), layout_file.path)

                if not self.bronze_validator.validate_metadata_df(metadata_df):
                    exception_message = f"{LC.INVALID_METADATA_INFORMATION.format(file_path=metadata_file.path)}"
                    new_row = self.business_events_ingestion_service.create_new_business_event_row(id=str(uuid.uuid4()), activityName=GlobalConstants.SDOH_BRONZE_INGESTION_ACTIVITY_NOTEBOOK, 
                        targetFilePath= self.bronze_tables_path, targetLakehouseName= self.target_lakehouse_name, targetTableName= GlobalConstants.SDOH_META_DATA_TABLE,
                        sourceFilePath= datasetFolder, sourceLakehouseName= self.source_lakehouse_name, severity= GlobalConstants.ERROR, 
                        eventType= GlobalConstants.SDOH_VALIDATE_METADATA_DATAFRAME, message= exception_message, exception= exception_message, active=True)
                    self.ingest_exception_csv = new_row
                    raise Exception(exception_message)
                if not self.bronze_validator.validate_loc_conf_df(loc_conf_df):
                    message = f"{LC.INVALID_LOC_CONFIG_INFORMATION.format(file_path=loc_conf_file.path)}"
                    new_row = self.business_events_ingestion_service.create_new_business_event_row(id=str(uuid.uuid4()), activityName=GlobalConstants.SDOH_BRONZE_INGESTION_ACTIVITY_NOTEBOOK, 
                        targetFilePath= self.bronze_tables_path, targetLakehouseName= self.target_lakehouse_name, targetTableName= GlobalConstants.SDOH_META_DATA_TABLE,
                        sourceFilePath= datasetFolder, sourceLakehouseName= self.source_lakehouse_name, severity= GlobalConstants.ERROR, 
                        eventType= GlobalConstants.SDOH_VALIDATE_LOCATION_CONFIGURATION_DATAFRAME, message= message, exception= message, active=True)
                    self.ingest_exception_csv = new_row
                    raise Exception(message)
                if not self.bronze_validator.validate_layout_df(layout_df):
                    message = f"{LC.INVALID_LAYOUT_INFORMATION.format(file_path=layout_file.path)}"
                    new_row = self.business_events_ingestion_service.create_new_business_event_row(id=str(uuid.uuid4()), activityName=GlobalConstants.SDOH_BRONZE_INGESTION_ACTIVITY_NOTEBOOK, 
                        targetFilePath= self.bronze_tables_path, targetLakehouseName= self.target_lakehouse_name, targetTableName= GlobalConstants.SDOH_LAYOUT_TABLE,
                        sourceFilePath= datasetFolder, sourceLakehouseName= self.source_lakehouse_name, severity= GlobalConstants.ERROR, 
                        eventType= GlobalConstants.SDOH_VALIDFATE_LAYOUT_DATAFRAME, message= message, exception= message, active=True)
                    self.ingest_exception_csv = new_row
                    raise Exception(message)

                #Ingest metadata
                metadata_df[SdohConstants.PUBLISHED_DATE] = pandas.to_datetime(metadata_df[SdohConstants.PUBLISHED_DATE])
                metadata_df[SdohConstants.VALIDITY_DATE] = pandas.to_datetime(metadata_df[SdohConstants.VALIDITY_DATE])
                loc_columns = self.utils.get_locationColumns(loc_conf_df)
                loc_conf = self.utils.prepare_location_configuration(loc_conf_df)
                hash_sdmd = self._ingest_metadata(metadata_df, loc_conf, metadata_file.path)
                list_processed_files.append(metadata_file.path)
                list_processed_files.append(loc_conf_file.path)
                self._logger.info(
                    f"{LC.DATASETMETADATA_INGESTION_COMPLETE.format(metadata_id=hash_sdmd, file_name=metadata_file.path)}"
                )

                #Ingest data
                for row in data_df.collect():
                    file_name = os.path.basename(row.path)
                    file_name_prefix =self.utils.check_filename(file_name)
                    file_name_original = file_name.replace(f"{file_name_prefix}_", "", 1)
                    csv_df = self.utils.read_csv_stream(bytes(row.content), row.path)
                    table_name = f"{SdohConstants.SD_PREFIX}{file_name_original.split(SdohConstants.DOT)[0]}"
                    self._ingest_data(csv_df, table_name, row.path, hash_sdmd, loc_columns)
                    list_processed_files.append(row.path)
                # Ingest layout
                # We ingest layout after data ingestion to make sure failure during data ingestion does not leave the layout table with unused rows
                self._ingest_layout(layout_df, hash_sdmd)
                list_processed_files.append(layout_file.path)
                self._logger.info(f"{LC.LAYOUT_INGESTION_COMPLETE.format(file_name=layout_file.path)}")
                self._logger.info(f"{LC.DATASET_INGESTION_COMPLETE.format(dataset_name=datasetName)}")
                
            except Exception as ex:
                bool_csv_ingested = False
                exception_message = f"{LC.DATASET_INGESTION_FAILURE.format(dataset_name=datasetName, error_message=str(ex))}"
                self._logger.error(exception_message)
                message = f"{LC.MOVE_FAILED_FILES_FAILED_FOLDER}"
                self._logger.error(message)
            
                self.exceptions.append(self.ingest_exception_csv)
                self.utils._move_folder_to_failed_folder(datasetFolder, self.sdoh_failed_folder_path, self.mssparkutils_client)
        
        return bool_csv_ingested

    def _ingest_metadata(self, metadata_df, loc_config, folder_path) -> str:
        """
        Ingest metadata table
        Args:
        - metadata_df - Metadata dataframe in dataset
        - loc_config - Prepared location configuration string
        - folder_path - str: Path for the dataset

        Returns:
        - Hash of the dataset metadata information
        """
        hash_sdmd = pandas.util.hash_pandas_object(metadata_df).astype(str)[0]
        delta_table_path = f"{self.bronze_tables_path}/{SdohConstants.SD_PREFIX}{SdohConstants.SHEETNAME_METADATA}"
        # Check if the metadata table already exists
        if self.spark.catalog.tableExists(f"{SdohConstants.SD_PREFIX}{SdohConstants.SHEETNAME_METADATA}"):
            # Read Delta table into a DataFrame
            table_df = self.spark.read.format(
                SdohConstants.FORMAT_DELTA).load(delta_table_path)
            contains_dataset = table_df[table_df[SdohConstants.COLUMN_DATASET_METADATA_ID] == hash_sdmd].count() > 0
            # Dataset already exists in the metadata table
            if contains_dataset:
                self._logger.info(f"{LC.METADATAID_ALREADY_EXISTS_LOC_UPDATE.format(metadata_id = hash_sdmd)}")
                table_df = table_df.withColumn(SdohConstants.COLUMN_LOC_CONFIG,
                    when(col(SdohConstants.COLUMN_DATASET_METADATA_ID) == hash_sdmd, loc_config)
                         .otherwise(col(SdohConstants.COLUMN_LOC_CONFIG)))
                for col_name in table_df.columns:
                    table_df=table_df.withColumnRenamed(col_name,col_name.strip())
                table_df.write.format(SdohConstants.FORMAT_DELTA).mode(
                    SdohConstants.MODE_OVERWRITE).save(delta_table_path)
                return hash_sdmd
        metadata_df.insert(loc=len(metadata_df.columns),
                           column=SdohConstants.COLUMN_DATASET_METADATA_ID, value=hash_sdmd)
        metadata_df.insert(loc=len(metadata_df.columns),
                           column=GlobalConstants.DEFAULT_BRONZE_CREATED_DATE_COL, value=pandas.Timestamp(SdohConstants.NOW))
        metadata_df.insert(loc=len(metadata_df.columns),
                           column=SdohConstants.FOLDER_PATH, value=folder_path)
        metadata_df.insert(loc=len(metadata_df.columns),
                           column=SdohConstants.COLUMN_LOC_CONFIG, value=loc_config)
        spark_df = self.spark.createDataFrame(metadata_df)
        for col_name in spark_df.columns:
            spark_df=spark_df.withColumnRenamed(col_name,col_name.strip())
        spark_df.write.format(SdohConstants.FORMAT_DELTA).mode(
            SdohConstants.MODE_APPEND).save(delta_table_path)
        
        self._collect_source_and_target_metrics_fn(metrics={"numSourceRecords": len(metadata_df)}, delta_table_path=delta_table_path)
        return hash_sdmd

    def _ingest_layout(self, layout_df, hash_sdmd) -> None:
        """
        Ingest layout table
         Args:
        - layout_df - Layout dataframe in dataset
        - hash_sdmd - Hash of the dataset metadata information
        """
        layout_df.insert(loc=len(layout_df.columns),
                         column=SdohConstants.COLUMN_DATASET_METADATA_ID, value=hash_sdmd)
        layout_df.insert(loc=len(layout_df.columns), column=GlobalConstants.DEFAULT_BRONZE_CREATED_DATE_COL,
                         value=pandas.Timestamp(SdohConstants.NOW))
        hash_layout = pandas.util.hash_pandas_object(layout_df).astype(str)
        layout_df.insert(loc=len(layout_df.columns),
                         column=SdohConstants.COLUMN_LAYOUT_ID, value=hash_layout)
        spark_df = self.spark.createDataFrame(layout_df)
        for col_name in spark_df.columns:
            spark_df=spark_df.withColumnRenamed(col_name,col_name.strip())

        if self.spark.catalog.tableExists(f"{SdohConstants.SD_PREFIX}{SdohConstants.SHEETNAME_LAYOUT}") :
            # Merge the layout table with the existing layout table
            deltaTable = DeltaTable.forPath(self.spark,  f"{self.bronze_tables_path}/{SdohConstants.SD_PREFIX}{SdohConstants.SHEETNAME_LAYOUT}")
            # Perform upsert (merge)
            deltaTable.alias("oldData") \
                .merge(
                    spark_df.alias("newData"),
                    "oldData.SocialDeterminantName= newData.SocialDeterminantName AND oldData.DataSetMetadataId= newData.DataSetMetadataId") \
                .whenNotMatchedInsertAll() \
                .execute()
        else:
            spark_df.write.format(SdohConstants.FORMAT_DELTA).mode(SdohConstants.MODE_APPEND).save(
                f"{self.bronze_tables_path}/{SdohConstants.SD_PREFIX}{SdohConstants.SHEETNAME_LAYOUT}")
        self._collect_source_and_target_metrics_fn(metrics={"numSourceRecords": len(layout_df)}, delta_table_path=f"{self.bronze_tables_path}/{SdohConstants.SD_PREFIX}{SdohConstants.SHEETNAME_LAYOUT}")

    def _ingest_data(self, sheet_data, table_name, file_path, hash_sdmd, loc_columns) -> None:
        """
        Iterate through the data sheets and ingest the data into the bronze tables
        Args:
        - sheet_data - Dataframe containing the data to be ingested
        - table_name - Name of the table to be created
        - file_path - Path of the file being ingested
        - hash_sdmd - Hash of the dataset metadata information
        - loc_columns - List of location columns for validation
        """
        validationError = self.bronze_validator.validate_data(sheet_data, loc_columns, file_path)
        if validationError is not None:
            raise Exception(validationError)
        sheet_data[GlobalConstants.DEFAULT_BRONZE_CREATED_DATE_COL] = pandas.Timestamp.now()
        sheet_data[SdohConstants.COLUMN_DATASET_METADATA_ID] = hash_sdmd
        table_name=self.utils.to_pascal_case(table_name)
        try:
            spark_df = self.spark.createDataFrame(sheet_data)
            
            # Reposition the createddate column to be the first column in each bronze table to enable indexing.
            column_to_move = GlobalConstants.DEFAULT_BRONZE_CREATED_DATE_COL
            columns = spark_df.columns
            reordered_columns = [column_to_move] + [col for col in columns if col != column_to_move]
            df_reordered = spark_df.select(reordered_columns)
            for col_name in df_reordered.columns:
                df_reordered=df_reordered.withColumnRenamed(col_name,col_name.strip())    
        
            df_reordered.write.format(SdohConstants.FORMAT_DELTA).mode(
                SdohConstants.MODE_OVERWRITE).save(f"{self.bronze_tables_path}/{table_name}")
            
            self._collect_source_and_target_metrics_fn(metrics={"numSourceRecords": len(sheet_data)}, delta_table_path=f"{self.bronze_tables_path}/{table_name}")

        except Exception as ex:
            raise Exception(f"{LC.DATAFILE_TABLE_CREATION_ERROR.format(file_path=file_path, error_message=str(ex))}")
        self._logger.info(
            f"{LC.DATA_TABLE_INGESTION_COMPLETE.format(table_name=table_name)}"
        )