import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Optional
from pyspark.sql import SparkSession
from tenacity import RetryError
from microsoft.fabric.hls.hds.ai_enrichments.core.clients.models.enrichment_api_response import EnrichmentAPIResponse
from microsoft.fabric.hls.hds.ai_enrichments.core.clients.openai_client.models.openai_client_settings import OpenAIClientSettings
from microsoft.fabric.hls.hds.ai_enrichments.core.clients.openai_client_orchestrator import OpenAIClientOrchestrator
from microsoft.fabric.hls.hds.ai_enrichments.core.errors.model_processor_error import ModelProcessError
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.conversational.models.conversational_enrichment_output import ConversationalEnrichmentOutput
from microsoft.fabric.hls.hds.ai_enrichments.core.clients.client_retry_management.retry_client_manager import RetryClientManager
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_context import EnrichmentContext
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_response import EnrichmentResponse
from microsoft.fabric.hls.hds.ai_enrichments.core.base_classes.enrichment_model_processor_base import EnrichmentModelProcessorBase
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import MSSparkUtilsClientBase
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.constants.enrichment_use_case_constants import EnrichmentUseCaseConstants as EUC
from microsoft.fabric.hls.hds.ai_enrichments.core.constants.ai_enrichments_constants import AIEnrichmentsConstants as EC
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.constants.enrichment_use_case_logging_constants import EnrichmentUseCaseLoggingConstants as ELC
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.utils.enrichment_model_utils import EnrichmentModelUtils as ModelUtils

class ConversationalDataModelProcessor(EnrichmentModelProcessorBase):
    """
    Provides methods to process conversational data using OpenAI orchestration.
    """

    def __init__(
        self,
        spark: SparkSession,
        data_enrichment_use_case:str =None,
        mssparkutils_client: Optional[MSSparkUtilsClientBase] = None
    ):
        """
        Initializes the processor with Spark, configuration, and optional MSSparkUtils client.
        """
        super().__init__(mssparkutils_client)
        self.spark = spark
        self.data_enrichment_use_case = data_enrichment_use_case
        self._logger = LoggingHelper.get_ai_enrichment_conversationaldata_execution__logger(
            self.spark,
            self.__class__.__name__,
            GC.LOGGING_LEVEL
        )

    def process(
        self,
        enrichment_generation_id: str, model_config:dict,
        enrichment_contexts: List[EnrichmentContext],
        should_save_raw_response: bool,
        output_path: str
    ) -> List[EnrichmentResponse]:
        """
        Process the end-to-end enrichment of conversational data. Splits
        documents into batches and processes them in parallel with configured
        use-case settings.
        """
        try:
            enrichment_responses = []
            self.model_config = model_config
            use_case_configs=EUC.CONVERSATIONAL_DATA_ENRICHMENT_USE_CASES
            if use_case_configs:
                process_use_cases=use_case_configs.values()
                if self.data_enrichment_use_case:
                    process_use_cases =[use_case_configs[self.data_enrichment_use_case]]
                for use_case_config in process_use_cases:
                    self._logger.info(ELC.AI_ENRICHMENT_CONVERSATIONAL_DATA_USECASE_INFO.format(use_case_name=use_case_config.get("use_case_name")))
                    self._initialize_client_manager(self.model_config, use_case_config)
                    raw_response_path = os.path.join(output_path, EC.ENRICHMENT_LANDING_ZONE_RAW_RESPONSE_PATH)
                    with ThreadPoolExecutor(max_workers=EUC.DEFAULT_AI_ENRICHMENT_EXECUTION_THREADS) as executor:
                        futures = [
                            executor.submit(
                                self._process_batch,
                                enrichment_generation_id,
                                enrichment_contexts,
                                i,
                                should_save_raw_response,
                                raw_response_path
                            )
                            for i in range(0, len(enrichment_contexts), EUC.DEFAULT_AI_ENRICHMENT_EXECUTION_BATCH_SIZE)
                        ]
                        for future in as_completed(futures):
                            if future.exception() is None:
                                result= future.result()
                                if result is not None:
                                    enrichment_responses.extend(future.result())
                            else:
                                exception=future.exception()
                                if isinstance(exception, RetryError):
                                    enrichment_error = exception.last_attempt.exception()
                                    self._logger.warning(enrichment_error)
                                else:
                                    self._logger.warning(exception)   

            return enrichment_responses
        except Exception as ex:
            raise ModelProcessError(str(ex)) from ex

    def _initialize_client_manager(self, model_config: dict, use_case_config: dict) -> None:
        """
        Creates and configures a RetryClientManager instance with parameters
        from the model and use-case configuration.
        """
        openai_config = OpenAIClientSettings(
            azure_endpoint=model_config.get("api_endpoint"),
            api_key=model_config.get("api_key"),
            api_version=model_config.get("version"),
            model_name=model_config.get("name"),
        )
        openai_client_orchestrator = OpenAIClientOrchestrator(
            api_endpoint=model_config.get("api_endpoint"),
            api_key=model_config.get("api_key"),
            open_ai_conn_config=openai_config,
            system_message=use_case_config.get("system_message"),
            examples=use_case_config.get("examples"),
            logger=self._logger
        )
        self.client_manager = RetryClientManager(openai_client_orchestrator,logger=self._logger)

    def _extract_text_from_documents(self, document_inputs: List[EnrichmentContext]) -> List[str]:
        """
        Extracts the textual content from each document's references.
        """
        return [
            text_file.content
            for enrichment_context in document_inputs
            for text_file in enrichment_context.enrichment_input.text_file_references
        ]

    def _analyze_conversations(
        self,
        document_texts: List[str]
    ) -> List[EnrichmentAPIResponse]:
        """
        Calls the configured OpenAI model to analyze each text and returns
        the model responses.
        """
        call_completion = self.client_manager.execute_client()
        
        results:List[EnrichmentAPIResponse] = []
        
        with ThreadPoolExecutor(max_workers=EUC.DEFAULT_AI_ENRICHMENT_EXECUTION_THREADS) as executor:
            futures = [
                executor.submit(call_completion, user_query=text, response_model=ConversationalEnrichmentOutput)
                for text in document_texts
            ]
            for future in as_completed(futures):
                response: EnrichmentAPIResponse = future.result()
                if response.is_completed:
                    results.append(response)  
        return results

    def _format_analysis_results(
        self,
        enrichment_generation_id: str,
        document_inputs: List[EnrichmentContext],
        start_index: int,
        results: List[EnrichmentAPIResponse],
        should_save_raw_response: bool,
        raw_response_output_path: str
    ) -> List[EnrichmentResponse]:
        """
        Converts raw model responses into EnrichmentResponse objects and
        saves them if required.
        """
        formatted_responses = []
        for i, result in enumerate(results):
            enrichment_response = EnrichmentResponse(
                id=document_inputs[start_index + i].enrichment_input.text_file_references[0].id,
                content=result.data
            )
            if should_save_raw_response:
                ModelUtils.save_model_raw_response(
                    self.mssparkutils_client,
                    enrichment_generation_id,
                    enrichment_response,
                    raw_response_output_path
                )
            formatted_responses.append(enrichment_response)
        return formatted_responses

    def _process_batch(
        self,
        enrichment_generation_id: str,
        document_inputs: List[EnrichmentContext],
        start_index: int,
        should_save_raw_response: bool,
        raw_response_output_path: str
    ) -> List[EnrichmentResponse]:
        """
        Processes a batch of documents, extracting text, analyzing conversations,
        and formatting the results.
        """
        document_batch = document_inputs[start_index : start_index + EUC.DEFAULT_AI_ENRICHMENT_EXECUTION_BATCH_SIZE]
        texts = self._extract_text_from_documents(document_batch)
        results = self._analyze_conversations(texts)
        return self._format_analysis_results(
            enrichment_generation_id,
            document_inputs,
            start_index,
            results,
            should_save_raw_response,
            raw_response_output_path
        )