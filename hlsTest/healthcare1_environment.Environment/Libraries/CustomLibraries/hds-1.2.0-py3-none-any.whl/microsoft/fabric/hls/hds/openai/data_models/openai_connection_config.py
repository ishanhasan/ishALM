# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
from dataclasses import dataclass, field
from typing import Dict
from microsoft.fabric.hls.hds.openai.constants import OpenAIConstants

@dataclass
class OpenAIConnectionConfig:
    """
    Configuration class for OpenAI.
    """
    azure_endpoint: str  # The Azure endpoint for the OpenAI service
    api_key: str  # The API key for authenticating with the OpenAI service
    api_version: str  # The API version to use
    open_ai_config_options: Dict[str, str] = field(default_factory=dict)  # Additional configuration options
    model_name: str = field(default=OpenAIConstants.MODEL_NAME)  # The name of the model to use
