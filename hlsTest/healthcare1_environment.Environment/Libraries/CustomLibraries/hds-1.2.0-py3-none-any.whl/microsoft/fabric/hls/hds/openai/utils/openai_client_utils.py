# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
import html
from microsoft.fabric.hls.hds.openai.constants import OpenAIConstants
from microsoft.fabric.hls.hds.openai.data_models.openai_connection_config import OpenAIConnectionConfig
from microsoft.fabric.hls.hds.openai.data_models.openai_model_response import OpenAIModelResponse
from microsoft.fabric.hls.hds.openai.data_models.openai_model_response_status import OpenAIModelResponseStatus
from microsoft.fabric.hls.hds.global_constants.logging_constants import (
    LoggingConstants as LC,
)

class OpenAIClientUtils:
    @staticmethod
    def format_enrichment_response(response: str, status: OpenAIModelResponseStatus) -> OpenAIModelResponse:
        """
        Format the model response with the given response text and status.

        Args:
            response (str): The response text from the model.
            status (OpenAIModelResponseStatus): The status of the response.

        Returns:
            OpenAIModelResponse: The formatted model response object.
        """
        return OpenAIModelResponse(
            response=response,
            status=status
        )
    
    @staticmethod
    def build_json_schema(schema_format: dict) -> dict:
        """
        Build a JSON schema dictionary from the provided schema format.

        Args:
            schema_format (dict): The schema format to be converted into a JSON schema.

        Returns:
            dict: The JSON schema dictionary.
        """
        return {
            "type": "json_schema",
            "json_schema": {
                "name": "output_response",
                "strict": True,
                "schema": schema_format
            }
        }
    
    @staticmethod  
    def convert_schema(input_schema):  
        
        if 'fields' not in input_schema or 'type' not in input_schema['fields'][0] or 'elementType' not in input_schema['fields'][0]['type'] or 'fields' not in input_schema['fields'][0]['type']['elementType']:
             raise ValueError(f"{LC.DAX_DATA_INPUT_SCHEMA_FORMAT_ERROR})")
        
        fields = input_schema['fields'][0]['type']['elementType']['fields']  
        
        properties = {}  
        for field in fields:  
            properties[field['name']] = {  
                "type": field['type'].lower()  
            }  
        
        output_schema = {  
            "type": "object",  
            "properties": {  
                input_schema['fields'][0]['name']: {  
                    "type": "array",  
                    "items": {  
                        "type": "object",  
                        "properties": properties,  
                        "required": list(properties.keys()),  
                        "additionalProperties": False  
                    }  
                }  
            },  
            "required": [input_schema['fields'][0]['name']],  
            "additionalProperties": False  
        }  

        return output_schema  
  
    @staticmethod
    def create_messages(user_query: str, messages: list) -> list:
        """
        Create a list of messages with the user message based on the provided prompt.

        Args:
            user_query (str): The user query.
            messages (list): A list of existing messages.

        Returns:
            list: A list of messages with the user message.
        """
        user_input = f"##INPUT##\n{html.escape(user_query)}\n##INPUT##"
        messages.append({"role": "user", "content": user_input})
        return messages

    @staticmethod
    def create_system_instructions(system_message: str, examples: list = None) -> list:
        """
        Create a list of messages with the system message and user message based on the provided prompt.

        Args:
            system_message (str): The system instruction message.
            examples (list, optional): A list of dictionaries containing user and assistant messages. Defaults to None.

        Returns:
            list: A list of messages with the system message and user message.
        """
        
        messages = [{"role": "system", "content": system_message}]  
        
        for example in examples:  
            user_message = example.get("user")  
            assistant_message = example.get("assistant")  
    
            if user_message:  
                messages.append({"role": user_message['role'], "content": user_message['content']})  
            
            if assistant_message:  
                messages.append({"role": "assistant", "content": str(assistant_message)})  
        
        return messages

    @staticmethod
    def prepare_tools_and_format(output_format_as_json: bool, schema_format: dict) -> tuple:
        """
        Prepare tools and response format based on the output_format_as_json flag.
        """
        tools = []
        response_format = None
        if output_format_as_json:
            tool_format_json = {
                "type": "function",
                "function": {
                    "name": OpenAIConstants.DEFAULT_OPEN_AI_TOOL_JSON,
                    "description": "Assistant to format the output into the required JSON structure",
                    "strict": True,
                    "parameters": schema_format
                }
            }
            tools.append(tool_format_json)
            response_format = {"type": "json_object"}
        return tools, response_format
    
    @staticmethod
    def process_completion_message(chat_completion) -> str:  
        """  
        Process the chat completion message and handle errors if any.  
    
        Args:  
            chat_completion: The chat completion object returned by the OpenAI API.  
    
        Returns:  
            str: The processed completion message or an error message.  
        """  
        choice = next(iter(chat_completion.choices), None)  
        return choice.message.content.strip()  
    
    @staticmethod
    def format_model_response(result_status,response, error_type=None, error_message=None,retry_count=0):
        """
        Create an OpenAIModelResponse object.

        Args:
            response (any): The response content.
            result_status (OpenAIResponseStatus): The result status.
            error_type (str, optional): The error type, if any. Defaults to None.
            error_message (str, optional): The error message, if any. Defaults to None.

        Returns:
            OpenAIModelResponse: The formatted OpenAI model response.
        """
        response_status = OpenAIModelResponseStatus(
            error_details=error_message,
            error_type=error_type,
            result=result_status,
            retry_count= retry_count
        )
        return OpenAIClientUtils.format_enrichment_response(response, response_status)
    
    @staticmethod
    def validate_open_ai_config(open_ai_config: OpenAIConnectionConfig) -> bool:
        """
        Validates the OpenAI configuration.

        Args:
            open_ai_config (OpenAIConnectionConfig): The OpenAI configuration object.

        Returns:
            bool: True if the OpenAI configuration is valid, False otherwise.
        """
        required_fields = ['api_key', 'model_name', 'azure_endpoint']
        return all(getattr(open_ai_config, field) for field in required_fields)
