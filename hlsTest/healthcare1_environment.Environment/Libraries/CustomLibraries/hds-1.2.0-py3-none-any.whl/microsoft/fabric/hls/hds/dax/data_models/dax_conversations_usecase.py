# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------


from dataclasses import dataclass, field
from typing import List
from microsoft.fabric.hls.hds.openai.data_models.openai_connection_config import OpenAIConnectionConfig


@dataclass
class DaxConversationsUseCase:
    """
    Represents the settings for a DAX Conversations use case config.
    """
    # The name of the use case
    use_case_name: str  
    # The OpenAI configuration for the use case
    open_ai_config: OpenAIConnectionConfig  
    # The system message for the use case
    system_message: str 
     # The examples to define the format
    examples: List[dict]     
    # The response format for the use case
    response_format: dict = field(default_factory=lambda: {})
