# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
from typing import Any, Dict, List, Optional, Union
from datetime import datetime
from azure.ai.textanalytics import TextAnalyticsClient
from azure.ai.textanalytics import AnalyzeHealthcareEntitiesResult, DocumentError
from azure.core.exceptions import HttpResponseError
from microsoft.fabric.hls.hds.nlp.response.nlp_result import NLPResult
from microsoft.fabric.hls.hds.nlp.constants import NLPConstants as C


def process_entities(
    doc: Union[AnalyzeHealthcareEntitiesResult, DocumentError]
) -> List[Dict[str, Any]]:
    """
    Process entities from a single API output.

    :param doc: The API output for a single document
    :return: List of processed entities
    """
    entities = []
    for entity in doc.entities:
        data_sources = []
        if entity.data_sources is not None:
            for data_source in entity.data_sources:
                data_sources.append(
                    {"entity_id": data_source.entity_id, "name": data_source.name}
                )
        entities.append(
            {
                "offset": entity.offset,
                "length": entity.length,
                "text": entity.text,
                "category": entity.category,
                "confidence_score": entity.confidence_score,
                "data_sources": data_sources,
            }
        )
    return entities


def process_entity_relations(
    doc: Union[AnalyzeHealthcareEntitiesResult, DocumentError]
) -> List[Dict[str, Any]]:
    """
    Process entity relations from a single API output.

    :param doc: The API output for a single document
    :return: List of processed entity relations
    """
    entity_relations = []
    for relation in doc.entity_relations:
        roles = []
        for role in relation.roles:
            roles.append(
                {
                    "name": role.name,
                    "entity": {
                        "offset": role.entity.offset,
                        "length": role.entity.length,
                        "text": role.entity.text,
                    },
                }
            )
        entity_relations.append(
            {"relation_type": relation.relation_type, "roles": roles}
        )
    return entity_relations


def process_warnings(
    doc: Union[AnalyzeHealthcareEntitiesResult, DocumentError]
) -> List[Dict[str, Any]]:
    """
    Process warnings from a single API output.

    :param doc: The API output for a single document
    :return: List of processed warnings
    """
    warnings = []
    for warning in doc.warnings:
        warnings.append({"code": warning.code, "message": warning.message})
    return warnings


def process_single_api_output(
    doc: Union[AnalyzeHealthcareEntitiesResult, DocumentError],
    error_message: Optional[str] = None,
    error_status_code: Optional[int] = None,
) -> NLPResult:
    """
    Process the output of a single API call.

    :param doc: The output of a single API call (AnalyzeHealthcareEntitiesResult or DocumentError)
    :param error_message: Optional error message in case of an error
    :param error_status_code: Optional error status code in case of an error
    :return: An NLPResult object
    """
    if error_message is not None or error_status_code is not None:
        error = {"code": error_status_code, "message": error_message}
        return NLPResult(
            id=doc["id"],
            is_error=True,
            error=error,
            warnings=None,
            entities=None,
            entity_relations=None,
            statistics=None,
            nlp_last_executed=datetime.now(),
        )

    # Process entities
    entities = process_entities(doc)

    # Process entity relations
    entity_relations = process_entity_relations(doc)

    # Process warnings
    warnings = process_warnings(doc)

    return NLPResult(
        id=doc.id,
        is_error=doc.is_error,
        error=doc.error if doc.is_error else None,
        warnings=warnings,
        entities=entities,
        entity_relations=entity_relations,
        statistics=doc.statistics,
        nlp_last_executed=datetime.now(),
        fhir_bundle=str(doc.get("fhir_bundle", None)),
    )


def ta4hbundle_udf(
    text_analytics_client: TextAnalyticsClient,
    nlp_column_mappings: Dict[str, str],
    model_version: str,
    fhir_version: str,
    batched_docs: list,
) -> list:
    """
    User-defined function for Text Analytics for Health API.

    :param text_analytics_client: TextAnalyticsClient instance
    :param batched_docs: list of batched documents to analyze
    :param model_version: Optional parameter to indicate which 
            model will be used for scoring, e.g. "latest", "2019-10-01". 
            Defaults to "latest"
    :param fhir_version: The FHIR Spec version that the result will use to
            format the fhir_bundle on the result object. For additional 
            information see https://www.hl7.org/fhir/overview.html.The only 
            acceptable values to pass in are None and "4.0.1". The default
            value is None.
    :return: analysis results
    """
    # NLP results
    nlp_result_structured = []

    id_column = nlp_column_mappings[C.DEFAULT_NLP_COLUMNS_NAMING_ID_KEY]
    text_column = nlp_column_mappings[C.DEFAULT_NLP_COLUMNS_NAMING_TEXT_KEY]

    # Prepare the documents for the API call
    documents = [
        {"id": doc[id_column], "text": doc[text_column]} for doc in batched_docs
    ]
    try:
        # Start the Text Analytics for Health analysis
        poller = text_analytics_client.begin_analyze_healthcare_entities(
            documents,
            display_name=C.DEFAULT_TEXT_ANALYTICS_REQUEST_DISPLAY_NAME,
            model_version=model_version,
            fhir_version=fhir_version,
            show_stats=True,
        )

        # Retrieve the results from the analysis
        docs_results = poller.result()
    except (HttpResponseError, TypeError, ValueError) as ex:
        error_message = str(ex)
        error_status_code = None
        
        if isinstance(ex, HttpResponseError):
            error_status_code = ex.status_code
            if ex.status_code == 429:
                raise ex

        for doc in batched_docs:
            nlp_result_structured.append(
                process_single_api_output(
                    doc, error_message=error_message, error_status_code=error_status_code
                )
            )
        return nlp_result_structured

    # If results were returned
    for doc in docs_results:
        nlp_result_structured.append(process_single_api_output(doc))

    return nlp_result_structured
