 # -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# -------------------------------------------------------------------------

from typing import Any
from azure.ai.textanalytics import TextAnalyticsClient
from azure.core.credentials import AzureKeyCredential
from microsoft.fabric.hls.hds.ai_enrichments.core.base_classes.enrichment_model_client_base import EnrichmentModelClientBase
from microsoft.fabric.hls.hds.ai_enrichments.core.clients.models.enrichment_api_response import EnrichmentAPIResponse
from microsoft.fabric.hls.hds.ai_enrichments.core.errors.enrichment_api_response_error import EnrichmentAPIResponseError
from microsoft.fabric.hls.hds.ai_enrichments.core.errors.model_configuration_error import ModelConfigurationError

class TA4hClientOrchestrator(EnrichmentModelClientBase):
    """
    Orchestrator class for interacting with the Azure Text Analytics for Health (TA4H) service.
    """

    def create(self) -> Any:
        """
        This method initializes the TextAnalyticsClient with the provided API endpoint and key.
        If the client creation fails, a ModelConfigurationError is raised.
        """
        try:
            self.client = TextAnalyticsClient(
                endpoint=self.api_endpoint,
                credential=AzureKeyCredential(self.api_key)
            )
        except Exception as e:
            raise ModelConfigurationError(e)
        
    def execute(self, **kwargs) -> EnrichmentAPIResponse:
        """
        Executes the healthcare entities analysis using the TA4H service.
        Args:
            **kwargs: Arbitrary keyword arguments. Expected to contain 'documents' key with the list of documents to analyze.

        Returns:
            EnrichmentAPIResponse: The response from the TA4H service, containing either the analysis result or an error message.
        """
        try:
            client_response = self.client.begin_analyze_healthcare_entities(
                documents=kwargs.get("documents")
            )
            if client_response:
                return EnrichmentAPIResponse(
                    data=client_response.result()
                )
        except Exception as e:
            return EnrichmentAPIResponse(
                error_message=str(e)
            )
