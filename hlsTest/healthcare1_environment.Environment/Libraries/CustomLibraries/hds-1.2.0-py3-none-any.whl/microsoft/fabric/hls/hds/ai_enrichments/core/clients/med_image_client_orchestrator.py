# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# -------------------------------------------------------------------------

import io
import zipfile
from typing import Any, Dict
from microsoft.fabric.hls.hds.ai_enrichments.core.base_classes.enrichment_model_client_base import EnrichmentModelClientBase
from microsoft.fabric.hls.hds.ai_enrichments.core.clients.models.enrichment_api_response import EnrichmentAPIResponse
from microsoft.fabric.hls.hds.ai_enrichments.core.errors.enrichment_value_error import EnrichmentValueError
from microsoft.fabric.hls.hds.ai_enrichments.core.utils.ai_enrichments_utils import AIEnrichmentsUtils
from microsoft.fabric.hls.hds.ai_enrichments.core.constants.ai_enrichments_logging_constants import AIEnrichmentsLoggingConstants as ELC

class MedImageClientOrchestrator(EnrichmentModelClientBase):
    def execute(self, **kwargs) -> EnrichmentAPIResponse:
        """
        Executes the image enrichment process.

        Args:
            **kwargs: Arbitrary keyword arguments. Expected to contain 'file_path'.

        Returns:
            EnrichmentAPIResponse: The response from the enrichment API.
        """
        try:
            file_path = kwargs.get('file_path')
            if not file_path:
                 raise EnrichmentValueError(ELC.AI_ENRICHMENT_CLIENT_INVALID_INPUT)
            binary_data = self._extract_file_content(file_path)
            image_data = AIEnrichmentsUtils.encode_dicom_image(binary_data)
            data = self._build_payload(image_data)
            response = AIEnrichmentsUtils.submit_request(
                api_endpoint=self.api_endpoint,
                headers=self._get_headers(),
                api_key=self.api_key,
                json=data
            )
            return EnrichmentAPIResponse(data=response)
        except Exception as e:
            self._logger.error(f"{ELC.AI_ENRICHMENT_CLIENT_EXECUTION_ERROR.format(error=e)}")
            return EnrichmentAPIResponse(error_message=str(e))

    def _extract_file_content(self, file_path: str) -> bytes:
        """
        Extracts the content of the file.

        Args:
            file_path (str): The path to the file.

        Returns:
            bytes: The binary content of the file.
        """
        if file_path.endswith('.zip'):
            return self._extract_zip_content(file_path)
        return self._extract_image_content(file_path)

    def _extract_zip_content(self, file_path: str) -> bytes:
        """
        Extracts the content of a zip file.

        Args:
            file_path (str): The path to the zip file.

        Returns:
            bytes: The binary content of the first file in the zip archive.
        """
        def _read_zip(data: bytes) -> bytes:
            with zipfile.ZipFile(io.BytesIO(data), 'r') as z:
                return z.read(z.namelist()[0])
        return (
            self.spark.sparkContext.binaryFiles(file_path)
            .map(lambda x: _read_zip(x[1]))
            .collect()[0]
        )

    def _extract_image_content(self, file_path: str) -> bytes:
        """
        Extracts the content of an image file.

        Args:
            file_path (str): The path to the image file.

        Returns:
            bytes: The binary content of the image file.
        """
        binary_df = self.spark.read.format("binaryFile").load(file_path)
        return binary_df.collect()[0].content

    def _build_payload(self, image_data: str) -> Dict[str, Any]:
        """
        Builds the payload for the API request.

        Args:
            image_data (str): The encoded image data.

        Returns:
            Dict[str, Any]: The payload for the API request.
        """
        return {
            "input_data": {
                "columns": ["image", "text"],
                "index": [0],
                "data": [[image_data, self.system_instructions or ""]]
            },
            "params": {}
        }
