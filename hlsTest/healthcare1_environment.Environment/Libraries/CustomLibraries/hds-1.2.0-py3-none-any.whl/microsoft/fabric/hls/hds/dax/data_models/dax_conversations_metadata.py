# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------


from dataclasses import dataclass
@dataclass
class DaxConversationsMetadata:
      """
      Represents the metadata of a DAX transcript.
      """
      # Represents the ID of the transcript
      transcript_id: str 
      # Represents the ID of the patient 
      patient_id: str 
      # Represents the ID of the encounter
      encounter_id: str
      # Represents the name of the practitioner
      practitioner_name: str
      # Represents the content of the DAX conversation 
      conversation: str  
      # Represents the path to the target file to write the output
      target_path:str
