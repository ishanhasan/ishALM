# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------


class EnrichmentUseCaseLoggingConstants:
    """
    This class contains logging constants for enrichment use cases.
    """

    AI_ENRICHMENT_RAW_ENRICHMENT_SAVE_ERROR="Error while saving raw enrichment"
    AI_ENRICHMENT_ENRICHMENT_MODEL_EXECUTION_ERROR="Error while executing model processor"
    AI_ENRICHMENT_CONVERSATIONAL_DATA_USECASE_INFO="Processing conversational data use case: {use_case_name}"
    AI_ENRICHMENT_TRANSFORMATION_RECORDS_INFO="Enrichment data transformation started with {records_count} responses."
    AI_ENRICHMENT_MODEL_PROCESS_COMPLETED_BATCH_INFO="Model execution completed for batch of documents {start_index} to {end_index}"
    