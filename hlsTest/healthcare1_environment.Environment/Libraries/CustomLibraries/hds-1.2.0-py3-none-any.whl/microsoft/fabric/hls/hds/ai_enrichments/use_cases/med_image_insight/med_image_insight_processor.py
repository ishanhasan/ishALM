import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Optional
from pyspark.sql import SparkSession
from microsoft.fabric.hls.hds.ai_enrichments.core.errors.model_processor_error import ModelProcessError
from microsoft.fabric.hls.hds.ai_enrichments.core.clients.client_retry_management.retry_client_manager import RetryClientManager
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_context import EnrichmentContext
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_response import EnrichmentResponse
from microsoft.fabric.hls.hds.ai_enrichments.core.base_classes.enrichment_model_processor_base import EnrichmentModelProcessorBase
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.constants.enrichment_use_case_logging_constants import EnrichmentUseCaseLoggingConstants as ELC
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import MSSparkUtilsClientBase
from microsoft.fabric.hls.hds.ai_enrichments.core.constants.ai_enrichments_constants import AIEnrichmentsConstants as EC
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.constants.enrichment_use_case_constants import EnrichmentUseCaseConstants as EUC
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.utils.enrichment_model_utils import EnrichmentModelUtils as ModelUtils
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC

class MedImageInsightProcessor(EnrichmentModelProcessorBase):
    """
    MedImageInsightProcessor is responsible for embedding images using the MedImageInsight model.
    """

    def __init__(self, spark: SparkSession,mssparkutils_client: Optional[MSSparkUtilsClientBase] = None):
        """
        Initializes the MedImageInsightsModelProcessor.

        Args:
            mssparkutils_client (MSSparkUtilsClientBase, optional): Spark utils client. Defaults to None.
        """
        super().__init__(mssparkutils_client)
        self.spark = spark
        self.client_manager = None
        self._logger = LoggingHelper.get_ai_enrichment_mii_execution__logger(
            self.spark,
            self.__class__.__name__,
            GC.LOGGING_LEVEL
        )
        
    def process(self, enrichment_generation_id: str, model_config:dict, document_inputs: List[EnrichmentContext], should_save_raw_response: bool, output_path: str) -> List[EnrichmentResponse]:
        """
        Processes the input documents to embed healthcare images and stores the result in a JSON file.

        Args:
            enrichment_generation_id (str): Unique identifier for the enrichment generation.
            model_config (dict): Model configuration dictionary.
            document_inputs (List[EnrichmentContext]): List of EnrichmentContext objects containing references to image files to be analyzed.
            should_save_raw_response (bool): Flag indicating whether to save the raw response.
            output_path (str): Path where the JSON output will be saved.

        Returns:
            List[EnrichmentResponse]: List of EnrichmentResponse objects containing the analysis results.
        """
        try:
            enrichment_responses = []
            self.model_config = model_config
            self._initialize_client_manager(self.model_config)
            raw_response_path = os.path.join(output_path, EC.ENRICHMENT_LANDING_ZONE_RAW_RESPONSE_PATH)
                    
            with ThreadPoolExecutor(max_workers=EC.DEFAULT_AI_ENRICHMENT_MII_EXECUTION_THREADS) as executor:
                futures = [
                    executor.submit(
                        self._process_batch,
                        enrichment_generation_id,
                        document_inputs,
                        i,
                        should_save_raw_response,
                        raw_response_path
                    )
                    for i in range(0, len(document_inputs), EUC.DEFAULT_AI_ENRICHMENT_EXECUTION_BATCH_SIZE)
                ]
                for future in as_completed(futures):
                    enrichment_responses.extend(future.result())
            return enrichment_responses
        except Exception as ex:
            raise ModelProcessError(str(ex)) from ex

    def _initialize_client_manager(self, model_config: dict) -> None:
        """
        Initializes the MedImagesInsight client.

        Args:
            model_config (dict): Configuration for the MedImageInsights model.
        """
        med_image_client=ModelUtils.initialize_med_image_client(self.spark,model_config,self._logger)
        
        self.client_manager = RetryClientManager(med_image_client)
       
    def _process_batch(
        self,
        enrichment_generation_id: str,
        document_inputs: List[EnrichmentContext],
        start_index: int,
        should_save_raw_response: bool,
        raw_response_output_path: str
    ) -> List[EnrichmentResponse]:
        """
        Processes a batch of documents, processing the enrichment results
        and formatting the results.
        """
        document_batch = document_inputs[start_index : start_index + EUC.DEFAULT_AI_ENRICHMENT_EXECUTION_BATCH_SIZE]
        
        file_path_contents = ModelUtils.extract_content_from_documents(document_batch)
        
        results = ModelUtils.analyze_images(self.client_manager,file_path_contents)
        
        self._logger.info(f"{ELC.AI_ENRICHMENT_MODEL_PROCESS_COMPLETED_BATCH_INFO.format(start_index=start_index, end_index=start_index + len(document_batch))}")

        return ModelUtils.format_analysis_results(
            self.mssparkutils_client,
            enrichment_generation_id,
            document_inputs,
            start_index,
            results,
            should_save_raw_response,
            raw_response_output_path
        )
        


