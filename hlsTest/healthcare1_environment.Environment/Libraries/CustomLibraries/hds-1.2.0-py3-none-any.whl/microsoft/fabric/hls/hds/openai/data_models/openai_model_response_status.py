# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
from dataclasses import dataclass
from typing import Optional
from microsoft.fabric.hls.hds.openai.data_models.openai_response_status import OpenAIResponseStatus

@dataclass
class OpenAIModelResponseStatus:
    """
    Status class represents the outcome of an operation with details about the result and any errors.

    Attributes:
        result (OpenAIResponseStatus): The result of the operation, default is OpenAIResponseStatus.SUCCESS.
        error_details (Optional[str]): Detailed information about any error that occurred, default is an empty string.
        error_type (Optional[str]): The type of error that occurred, default is an empty string.
    """
    result: OpenAIResponseStatus = OpenAIResponseStatus.SUCCESS
    error_details: Optional[str] = ""  
    error_type: Optional[str] = None
    retry_count: int = 0
    retriable: bool = None
    
    def __post_init__(self):
        """
        Initialize the OpenAIModelResponseStatus instance.
        """
        if self.retriable is None:
            self.retriable = self._is_retriable()
    
    def _is_retriable(self) -> bool:
            """
            Determine if the operation is retriable based on the status.

            Returns:
                bool: True if retriable, False otherwise.
            """
            # If the result is not a failure, the operation is not retriable
            if self.result != OpenAIResponseStatus.FAILURE:
                return False
            
            # If there is no error type or the error type is "BadRequestError", the operation is not retriable
            if not self.error_type or self.error_type == "BadRequestError":
                return False
            
            # The operation is retriable if the retry count is 3 or less
            return self.retry_count <= 3
    
    def to_dict(self) -> dict:
        """
        Converts the OpenAIModelResponseStatus instance to a dictionary.

        Returns:
            dict: A dictionary representation of the instance.
        """
        return {
            "result": self.result.name if hasattr(self.result, 'name') else str(self.result),  # Ensure result is converted to its name if it has one
            "error_details": self.error_details,  # Include error details in the dictionary
            "error_type": self.error_type , # Include error type in the dictionary
            "retry_count": self.retry_count,  # Include retry count in the dictionary    
            "retriable": self.retriable  # Include retriable status in the dictionary   
        }