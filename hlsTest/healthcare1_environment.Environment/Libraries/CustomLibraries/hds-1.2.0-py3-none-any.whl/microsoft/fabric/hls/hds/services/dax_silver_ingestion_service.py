# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
from functools import partial
import json
import os
from typing import Dict, Callable, Tuple, Union
from datetime import datetime

from pyspark.sql import SparkSession, DataFrame, types as T, functions as F, Window
from microsoft.fabric.hls.hds.structured_stream.delta_table_stream_reader import (
    DeltaTableStreamReader,
)
from microsoft.fabric.hls.hds.structured_stream.stream_orchestrator import (
    StreamOrchestrator,
    StreamingQueryInfo,
)
from microsoft.fabric.hls.hds.global_constants.global_constants import (
    GlobalConstants as GC,
)
from microsoft.fabric.hls.hds.flatten.constants import FlattenConstants as FC
from microsoft.fabric.hls.hds.global_constants.logging_constants import (
    LoggingConstants as LC,
)
from microsoft.fabric.hls.hds.flatten.normalization.normalization_manager import FlattenNormalization

from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.utils import FolderPath, Utils
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import (
    MSSparkUtilsClientBase,
)

from microsoft.fabric.hls.hds.utils.dataframe_utils import (
    get_or_create_managed_delta_table_using_path,
    append_to_delta_table_using_path,
    upsert_unique_to_delta_managed,
    validate_checkpoint,
)
from microsoft.fabric.hls.hds.utils.telemetry_reporter import TelemetryReporter
from microsoft.fabric.hls.hds.utils.parameter_service import ParameterService


telemetry_reporter = TelemetryReporter()

# Report SilverIngestionService module import
telemetry_reporter.report_usage(
    feature_name=GC.LIBRARY_IMPORT_FEATURE_NAME,
    activity_name=GC.DAX_SILVER_INGESTION_ACTIVITY_NAME,
)


class DaxSilverIngestionService:
    """
    The DaxSilverIngestionService is responsible for ingesting data from 
    a partitioned single source table (one for dax resources and one for enrichments) 
    and applying the dax transformation function for known resources.
    """
    def __init__(
        self,
        spark: SparkSession,
        workspace_name: str,
        solution_name: str,
        admin_lakehouse_name: str,
        inline_params: dict = None,
        one_lake_endpoint: str = GC.DEFAULT_ONE_LAKE_ENDPOINT,
        mssparkutils_client: MSSparkUtilsClientBase | None = None,
    ) -> None:
        
        """
        Args:
        spark: spark session
        - workspace_name: Name of the Fabric Workspace
        - solution_name: Name of the HDS-Healthcare data solutions OneLake workload solution
        - admin_lakehouse_name (str): The lakehouse name of where the administration configurations are located
        - inline_params (dict): Inline parameters that will overwrite and take precedence over the parameters in the administration lakehouse configuration
        - one_lake_endpoint (str): The one lake endpoint. Default is `onelake.dfs.fabric.microsoft.com`
        - mssparksutils_client (MSSparkUtilsClientBase): The mssparkutils client
        """

        def __check_udf_registered(udf_name: str) -> bool:
            """
            Check if UDF is registered in spark session
            """
            return udf_name in [
                func.name for func in self.spark.catalog.listFunctions()
            ]
       
        self.spark: SparkSession = spark
        self.workspace_name = workspace_name
        self.solution_name = solution_name
        self.one_lake_endpoint = one_lake_endpoint
        self.mssparkutils_client = Utils.get_mssparkutils_client(mssparkutils_client)
        
        self.parameter_service = ParameterService(
            spark=spark,
            workspace_name=workspace_name,
            admin_lakehouse_name=admin_lakehouse_name,
            one_lake_endpoint=self.one_lake_endpoint,
            mssparkutils_client=self.mssparkutils_client,
            inline_params=inline_params
        )

        self.source_lakehouse_name = self.parameter_service.get_foundation_config_value(GC.BRONZE_LAKEHOUSE_ID_KEY)
        self.target_lakehouse_name = self.parameter_service.get_foundation_config_value(GC.SILVER_LAKEHOUSE_ID_KEY)

        self.max_files_per_trigger = self.parameter_service.get_activity_config_value(
            GC.MAX_FILES_PER_TRIGGER_KEY, 
            GC.DEFAULT_NUMBER_OF_FILES_PER_TRIGGER_BRONZE, # 1000 
            "int"
        )

        self.max_bytes_per_trigger = self.parameter_service.get_activity_config_value(
            GC.MAX_BYTES_PER_TRIGGER_KEY, 
            GC.DEFAULT_NUMBER_OF_BYTES_PER_TRIGGER_BRONZE, 
            "int"
        )

        self.source_table_name = self.parameter_service.get_activity_config_value(
            GC.DAX_SOURCE_TABLE_NAME_KEY,
            GC.DEFAULT_DAX_TARGET_BRONZE_TABLE_NAME
        )
        
        self.source_enrichment_table_name = self.parameter_service.get_activity_config_value(
            GC.DAX_SOURCE_ENRICHMENT_TABLE_NAME_KEY,
            GC.DEFAULT_DAX_TARGET_BRONZE_ENRICHMENT_TABLE_NAME
        )

        self._logger = LoggingHelper.get_dax_silveringestion_logger(
            self.spark, self.__class__.__name__, GC.LOGGING_LEVEL
        )

        try:
            self.config_files_root_path = FolderPath.get_fabric_workload_files_root_path(
                    workspace_name=self.workspace_name,
                    one_lake_endpoint=self.one_lake_endpoint,
                    solution_name=self.solution_name
            )
            
            self.settings_file = self.parameter_service.get_activity_config_value(
                GC.DAX_CONFIG_PATH_KEY,
                f"{self.config_files_root_path}/{GC.DEFAULT_DAX_ENRICHMENT_CONFIG_PATH}"
            )

            self.target_tables_path = self.parameter_service.get_activity_config_value(
                GC.TARGET_TABLES_PATH_KEY,
                FolderPath.get_fabric_tables_path(
                    workspace_name=self.workspace_name,
                    one_lake_endpoint=self.one_lake_endpoint,
                    lakehouse_name=self.target_lakehouse_name,
                )
            )
            
            self.source_tables_path = self.parameter_service.get_activity_config_value(
                GC.SOURCE_TABLES_PATH_KEY,
                FolderPath.get_fabric_tables_path(
                    workspace_name=self.workspace_name,
                    one_lake_endpoint=self.one_lake_endpoint,
                    lakehouse_name=self.source_lakehouse_name,
                )
            )
            
            self.dax_resource_schema_path = self.parameter_service.get_activity_config_value(
                GC.DAX_RESOURCE_SCHEMA_PATH_KEY,
                FolderPath.get_fabric_workload_files_dax_resources_folder_path(root_path=self.config_files_root_path)
            )

            self.source_table_full_path = (
                f"{self.source_tables_path}/{self.source_table_name}"
            )

            self.source_enrichment_table_full_path = (
                f"{self.source_tables_path}/{self.source_enrichment_table_name}"
            )

            self.checkpoint_path = self.parameter_service.get_activity_config_value(
                GC.CHECKPOINT_PATH_KEY,
                FolderPath.get_fabric_workload_files_checkpoint_folder_path(root_path=self.config_files_root_path,
                                                                            checkpoint_folder_name=self.target_lakehouse_name)
            )

            self.status_table_name = f"{GC.DEFAULT_DAX_TRANSCRIPT_STATUS_TABLE_NAME}"

            self.status_table_full_path = (
                f"{self.target_tables_path}/{self.status_table_name}"
            )
           
            self.max_structured_streaming_queries = self.parameter_service.get_activity_config_value(
                GC.MAX_STRUCTURED_STREAMING_QUERIES_KEY, 
                GC.DEFAULT_NUMBER_OF_MAX_STREAMING_QUERIES_BRONZE, # 1
                "int"
            )

            if not __check_udf_registered(FC.NORM_UDF_NORM_DATE):
                self.spark.udf.register(
                    FC.NORM_UDF_NORM_DATE,
                    FlattenNormalization.normalize_date,
                    T.TimestampType(),
                )

            self._initialize_progress_table()

        except Exception as ex:
            self._logger.error(message=str(ex))
            raise


    def _progress_table_schema(self):
        """
        Returns the schema for the progress table.
        """

        schema = T.StructType(
            [
                T.StructField("transcriptId", T.StringType(), True),
                T.StructField("use_case", T.StringType(), True),
                T.StructField("raw_model_response", T.StringType(), True),
                T.StructField("status", T.StringType(), True),
                T.StructField("status_message", T.StringType(), True),
                T.StructField(
                    "retries_count", T.IntegerType(), True
                ),
                T.StructField("retriable", T.BooleanType(), True),
                T.StructField("updated_date", T.TimestampType(), True),
            ]
        )
        return schema

    def _initialize_progress_table(self):
        """
        Initializes the progress table.
        If the table does not exist, it will be created.
        """
        self.progress_table_delta = get_or_create_managed_delta_table_using_path(
            spark_session=self.spark,
            data_manager_logger=self._logger,
            df_to_process=self.spark.createDataFrame(
                self.spark.sparkContext.emptyRDD(), self._progress_table_schema()
            ),
            delta_table_path=self.status_table_full_path,
        )

    def _stream_resource(
        self,
        resource_name: str,
        resource_path: str,
        target_table_path: str,
        resource_fn: Callable,
        streaming_df: DataFrame,
    ) -> StreamingQueryInfo | None:
        """
        Stream a resource and apply the resource function to the stream

        Args:
        - resource_name: str - The name of the resource
        - resource_path: str - The path to the resource
        - resource_fn: Callable - The function to apply to the resource
        - streaming_df: DataFrame - The streaming DataFrame
        Returns:
        - StreamingQueryInfo | None: The streaming query info
        """
        try:
            resource_schema = self._get_resource_schema(resource_name)
            if resource_schema is None:
                self._logger.warning(
                    LC.DAX_INGESTION_TRANSFORMATION_NOSCHEMA.format(
                        resource_name=resource_name, source_table_path=resource_path
                    )
                )
                return None

            resource_checkpoint_path = (
                f"{self.checkpoint_path}/dax_silver/{resource_name}"
            )

            batch_fn = partial(
                resource_fn,
                resource=resource_name,
                resource_schema=resource_schema,
            )
            
            validate_checkpoint(spark=self.spark,
                logger=self._logger,
                target_table_path=target_table_path,
                checkpoint_path=resource_checkpoint_path,
                mssparkutils_client=self.mssparkutils_client,
                resource_name=resource_name)

            streaming_query_info = StreamingQueryInfo(
                query_name=f"{self.source_table_full_path}_{self.target_tables_path}_{resource_name}",
                checkpoint_path=resource_checkpoint_path,
                streaming_dataframe=streaming_df,
                batch_fn=batch_fn,
                data_format="delta",
            )
            return streaming_query_info
        except Exception as e:
            self._logger.error(
                LC.DAX_INGESTION_FAILED_TO_PROCESS_GENERIC_RESOURCE_ERROR_MSG.format(
                    resource_name=resource_name, exception_details=str(e)
                )
            )
        return None

    def ingest(self) -> None:
        """
        Ingest data from a partitioned single source table and apply the dax transformation function for known resources.

        This method sets up streaming on a single source table that is already partitioned by resource type,
        and applies the internal dax transformation function to each partition.

        """
        telemetry_reporter.report_usage(
            feature_name=GC.LIBRARY_USAGE_FEATURE_NAME,
            activity_name=GC.DAX_SILVER_INGESTION_ACTIVITY_NAME,
        )

        self._logger.info(f"{LC.DAX_SILVER_INGESTION_START_INFO_MSG}")

        # Set up streaming on all source tables
        stream_orchestrator = StreamOrchestrator(
            spark=self.spark,
            max_structured_streaming_queries=self.max_structured_streaming_queries,
        )
        delta_table_stream_reader = self.__get_delta_table_stream_reader()

        # process dax tables

        # Get all the resource types from the source table (identified by the parent folder column name)
        resource_types = (
            self.spark.sql(
                f"SELECT DISTINCT `{GC.DAX_BRONZE_PARENT_FOLDER_COLUMN}` FROM delta.`{self.source_table_full_path}`"
            )
            .rdd.flatMap(lambda x: x)
            .collect()
        )

        streaming_dataframe = delta_table_stream_reader.set_up_streaming(
            delta_table_path=self.source_table_full_path
        )

        for resource in resource_types:
            # get stream for the particular dax resource
            streaming_df_resource = streaming_dataframe.filter(
                streaming_dataframe[GC.DAX_BRONZE_PARENT_FOLDER_COLUMN] == resource
            )
            
            target_table_path = f"{self.target_tables_path}/{GC.DEFAULT_DAX_SILVER_PREFIX}{resource}"

            # process generic dax resource
            stream_query_info = self._stream_resource(
                resource_name=resource,
                resource_path=self.source_table_full_path,
                target_table_path=target_table_path,
                resource_fn=self._process_generic_dax_resource,
                streaming_df=streaming_df_resource,
            )
            if stream_query_info:
                stream_orchestrator.enqueue_streaming_query(stream_query_info)

        try:
            settings_str = Utils.load_config_file(
                self.spark, self.settings_file)
            self.settings = json.loads(settings_str)
        except Exception as e:
            self._logger.error(
                f"Error loading settings file {self.settings_file}: {e}")
            raise e

        streaming_dataframe_enrichment = delta_table_stream_reader.set_up_streaming(
            delta_table_path=self.source_enrichment_table_full_path
        )
        
        enrichemnt_stream_query_info = self._stream_resource(
            resource_name=GC.DAX_ENRICHMENT_RESOURCE_TYPE,
            resource_path=self.source_enrichment_table_full_path,
            target_table_path=self.status_table_full_path,
            resource_fn=self._process_enrichments,
            streaming_df=streaming_dataframe_enrichment,
        )

        if enrichemnt_stream_query_info:
            stream_orchestrator.enqueue_streaming_query(
                enrichemnt_stream_query_info)

        stream_orchestrator.await_all()
        self._logger.info(f"{LC.COMPLETED_EXECUTION_INFO_MSG}")

    def __get_delta_table_stream_reader(self) -> DeltaTableStreamReader:

        stream_reader_kwargs = {}

        self._logger.info(
            f"The maxBytesPerTrigger is set to {self.max_bytes_per_trigger}.The maxFilesPerTrigger is set to {self.max_files_per_trigger}."
        )
        if self.max_bytes_per_trigger:
            stream_reader_kwargs["maxBytesPerTrigger"] = self.max_bytes_per_trigger

        if self.max_files_per_trigger:
            stream_reader_kwargs["maxFilesPerTrigger"] = self.max_files_per_trigger

        return DeltaTableStreamReader(self.spark, **stream_reader_kwargs)

    def _get_resource_schema(self, resource: str) -> Union[T.StructType, None]:
        resource_path = (
            f"{self.dax_resource_schema_path}/{resource.lower()}.json"
        )

        if not Utils.file_exists(resource_path, self.mssparkutils_client):
            return None

        schema_str = Utils.load_config_file(self.spark, resource_path)
        schema_json = json.loads(schema_str)
        return T.StructType.fromJson(schema_json)

    def _process_dax_transcript_resource(
        self, df: DataFrame, unique_columns: list, source_modified_on_column: str
    ) -> Tuple[DataFrame, list, str]:
        """
        Process the DAX transcript resource
        """

        def process_transcript(transcript):
            """
            Process the transcript data
            Args:
                transcript: The transcript data

            Returns:
                Tuple[str, str, float]: The conversation, webVTT, and total transcription time
            """
            time_format = "%H:%M:%S.%f"
            conversation = ""
            webVTT = None
            total_transcription_time = 0.0

            if transcript is not None:
                # Process conversation
                conversation = "\n".join(
                    f"{turn['speaker']}: {turn['text']}" for turn in transcript["turns"]
                )
                webVTT = transcript["webVTT"]

                # Calculate transcription time
                try:
                    start_time = datetime.strptime(
                        transcript["turns"][0]["startTime"], time_format
                    )
                    end_time = datetime.strptime(
                        transcript["turns"][-1]["endTime"], time_format
                    )
                    time_difference = end_time - start_time
                    total_transcription_time = time_difference.total_seconds() / 60
                except Exception:
                    total_transcription_time = 0.0

            return conversation, webVTT, total_transcription_time

        # Define the UDF
        process_transcript_udf = F.udf(
            process_transcript,
            T.StructType(
                [
                    T.StructField("content", T.StringType(), True),
                    T.StructField("timeTranscript", T.StringType(), True),
                    T.StructField("totalTranscriptionTime",
                                  T.DoubleType(), True),
                ]
            ),
        )

        # Apply the UDF to the 'transcript' column to get the new columns
        dax_data_df = df.withColumn(
            "transcript_data", process_transcript_udf(F.col("transcript"))
        )

        # Now extract each field from the struct returned by the UDF
        dax_data_df = (
            dax_data_df.withColumn("content", F.col("transcript_data.content"))
            .withColumn("timeTranscript", F.col("transcript_data.timetranscript"))
            .withColumn(
                "totalTranscriptionTime",
                F.col("transcript_data.totalTranscriptionTime"),
            )
            .withColumn("encounterId", F.col("encounter.external_encounter_id"))
            .withColumn("patientId", F.col("encounter.patient.external_patient_id"))
            .withColumn("practitionerName", F.col("encounter.practitioner.full_name"))
            .withColumn("transcriptId",F.col(GC.DAX_BRONZE_FILENAME_NO_EXTENSION_COLUMN))
        )
        dax_data_df = dax_data_df.drop("transcript_data")

        return dax_data_df, unique_columns, source_modified_on_column

    def _process_generic_dax_resource(
        self,
        df: DataFrame,
        batchId: int,
        resource: str,
        resource_schema: T.StructType,
    ) -> None:
        """
        Process the generic DAX resource

        Args:
        - df: DataFrame - The DataFrame to process
        - batchid: int - The batch id
        - resource: str - The resource name
        - resource_schema: T.StructType - The resource schema
        """
        parsed_df = df.withColumn(
            "parsed_data",
            F.from_json(F.col(GC.DAX_BRONZE_DATA_COLUMN), resource_schema),
        )
        df = parsed_df.select(
            *[
                F.col(f"parsed_data.{col_name}").alias(col_name)
                for col_name in resource_schema.fieldNames()
            ],  # Extract all columns from parsed_data
            GC.DAX_BRONZE_FULL_FILE_PATH_COLUMN,  # Keep the original 'file_path' column
            GC.DAX_BRONZE_FILENAME_NO_EXTENSION_COLUMN,  # Keep the original 'filename_no_extension' column
            "createdDatetime",  # Keep the original 'createdDatetime' column
        )

        unique_columns = [GC.DAX_BRONZE_FILENAME_NO_EXTENSION_COLUMN]
        source_modified_on_column = "createdDatetime"

        # special processing for transcript resource
        if resource.casefold() == GC.DAX_TRANSCRIPT_RESOURCE_TYPE.casefold(): 
            # Process the transcript resource
            df, unique_columns, source_modified_on_column = (
                self._process_dax_transcript_resource(
                    df, unique_columns, source_modified_on_column
                )
            )

        # Append the data to the target table
        upsert_unique_to_delta_managed(
            spark_session=self.spark,
            data_manager_logger=self._logger,
            df_to_process=df,
            delta_table_path=f"{self.target_tables_path}/{GC.DEFAULT_DAX_SILVER_PREFIX}{resource}",
            unique_columns=unique_columns,
            source_modified_on_column= source_modified_on_column,
        )

    def _find_use_case(self, use_case_table_name: str) -> Dict | None:
        """
        Find the use case by the use casetable  name

        Args:
        - use_case_name: str - The use case table name

        Returns:
        - Dict: The use case
        """
        for use_case_section in self.settings:
            if use_case_section["use_case_name"] == use_case_table_name:
                return use_case_section
        return None

    def _read_schema_from_file(self, schema_file_path):
        try:
            schema_str = Utils.load_config_file(self.spark, schema_file_path)
            schema_dict = json.loads(schema_str)
            return T.StructType.fromJson(schema_dict)
        except Exception as e:
            self._logger.error(
                f"Error reading schema from file {schema_file_path}: {e}"
            )
            raise e

    def _process_enrichments(
        self, df: DataFrame, batchid: int, resource: str, resource_schema: T.StructType
    ) -> None:
        """
        Process the enrichments

        Args:
        - df: DataFrame - The DataFrame to process
        - batchid: int - The batch id
        - resource: str - The resource name
        - resource_schema: T.StructType - The resource schema
        """
        parsed_df = df.withColumn(
            "parsed_data",
            F.from_json(F.col(GC.DAX_BRONZE_DATA_COLUMN), resource_schema),
        )
        df = parsed_df.select(
            *[
                F.col(f"parsed_data.{col_name}").alias(col_name)
                for col_name in resource_schema.fieldNames()
            ],  # Extract all columns from parsed_data
            GC.DAX_BRONZE_VALUE_COLUMN,
            GC.DAX_BRONZE_DATA_COLUMN,
        )

        # Create the status table
        status_df = df.select(
            "transcriptId",
            F.col(GC.DAX_BRONZE_DATA_COLUMN).alias("raw_model_response"),
            F.col("use_case_name").alias("use_case"),
            F.col("status.result").alias("status"),
            F.col("status.error_details").alias("status_message"),
            F.col("status.retry_count").alias("retries_count"),
            F.col("status.retriable").alias("retriable"),
            F.current_timestamp().alias("updated_date"),
        )
        
        # first rank = success, then maximum retries_count
        
        # This is to address use case when we recreate bronze table and we 
        # have multiple records for the same transcriptId for the same use_case, 
        # part of which have failed status and thus have re-processed
        # we want to keep only the latest status for each transcriptId
        
        window_spec = Window.partitionBy("transcriptId","use_case").orderBy(
            F.desc(F.when(F.lower(F.col("status")) == "success", 1).otherwise(0)),
            F.desc("retries_count"),
        )
        
        ranked_status_df = status_df.withColumn(
            "rank", 
            F.row_number().over(window_spec)
        )
        
        filtered_status_df = ranked_status_df.filter(F.col("rank") == 1).drop("rank")


        upsert_unique_to_delta_managed(
            spark_session=self.spark,
            data_manager_logger=self._logger,
            df_to_process=filtered_status_df,
            delta_table_path=f"{self.status_table_full_path}",
            unique_columns=["transcriptId", "use_case"],
            source_modified_on_column="updated_date",
        )

        use_cases_list = (
            df.select("use_case_name").distinct().rdd.flatMap(lambda x: x).collect()
        )

        for use_case in use_cases_list:
            use_case_df = df.filter(df["use_case_name"] == use_case)
            self._logger.info(
                f"Processing use case: {use_case}. Found {use_case_df.count()} records."
            )
            section = self._find_use_case(use_case)
            if section:
                self._logger.info(f"Config section found for use case: {use_case}")
                # TODO table_schema to const
                schema_file_path = os.path.join(
                    os.path.dirname(self.settings_file), f'{section["table_schema"]}'
                )
                table_schema = self._read_schema_from_file(schema_file_path)
                multi_records = section.get("multiple_records_for_array", False)
                use_case_tname = section["table_name"]

                use_case_df = use_case_df.withColumn(
                    "parsed_value",
                    F.from_json(F.col(GC.DAX_BRONZE_VALUE_COLUMN), table_schema),
                )
                
                # Filter out records with failed status even if they have some values persisted
                use_case_df = use_case_df.filter(F.lower(F.col("status.result")) == "success")
                
                self._logger.info(
                    f"After applying filter for use case: {use_case}. We have  {use_case_df.count()} records."
                )
                
                self._logger.info(f"Multi records: {multi_records}")

                if multi_records:
                    first_field = table_schema.fields[0]
                    if isinstance(first_field.dataType, T.ArrayType):
                        use_case_df = use_case_df.withColumn(
                            "exploded",
                            F.explode(F.col(f"parsed_value.{first_field.name}")),
                        )
                        if isinstance(first_field.dataType.elementType, T.StructType):
                            # Extract fields from the struct inside the array
                            array_fields = [
                                F.col(f"exploded.{col.name}").alias(col.name)
                                for col in first_field.dataType.elementType.fields
                            ]
                        else:
                            # Handle arrays with simple types like strings or integers
                            array_fields = [F.col("exploded").alias(first_field.name)]
                        use_case_df = use_case_df.select(
                            *array_fields,
                            "transcriptId",
                            "patientId",
                            "encounterId",
                            "practitionerName",
                            "use_case_name",
                            "model_name",
                            "model_version",
                        )
                    else:
                        self._logger.error(
                            f"Field {first_field.name} is not an array for use case where multi_records is set to True."
                        )
                else:
                    use_case_df = use_case_df.select(
                        *[
                            F.col(f"parsed_value.{col_name}").alias(col_name)
                            for col_name in table_schema.fieldNames()
                        ],
                        "transcriptId",
                        "patientId",
                        "encounterId",
                        "practitionerName",
                        "use_case_name",
                        "model_name",
                        "model_version",
                    )

                if use_case_df is not None and use_case_df.count() > 0:
                    append_to_delta_table_using_path(
                        delta_table_path=f"{self.target_tables_path}/{use_case_tname}",
                        df_to_process=use_case_df,
                        logger=self._logger,
                    )
                    # upsert_unique_to_delta_managed(
                    #     spark_session = self.spark,
                    #     data_manager_logger = self._logger,
                    #     df_to_process = df,
                    #     delta_table_path = f"{self.target_tables_path}/{use_case_tname}",
                    #     unique_columns = ["recordingStableId"],
                    #     source_modified_on_column = "dateCreated",
                    # )
