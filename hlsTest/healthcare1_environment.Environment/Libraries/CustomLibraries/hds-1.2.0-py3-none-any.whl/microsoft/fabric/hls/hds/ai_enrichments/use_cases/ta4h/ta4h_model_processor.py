import json
import os
from pyspark.sql import SparkSession
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Optional
from azure.ai.textanalytics import TextAnalyticsClient
from azure.core.credentials import AzureKeyCredential
from microsoft.fabric.hls.hds.ai_enrichments.core.clients.client_retry_management.retry_client_manager import RetryClientManager
from microsoft.fabric.hls.hds.ai_enrichments.core.clients.models.enrichment_api_response import EnrichmentAPIResponse
from microsoft.fabric.hls.hds.ai_enrichments.core.clients.ta4h_client_orchestrator import TA4hClientOrchestrator
from microsoft.fabric.hls.hds.ai_enrichments.core.errors.enrichment_api_response_error import EnrichmentAPIResponseError
from microsoft.fabric.hls.hds.ai_enrichments.core.errors.model_processor_error import ModelProcessError
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_context import EnrichmentContext
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_response import EnrichmentResponse
from microsoft.fabric.hls.hds.ai_enrichments.core.base_classes.enrichment_model_processor_base import EnrichmentModelProcessorBase
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import MSSparkUtilsClientBase
from microsoft.fabric.hls.hds.ai_enrichments.core.constants.ai_enrichments_constants import AIEnrichmentsConstants as EC
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.constants.enrichment_use_case_constants import EnrichmentUseCaseConstants as EUC
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.constants.enrichment_use_case_logging_constants import EnrichmentUseCaseLoggingConstants as ELC
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC
from microsoft.fabric.hls.hds.ai_enrichments.use_cases.common.utils.enrichment_model_utils import EnrichmentModelUtils as ModelUtils

class TA4HModelProcessor(EnrichmentModelProcessorBase):
    """
    TA4HModelProcessor is responsible for analyzing healthcare entities using Azure Text Analytics.
    """

    def __init__(self, spark: SparkSession, mssparkutils_client: Optional[MSSparkUtilsClientBase] = None):
        """
        Initializes the TA4HModelProcessor.

        Args:
            mssparkutils_client (MSSparkUtilsClientBase, optional): Spark utils client. Defaults to None.
        """
        super().__init__(mssparkutils_client)
        self.spark = spark
        self._logger = LoggingHelper.get_ai_enrichment_ta4h_execution__logger(
            self.spark,
            self.__class__.__name__,
            GC.LOGGING_LEVEL
        )
        
    def process(self, enrichment_generation_id: str,model_config:dict, enrichment_contexts: List[EnrichmentContext], should_save_raw_response: bool, output_path: str) -> List[EnrichmentResponse]:
        """
        Processes the input documents to analyze healthcare entities and stores the result in a JSON file.

        Args:
            enrichment_generation_id (str): Unique identifier for the enrichment generation.
            model_config (dict): Configuration for the Text Analytics model.
            enrichment_contexts (List[EnrichmentContext]): List of EnrichmentContext objects containing references to text files to be analyzed.
            should_save_raw_response (bool): Flag indicating whether to save the raw response.
            output_path (str): Path where the JSON output will be saved.

        Returns:
            List[EnrichmentResponse]: List of EnrichmentResponse objects containing the analysis results.
        """
        try:
            self.model_config = model_config
            self._initialize_client_manager(self.model_config)
            enrichment_raw_responses = []
            raw_response_output_path = os.path.join(output_path, EC.ENRICHMENT_LANDING_ZONE_RAW_RESPONSE_PATH)
            with ThreadPoolExecutor(max_workers=EUC.DEFAULT_AI_ENRICHMENT_EXECUTION_THREADS) as executor:
                    futures = [
                        executor.submit(
                            self._analyze_entities_in_batches,
                            enrichment_generation_id,
                            enrichment_contexts,
                            i,
                            should_save_raw_response,
                            raw_response_output_path
                        )
                        for i in range(
                            0,
                            len(enrichment_contexts),
                            EUC.DEFAULT_AI_ENRICHMENT_EXECUTION_BATCH_SIZE
                        )
                    ]
                    
            for future in as_completed(futures):
                   if future.exception() is None:
                        result= future.result()
                        if result is not None:
                            enrichment_raw_responses.extend(future.result())
                   else:
                       exception_message=future.exception()
                       api_response_error = EnrichmentAPIResponseError(f"{ELC.AI_ENRICHMENT_ENRICHMENT_MODEL_EXECUTION_ERROR}: { type(exception_message).__name__}:{exception_message} ")
                       self._logger.error(api_response_error)         
            return enrichment_raw_responses
        except Exception as e:
            raise ModelProcessError(f"{ELC.AI_ENRICHMENT_ENRICHMENT_MODEL_EXECUTION_ERROR}: {e}") from e


    def _initialize_client_manager(self, model_config: dict) -> None:
        """
        Initializes the Text Analytics client.

        Args:
            model_config (dict): Configuration for the Text Analytics model.
        """
        # Initialize the Text Analytics client with the provided endpoint and API key
        ta4h_client_orchestrator = TA4hClientOrchestrator(
            api_endpoint=model_config.get("api_endpoint"),
            api_key=model_config.get("api_key"),
            logger=self._logger
        )
        # Create a RetryClientManager instance to handle retries for the Text Analytics client
        self.client_manager = RetryClientManager(ta4h_client_orchestrator,logger=self._logger)
        

    def _extract_documents_text(self, document_inputs: List[EnrichmentContext]) -> List[str]:
        """
        Extracts text contents from the document input.

        Args:
            document_inputs (List[EnrichmentInput]): List of EnrichmentInput objects containing references to text files to be analyzed.

        Returns:
            List[str]: List of text contents from the input documents.
        """
        return [text_file.content for enrichment_context in document_inputs for text_file in enrichment_context.enrichment_input.text_file_references]

    def _analyze_entities(self, document_texts: List[str]):
        """
        Analyzes healthcare entities in the input documents.

        Args:
            document_texts (List[str]): List of input documents to be analyzed.

        Returns:
            The result of the healthcare entity analysis.
        """
        # Call the execute_method from the client_manager to start analyzing healthcare entities
        execute_analyze = self.client_manager.execute_client()
        
        enrichment_model_response:EnrichmentAPIResponse = execute_analyze(documents=document_texts)
       
        return enrichment_model_response

    def _format_model_raw_outputs(self, enrichment_generation_id: str, document_inputs: List[EnrichmentContext], start_index: int, document_text_contents: List[str], results:EnrichmentAPIResponse, should_save_raw_response: bool, raw_response_output_path: str) -> List[EnrichmentResponse]:
        """
        Prepares the JSON output from the analysis result.

        Args:
            enrichment_generation_id (str): Unique identifier for the enrichment generation.
            document_inputs (List[EnrichmentInput]): List of EnrichmentInput objects.
            start_index (int): The starting index of the current batch.
            document_text_contents (List[str]): List of text contents from the input documents.
            results: The result of the healthcare entity analysis.
            should_save_raw_response (bool): Flag indicating whether to save the raw response.
            raw_response_output_path (str): Path where the raw response will be saved.

        Returns:
            List[EnrichmentResponse]: List of EnrichmentResponse objects containing the analysis results.
        """
        formatted_output_results = []
        if results.is_completed:
            for doc in results.data:
                if not doc.is_error:
                    formatted_result = {
                        "id": doc.id,
                        "entities": [
                            {
                                "text": entity.text,
                                "category": entity.category,
                                "subcategory": entity.subcategory,
                                "confidence_score": entity.confidence_score,
                                "offset": entity.offset,
                                "length": entity.length,
                                "data_sources": [
                                    {
                                        "name": source.name,
                                        "entity_id": source.entity_id
                                    } for source in entity.data_sources or []
                                ]
                            } for entity in doc.entities or []
                        ],
                        "relations": [
                            {
                                "relation_type": relation.relation_type,
                                "roles": [
                                    {
                                        "name": role.name,
                                        "entity": role.entity.text
                                    } for role in relation.roles or []
                                ]
                            } for relation in doc.entity_relations or []
                        ]
                    }
                    enrichment_response = EnrichmentResponse(id=document_inputs[start_index + int(doc.id)].enrichment_input.text_file_references[0].id, content=formatted_result)
                    formatted_output_results.append(enrichment_response)
                    if should_save_raw_response:
                        ModelUtils.save_model_raw_response(self.mssparkutils_client,enrichment_generation_id, enrichment_response, raw_response_output_path)
        else:
            self._logger.error(f"{ELC.AI_ENRICHMENT_ENRICHMENT_MODEL_EXECUTION_ERROR}: {results.error_message}")
                    
        return formatted_output_results

    def _analyze_entities_in_batches(self, enrichment_generation_id: str, document_inputs: List[EnrichmentContext], start_index: int, should_save_raw_response: bool, raw_response_output_path: str) -> List[EnrichmentResponse]:
        """
        Executes the analysis for a batch of documents.

        Args:
            enrichment_generation_id (str): Unique identifier for the enrichment generation.
            document_inputs (List[EnrichmentInput]): List of EnrichmentInput objects.
            start_index (int): The starting index of the current batch.
            should_save_raw_response (bool): Flag indicating whether to save the raw response.
            raw_response_output_path (str): Path where the raw response will be saved.

        Returns:
            List[EnrichmentResponse]: List of EnrichmentResponse objects containing the analysis results.
        """
        document_text_contents = self._extract_documents_text(
            document_inputs[start_index:start_index + EUC.DEFAULT_AI_ENRICHMENT_EXECUTION_BATCH_SIZE]
        )
        results = self._analyze_entities(document_text_contents)

        if results is None:
            return []

        return self._format_model_raw_outputs(
            enrichment_generation_id, 
            document_inputs, 
            start_index, 
            document_text_contents, 
            results, 
            should_save_raw_response, 
            raw_response_output_path
        )
