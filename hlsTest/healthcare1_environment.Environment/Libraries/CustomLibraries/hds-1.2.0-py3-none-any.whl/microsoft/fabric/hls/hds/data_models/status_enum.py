from enum import Enum

class Status(Enum):
    Success = 0
    Fail = 1