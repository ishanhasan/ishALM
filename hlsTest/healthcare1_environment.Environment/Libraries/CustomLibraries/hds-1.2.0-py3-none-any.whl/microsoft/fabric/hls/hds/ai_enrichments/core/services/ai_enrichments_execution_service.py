# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
from concurrent.futures import ThreadPoolExecutor
import json
import os
from typing import Any, Dict, List, Literal, Type, Optional
import uuid
from microsoft.fabric.hls.hds.ai_enrichments.core.errors.execution_service_error import ExecutionServiceError
from microsoft.fabric.hls.hds.ai_enrichments.core.errors.model_configuration_error import ModelConfigurationError
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.metadata.enrichment_input_mapping import EnrichmentInputMapping
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_context import EnrichmentContext
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_result import EnrichmentResult
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC
from pyspark.sql import SparkSession
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.metadata.enrichment_view import EnrichmentView
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.metadata.generated_enrichment import GeneratedEnrichment
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_input import EnrichmentInput
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.enrichment_result import EnrichmentResult
from microsoft.fabric.hls.hds.ai_enrichments.core.models.enrichment.output.resource_reference import ResourceReference
from microsoft.fabric.hls.hds.ai_enrichments.core.base_classes.enrichment_model_processor_base import EnrichmentModelProcessorBase
from microsoft.fabric.hls.hds.ai_enrichments.core.base_classes.enrichment_transformer_base import EnrichmentTransformerBase
from microsoft.fabric.hls.hds.ai_enrichments.core.utils.ai_enrichments_utils import AIEnrichmentsUtils
from microsoft.fabric.hls.hds.ai_enrichments.core.services.ai_enrichments_metadata_service import AIEnrichmentsMetaDataService
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.parameter_service import ParameterService
from microsoft.fabric.hls.hds.utils.telemetry_reporter import TelemetryReporter
from microsoft.fabric.hls.hds.utils.utils import FolderPath, Utils
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import MSSparkUtilsClientBase
from microsoft.fabric.hls.hds.ai_enrichments.core.constants.ai_enrichments_logging_constants import AIEnrichmentsLoggingConstants as ELC
from microsoft.fabric.hls.hds.ai_enrichments.core.constants.ai_enrichments_constants import AIEnrichmentsConstants as EC

telemetry_reporter = TelemetryReporter()

class AIEnrichmentsExecutionService:
    """
    AIEnrichmentsExecutionService is responsible for managing the enrichment process within the healthcare data platform.
    """

    def __init__(
        self,
        spark: SparkSession,
        workspace_name: str,
        solution_name: str,
        admin_lakehouse_name: str,
        enrichment_model_processor: Type[EnrichmentModelProcessorBase],
        enrichment_transformer: Type[EnrichmentTransformerBase],
        aienrichment_metadata_service: AIEnrichmentsMetaDataService,
        inline_params: Optional[Dict[str, Any]] = None,
        one_lake_endpoint: str = GC.DEFAULT_ONE_LAKE_ENDPOINT,
        output_format:Literal["json","ndjson"] = "ndjson",
        mssparkutils_client: Optional[MSSparkUtilsClientBase] = None
    ) -> None:
        """
        Initializes the AIEnrichmentsExecutionService with the provided parameters.

        Args:
            spark (SparkSession): The Spark session to use for data processing.
            workspace_name (str): The name of the workspace.
            solution_name (str): The name of the solution.
            admin_lakehouse_name (str): The name of the admin lakehouse.
            enrichment_model_processor (Type[EnrichmentModelProcessorBase]): The processor for enrichment models.
            enrichment_transformer (Type[EnrichmentTransformerBase]): The transformer for enrichment data.
            aienrichment_metadata_service (AIEnrichmentsMetaDataService): The service for enrichment metadata operations.
            inline_params (Optional[Dict[str, Any]], optional): Custom inline parameters for activity configuration.
            one_lake_endpoint (str, optional): The endpoint for OneLake. Defaults to GC.DEFAULT_ONE_LAKE_ENDPOINT.
            output_format (Literal["json","ndjson"], optional): The output format. Defaults to "ndjson".
            mssparkutils_client (Optional[MSSparkUtilsClientBase], optional): The MSSparkUtils client. Defaults to None.
            new_param (Optional[Any], optional): New optional parameter to demonstrate docstring update.

        Raises:
            Exception: If an error occurs during initialization.
        """
        try:
            self.spark = spark
            self.workspace_name = workspace_name
            self.solution_name = solution_name
            self.mssparkutils_client = Utils.get_mssparkutils_client(mssparkutils_client)
            self.one_lake_endpoint = one_lake_endpoint
            self.parameter_service = ParameterService(
                spark=spark,
                workspace_name=workspace_name,
                admin_lakehouse_name=admin_lakehouse_name,
                one_lake_endpoint=self.one_lake_endpoint,
                mssparkutils_client=self.mssparkutils_client,
                inline_params=inline_params,
            )
            self.target_lakehouse_name = self.parameter_service.get_foundation_config_value(GC.BRONZE_LAKEHOUSE_ID_KEY)
            self.silver_lakehouse_id = self.parameter_service.get_foundation_config_value(
                GC.SILVER_LAKEHOUSE_ID_KEY
            )
            self.enrichment_records_limit = int(self.parameter_service.get_activity_config_value(
                EC.ENRICHMENT_RECORDS_LIMIT_KEY, EC.ENRICHMENT_RECORDS_LIMIT_DEFAULT_VALUE
            ))
            
            self.enrichment_output_records_limit_per_file = int(self.parameter_service.get_activity_config_value(
                EC.ENRICHMENT_RECORDS_OUTPUT_LIMIT_KEY, EC.ENRICHMENT_RECORDS_OUTPUT_LIMIT_DEFAULT_VALUE
            ))

            self.should_save_model_raw_response = bool(self.parameter_service.get_activity_config_value(
                EC.ENRICHMENT_RECORDS_SAVE_RAW_RESPONSE_KEY, False
            ))
            
            self.enrichment_model_defintion_excluded_keys = str(self.parameter_service.get_activity_config_value(
                EC.ENRICHMENT_MODEL_CONFIG_EXCLUDE_KEYS, EC.ENRICHMENT_MODEL_CONFIG_EXCLUDE_VALUES
            ))
          
            
            self.enrichment_metadata_service = aienrichment_metadata_service
            self.enrichment_transformer = enrichment_transformer
            self.enrichment_model_processor = enrichment_model_processor
            self.landing_zone_lakehouse_id = self.parameter_service.get_activity_config_value(
                EC.ENRICHMENT_LANDING_ZONE_LAKEHOUSE_ID_KEY, self.target_lakehouse_name
            )
            self.execution_threads = self.parameter_service.get_activity_config_value(
                    EC.DEFAULT_AI_ENRICHMENT_EXECUTION_THREADS_LIMIT_KEY,
                    EC.DEFAULT_AI_ENRICHMENT_EXECUTION_THREADS,
                    "int"
            )
            
            self.metadata_lakehouse_id = (self.parameter_service.get_foundation_config_value(EC.ENRICHMENT_METADATA_LAKEHOUSE_ID_KEY))
         
            self._logger = LoggingHelper.get_ai_enrichment_execution__logger(
                self.spark, self.__class__.__name__, GC.LOGGING_LEVEL
            )
            self.output_format=output_format
            
             # Retrieve the Key Vault name from the foundation configuration
            self.kv_name = self.parameter_service.get_foundation_config_value(GC.KEYVAULT_NAME_KEY)
            self._initialize_paths()
        except Exception as e:
            self._logger.error(f"{ELC.AI_ENRICHMENT_ENRICHMENT_SERVICE_INIT_ERROR}: {e}")
            raise

    def execute(self, enrichment_id: str) -> None:
        """
        Executes the enrichment process for a given enrichment ID.

        Args:
            enrichment_id (str): The ID of the enrichment process to execute.

        Raises:
            Exception: If any error occurs during the enrichment process, it is logged and re-raised.
        """
        try:
            telemetry_reporter.report_usage(
                feature_name=GC.LIBRARY_USAGE_FEATURE_NAME,
                activity_name=EC.AI_ENRICHMENT_EXECUTION_ACTIVITY_NAME,
            )
            
            self._logger.info(f"{ELC.AI_ENRICHMENT_ENRICHMENT_SERVICE_START}: {enrichment_id}")

            self.enrichment_definition_id = enrichment_id
            self.enrichment_generation_id=str(uuid.uuid4())

            input_records = self._retrieve_input_records(enrichment_id)
            
            if len(input_records) == 0:
                self._logger.warning(ELC.AI_ENRICHMENT_MODEL_VIEW_QUERY_EMPTY_INFO.format(enrichment_id=enrichment_id))
                return
            
            input_records_to_process = input_records[:self.enrichment_records_limit] if self.enrichment_records_limit > 0 else input_records

            self._logger.info(f"{ELC.AI_ENRICHMENT_EXECUTE_STARTED_INFO.format(inputs_count=len(input_records_to_process),generation_id= self.enrichment_generation_id)}")
            
            enrichment_results = self._perform_model_execution_and_transformation(input_records_to_process)

            self._save(self.enrichment_generation_id, enrichment_results)

            generated_enrichment_info = GeneratedEnrichment(
                id= self.enrichment_generation_id,
                materialize_view_id=self.materialized_id,
                input_name=self.input_table_name,
                name=f"Generated enrichment for {enrichment_id}"
            )

            self.enrichment_metadata_service.create_generated_enrichment(generated_enrichment_info)
            
            self._logger.info(f"{ELC.AI_ENRICHMENT_ENRICHMENT_SERVICE_SUCCESS}: {enrichment_id}")
        except Exception as e:
            raise ExecutionServiceError(f"{ELC.AI_ENRICHMENT_ENRICHMENT_EXECUTION_ERROR}: {e}") from e
    
    
    def _initialize_paths(self) -> None:
        """
        Initialize file and storage paths for the enrichment process.
        """
        self.files_path = FolderPath.get_fabric_files_path(
            workspace_name=self.workspace_name,
            one_lake_endpoint=self.one_lake_endpoint,
            lakehouse_name=self.landing_zone_lakehouse_id,
        )
        
        ai_enrichment_landing_zone_path = self.parameter_service.get_activity_config_value(
                    EC.DEFAULT_AI_ENRICHMENT_LANDING_ZONE_PATH_KEY,
                    EC.ENRICHMENT_LANDING_ZONE_PATH)
        
        self.storage_path= f"{self.files_path}/{ai_enrichment_landing_zone_path}"  
        
        self.source_lakehouse_name=self.mssparkutils_client.get_lakehouse(self.silver_lakehouse_id).get("displayName")
        
    
    def _retrieve_input_records(self, enrichment_id: str) -> List[EnrichmentContext]:
        """
        Get the input data for the enrichment process.

        Args:
            enrichment_id (str): The ID of the enrichment process.

        Returns:
            List[EnrichmentContext]: The list of prepared enrichment contexts.

        Raises:
            Exception: If any error occurs during the preparation of enrichment inputs.
        """
        try:
            enrichment_input_contexts = []
            content_records = self._run_enrichment_definition(enrichment_id)
            if len(content_records)>0:
                input_mapping = self.enrichment_definition.input_mapping
                
                AIEnrichmentsUtils.validate_input_mapping(input_mapping, enrichment_id)
                
                metadata_columns = json.loads(input_mapping.metadata)
                
                patient_id = input_mapping.patient_id

                for record in content_records:
                    enrichment_input_context = self._contextualize_record_for_enrichment(record, self.model_config, metadata_columns, patient_id, input_mapping)
                    if enrichment_input_context:
                        enrichment_input_contexts.append(enrichment_input_context)
                
                enrichment_context_ids=[context.enrichment_context_id for context in enrichment_input_contexts]
                
                active_enrichment_contexts = self.enrichment_metadata_service.get_active_context_ids(enrichment_context_ids)
                
                if active_enrichment_contexts:
                    enrichment_input_contexts = [context for context in enrichment_input_contexts if context.enrichment_context_id not in active_enrichment_contexts]
                
            return enrichment_input_contexts    
        except Exception:
            raise 
        
    def _run_enrichment_definition(self, enrichment_id: str) -> List[Dict[str, Any]]:
        """
        Executes the enrichment definition to fetch the records from the given view ID and respective SQL query expression
        Args:
            enrichment_id (str): The ID of the enrichment process.

        Returns:
            List[Dict[str, Any]]: The list of fetched records.

        """
        try:
            enrichment_info = self.enrichment_metadata_service.get_enrichment_info(enrichment_id)
            if not enrichment_info:
                raise ExecutionServiceError(EC.ENRICHMENT_DEFINITION_NOT_FOUND.format(enrichment_id=enrichment_id))

            self.enrichment_definition = enrichment_info.definition
            
            self.enrichment_definition.model = json.loads(enrichment_info.definition.model)
            
            self._get_model_configuration(self.enrichment_definition.model)
            
            AIEnrichmentsUtils.validate_model_config(self.model_config)

            view_id = self.enrichment_definition.view_id
            if not view_id:
                raise ExecutionServiceError(EC.ENRICHMENT_VIEW_ID_NOT_FOUND.format(view_id=enrichment_id))

            enrichment_view_info = self.enrichment_metadata_service.get_enrichment_view_info(view_id)
            if not enrichment_view_info:
                raise ExecutionServiceError(EC.ENRICHMENT_VIEW_INFO_NOT_FOUND.format(view_id=view_id))

            sql_query = self._prepare_sql_query(enrichment_view_info)
            self._logger.info(sql_query)
            result_df = self.spark.sql(sql_query)
            row_result = [row.asDict() for row in result_df.collect()]
            if not row_result:
                self._logger.warning(EC.ENRICHMENT_VIEW_QUERY_RESULT_EMPTY.format(enrichment_view_info_id=view_id))
            else:
                self._get_materialized_view_path(enrichment_view_info, result_df)
            return row_result
        except Exception:
            raise
    
    def _get_model_configuration(self, model_configuration: dict) -> None:
        """
        Get the model configuration from the enrichment definition.

        Args:
            model_configuration (dict): The model configuration.

        Raises:
            ModelConfigurationError: If the model configuration is not found or an unexpected error occurs.
        """
        if not model_configuration:
            raise ModelConfigurationError(EC.ENRICHMENT_MODEL_CONFIGURATION_INVALID)

        api_key_secret_identifier = model_configuration.get(EC.ENRICHMENT_API_SECRET_KEY_NAME)
        if api_key_secret_identifier:
            try:
                kv_uri = model_configuration.get(EC.ENRICHMENT_API_KV_KEY_NAME) or FolderPath.get_key_vault_uri(self.kv_name)
                api_key = self.mssparkutils_client.credentials_getSecret(kv_uri, api_key_secret_identifier)
                model_configuration["api_key"] = api_key
            except Exception as e:
                raise ModelConfigurationError(EC.ENRICHMENT_UNEXPECTED_ERROR.format(method="_get_model_configuration", error=e))  
        self.model_config = model_configuration
        
    def _perform_model_execution_and_transformation(self, enrichment_input_contexts_list: List[EnrichmentContext]) -> List[EnrichmentResult]:
        """
        Processes the enrichment input and returns the transformed enriched response.

        Args:
            enrichment_input_contexts_list (List[EnrichmentContext]): The list of input contexts for the enrichment process.

        Returns:
            List[EnrichmentResult]: The enriched response after processing.
        """
        try:
            # Execute the enrichment model processor to get the raw responses
            self._logger.info(f"{ELC.AI_ENRICHMENT_MODEL_PROCESS_EXECUTION_INFO.format(records_count=len(enrichment_input_contexts_list))}")
            
            raw_responses = self.enrichment_model_processor.process(self.enrichment_generation_id,self.model_config,enrichment_input_contexts_list,self.should_save_model_raw_response,self.storage_path)
            
            if len(raw_responses) == 0:
                 raise ExecutionServiceError(ELC.AI_ENRICHMENT_MODEL_PROCESS_EMPTY_RESPONSE_ERROR)
            
            # Transform the raw responses to enriched responses
            self._logger.info(f"{ELC.AI_ENRICHMENT_TRANSFORMER_PROCESS_STARTED_INFO}")
            transformed_responses: List[EnrichmentResult] =self.enrichment_transformer.transform(
                self.enrichment_generation_id,enrichment_input_contexts_list, raw_responses
            )
            
            #loop through the transformed responses and update enrichment definition id
            for response in transformed_responses:
                response.enrichment_definition_id= self.enrichment_definition_id
                
            self._logger.info(f"{ELC.AI_ENRICHMENT_PROCESS_TRANSFORMATION_COMPLETED_INFO.format(inputs_count=len(raw_responses),processed_count=len(transformed_responses))}")
            return transformed_responses
    
        except Exception:
            raise
    
    def _prepare_sql_query(self, enrichment_view_info: EnrichmentView) -> str:
        """
        Prepares the SQL query for fetching enrichment data.

        Args:
            enrichment_view_info (EnrichmentView): The enrichment view information.

        Returns:
            str: The prepared SQL query.

        Raises:
            Exception: If any error occurs during the preparation of the SQL query.
        """
        try:
            enrichment_view_definition = enrichment_view_info.definition
            sql_query = AIEnrichmentsUtils.extract_sql_query(enrichment_view_info, enrichment_view_definition)
            parent_ids = enrichment_view_definition.parent_views_ids

            if not AIEnrichmentsUtils.validate_views_in_sql_expression(sql_query, len(parent_ids)):
                raise ExecutionServiceError(EC.ENRICHMENT_SQL_QUERY_INVALID.format(enrichment_view_info_id=enrichment_view_info.id))

            references_paths = self._get_or_create_references_paths(parent_ids)
            return AIEnrichmentsUtils.replace_materialized_view_names(self.spark,sql_query, references_paths)

        except Exception:
            raise
        
    def _contextualize_record_for_enrichment(self, record: Dict[str, Any],model_configuration:dict, metadata_columns: Dict[str, str], patient_id: str, input_mapping: EnrichmentInputMapping) -> Optional[EnrichmentContext]:
        """
        Transforms record data into an EnrichmentContext object.

        Args:
            record (Dict[str, Any]): The record data.
            model_configuration (dict): The model configuration.
            metadata_columns (Dict[str, str]): The metadata columns.
            patient_id (str): The patient ID.
            input_mapping (EnrichmentInputMapping): The input mapping.

        Returns:
            Optional[EnrichmentContext]: The created EnrichmentContext object, or None if no valid context is created.
        """
        meta_data = {key: record.get(column_name) for key, column_name in metadata_columns.items()}
        text_resource_references_data = [
            ResourceReference(
                id=record.get(ref.id),
                content=record.get(ref.content)
            )
            for ref in input_mapping.text_resource_references
            if record.get(ref.content)
        ]
        image_resource_references_data = [
            ResourceReference(
                id=record.get(ref.id),
                content=record.get(ref.content)
            )
            for ref in input_mapping.image_resource_references
            if record.get(ref.content)
        ]

        updated_model_configuration = self._remove_excluded_keys(model_configuration)
        
        if text_resource_references_data or image_resource_references_data:
            enrichment_input = EnrichmentInput(
                patient_id=record.get(patient_id),
                metadata=meta_data,
                text_file_references=text_resource_references_data,
                image_file_references=image_resource_references_data
            )
            context = AIEnrichmentsUtils.create_context_string(
                updated_model_configuration,
                enrichment_input
            )
            context_id=AIEnrichmentsUtils.get_hash_id(context)
            return EnrichmentContext(
                enrichment_context_id=context_id,
                enrichment_input=enrichment_input,
                model_configuration=updated_model_configuration
            )
        return None
    
    def _remove_excluded_keys(self, model_configuration: dict) -> dict:
        """
        Removes any keys that are listed in the exclusion configuration from the given model configuration.

        This function uses the comma-separated keys defined in the enrichment model configuration's
        exclusion settings and filters them out from the provided dictionary.

        Args:
            model_configuration (dict):
                The dictionary containing model configuration data.

        Returns:
            dict:
                A new dictionary with all excluded keys removed, preserving only the allowed keys.

        """
        exclude_keys = [key.strip() for key in self.enrichment_model_defintion_excluded_keys.split(',')]
        return {k: v for k, v in model_configuration.items() if k not in exclude_keys}
        
    def _get_or_create_references_paths(self, parent_ids: List[str]) -> List[str]:
        """
        Retrieves the reference table paths for the parent views.

        Args:
            parent_ids (List[str]): The list of parent view IDs.

        Returns:
            List[str]: The list of reference paths.

        Raises:
            Exception: If any error occurs during the retrieval of reference paths.
        """
        references_paths = {}
        view_definitions = {parent_id: self.enrichment_metadata_service.get_enrichment_view_info(parent_id) for parent_id in parent_ids}

        for view_definition in view_definitions.values():
            parent_view_definition = view_definition.definition
            parent_view_ids = parent_view_definition.parent_views_ids
            if not parent_view_ids:
                references_paths[view_definition.name] = self.source_lakehouse_name
            else:
                sql_query = AIEnrichmentsUtils.extract_sql_query(view_definition, parent_view_definition)
                parent_references_paths = self._get_or_create_references_paths(parent_view_ids)
                sql_query = AIEnrichmentsUtils.replace_materialized_view_names(self.spark,sql_query, parent_references_paths)
                result_df = self.spark.sql(sql_query)
                materialized_view_path = self._get_materialized_view_path(view_definition, result_df)
                references_paths[materialized_view_path] = None
        return references_paths
    
    def _get_materialized_view_path(self, enrichment_view_info: EnrichmentView, result_df) -> str:
        """
        Creates materialized records for the given enrichment ID and view information.

        Args:
            enrichment_view_info (EnrichmentView): The enrichment view information.
            result_df (DataFrame): The result DataFrame.

        Returns:
            str: The name of the input table.
        """
        input_table_name = f"{EC.ENRICHMENT_MATERIALIZED_FILE_PREFIX}-{uuid.uuid4().hex}"
        target_table_path = f"{FolderPath.get_fabric_files_path(self.workspace_name, self.one_lake_endpoint, self.metadata_lakehouse_id)}/{EC.ENRICHMENT_MATERIALIZED_VIEWS_PATH}/{input_table_name}"
        self._logger.info(f"Saving materialized view to {target_table_path}")
        result_df.write.format("delta").mode("overwrite").save(target_table_path)
        self.materialized_id = self.enrichment_metadata_service.create_materialized_view(enrichment_view_info, target_table_path)
        self.input_table_name = input_table_name
        return target_table_path


    def _save(self, enrichment_generation_id: str, enrichment_results: List[EnrichmentResult]) -> None:
        """
        Save the enrichment results to the storage path in batches.

        Args:
            enrichment_generation_id (str): The ID of the enrichment generation.
            enrichment_results (List[EnrichmentResult]): The list of enrichment results to save.
        """
        os.makedirs(self.storage_path, exist_ok=True)
        unique_output_types = {output.type.lower() for result in enrichment_results for output in result.outputs}

        def process_output_type(output_type: str) -> None:
            try:
                self._logger.info(f"Processing output type: {output_type}")
                batch_size = self.enrichment_output_records_limit_per_file
                output_type_path = os.path.join(self.storage_path, output_type.capitalize(),EC.ENRICHMENT_LANDING_ZONE_DIR)
                os.makedirs(output_type_path, exist_ok=True)
                results_by_output_type = [
                    result.model_copy(update={"outputs": [output for output in result.outputs if output.type.lower() == output_type]})
                    for result in enrichment_results if any(output.type.lower() == output_type for output in result.outputs)
                ]
                self.process_results(results_by_output_type, batch_size, output_type_path, enrichment_generation_id)
            except Exception as e:
                self._logger.error(EC.ENRICHMENT_UNEXPECTED_ERROR.format(method="save", error=e))

        with ThreadPoolExecutor(max_workers=self.execution_threads) as executor:
            executor.map(process_output_type, unique_output_types)
            

    def process_results(self, results_by_output_type, batch_size, output_type_path, enrichment_generation_id):
        """
        Process and save the results in batches.

        Args:
            results_by_output_type (list): List of results categorized by output type.
            batch_size (int): The size of each batch to be processed.
            output_type_path (str): The path where the output files should be saved.
            enrichment_generation_id (str): The ID for the enrichment generation.

        Returns:
            None
        """
        is_json = self.output_format == "json"
        for batch_number, i in enumerate(range(0, len(results_by_output_type), batch_size), start=1):
            batch_results = results_by_output_type[i:i + batch_size]
            self.save_batch_results(batch_results, batch_number, output_type_path, enrichment_generation_id, is_json)


    def save_batch_results(self, batch_results, batch_number, output_type_path, enrichment_generation_id, is_json):
            """
            Save the batch results to the specified output path.

            Args:
                batch_results (list): List of results to be saved.
                batch_number (int): The batch number for the current set of results.
                output_type_path (str): The path where the output files should be saved.
                enrichment_generation_id (str): The ID for the enrichment generation.
                is_json (bool): Flag indicating whether the output should be in JSON format.

            Returns:
                None
            """
            file_extension = "json" if is_json else GC.DEFAULT_FHIR_NDJSON_FILE_EXTENSION
            file_content = '\n'.join(json.dumps(result.model_dump(), separators=(',', ':')) for result in batch_results)
        
            if is_json:
                for line in file_content.splitlines():
                    if line:
                        final_output_path = os.path.join(output_type_path, f"{enrichment_generation_id}_{uuid.uuid4()}.json")
                        self.mssparkutils_client.fs_put(final_output_path, line, overwrite=True)
            else:
                final_output_path = os.path.join(output_type_path, f"{enrichment_generation_id}_batch{batch_number}.{file_extension}")
                self.mssparkutils_client.fs_put(final_output_path, file_content, overwrite=True)
        
            self._logger.info(f"{EC.ENRICHMENT_OUTPUT_SAVE_INFO.format(batch_number=batch_number, final_output_path=final_output_path)}")