# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
from typing import Callable
from pyspark.sql import SparkSession
from microsoft.fabric.hls.hds.nlp.constants import NLPConstants as NC
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.nlp.nlp_manager import NLPManager
from microsoft.fabric.hls.hds.utils.utils import FolderPath, Utils
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import MSSparkUtilsClientBase
from microsoft.fabric.hls.hds.services.base_runnable_service import BaseRunnableService
from microsoft.fabric.hls.hds.data_models.execution_metadata import ExecutionMetadata, ExecutionDataType

class NLPIngestionService(BaseRunnableService):

    def __init__(
        self,
        spark: SparkSession,
        workspace_name: str,
        solution_name: str,
        admin_lakehouse_name: str,
        inline_params: dict = None,
        one_lake_endpoint: str = GC.DEFAULT_ONE_LAKE_ENDPOINT,
        mssparkutils_client: MSSparkUtilsClientBase = None,
        ):
        """
        Initialize the NLPIngestionService which transforms a given table in the lakehouse and uses the Microsoft Text Analytics for Health
        to extract and label relevant medical information from unstructured texts

        Args:
            - spark (SparkSession): The SparkSession object.
            - workspace_name (str): The name of the fabric Workspace
            - solution_name: Name of the HDS-Healthcare data solutions OneLake workload solution
            - admin_lakehouse_name (str): The lakehouse name of where the administration configurations are located
            - inline_params (dict): Inline parameters that will overwrite and take precedence over the parameters in the administration lakehouse configuration
            - one_lake_endpoint (str): The one lake endpoint. Default is `onelake.dfs.fabric.microsoft.com`
            - mssparksutils_client (MSSparkUtilsClientBase): The mssparkutils client
        """
        super().__init__(spark=spark,
                         workspace_name=workspace_name,
                         solution_name=solution_name,
                         admin_lakehouse_name=admin_lakehouse_name,
                         inline_params=inline_params,
                         one_lake_endpoint=one_lake_endpoint,
                         mssparkutils_client=mssparkutils_client)

        
    def _setup(self) -> None:
        """
        Setup method for the SilverIngestionService
        """
        try:
            self.language_service_token = ""
            self.nlp_api_endpoint = ""

            self.config_files_root_path = FolderPath.get_fabric_workload_files_root_path(
                workspace_name=self.workspace_name,
                one_lake_endpoint=self.one_lake_endpoint,
                solution_name=self.solution_name
            )
            
            self.target_lakehouse_name = self.parameter_service.get_foundation_config_value(GC.SILVER_LAKEHOUSE_ID_KEY)
            self.enable_text_analytics_logs = self.parameter_service.get_activity_config_value(GC.ENABLE_TEXT_ANALYTICS_LOGS_KEY, GC.ENABLE_TEXT_ANALYTICS_LOGS, "bool")
            self.nlp_config_name = self.parameter_service.get_activity_config_value(GC.NLP_CONFIG_FILE_NAME_KEY, GC.NLP_CONFIG_NAME)
            self.nlp_source_table_name = self.parameter_service.get_activity_config_value(GC.NLP_SOURCE_TABLE_NAME_KEY, GC.DOCUMENT_REFERENCE_CONTENT_RESOURCE)
            self.nlp_document_limit = self.parameter_service.get_activity_config_value(GC.NLP_DOCUMENT_LIMIT_KEY, GC.DOCUMENT_LIMIT, "int")
            self.tables_path = self.parameter_service.get_activity_config_value(
                GC.TABLES_PATH_KEY,
                FolderPath.get_fabric_tables_path(
                    workspace_name=self.workspace_name,
                    one_lake_endpoint=self.one_lake_endpoint,
                    lakehouse_name=self.target_lakehouse_name
                )
            )
            self.nlp_config_dir = self.parameter_service.get_activity_config_value(
                GC.NLP_CONFIG_DIR_KEY,
                FolderPath.get_fabric_workload_files_nlp_config_root_folder_path(root_path=self.config_files_root_path)
            )
            
            # get secret from keyvault
            self.nlp_api_endpoint = Utils.get_key_vault_secret(
                spark=self.spark,
                kv_secret_name=GC.NLP_API_ENDPOINT_SECRET_NAME,
                mssparkutils_client=self.mssparkutils_client,
            )
            self.language_service_token = Utils.get_key_vault_secret(
                spark=self.spark,
                kv_secret_name=GC.NLP_SECRET_NAME,
                mssparkutils_client=self.mssparkutils_client,
            )

            # Validate the config exists
            self.mssparkutils_client.fs_exists(file_url=f"{self.nlp_config_dir}/{self.nlp_config_name}")

            Utils.validate_required_parameters({
                'spark': self.spark,
                'admin_lakehouse_name': self.admin_lakehouse_name,
                'workspace_name': self.workspace_name,
                'solution_name': self.solution_name,
            })
            
        except Exception as ex:
            self._logger.error(message=str(ex))
            raise
        
    def _setup_execution_metadata(self) -> ExecutionMetadata:
        lakehouse_properties = self.mssparkutils_client.get_lakehouse(self.target_lakehouse_name) # The source and target lakehouse are the same NLP service
        return ExecutionMetadata(
            sourceType=ExecutionDataType.deltaTable,
            sourcePath=self.tables_path,
            sourceLakehouseIdentifier=lakehouse_properties.get("id"),
            sourceLakehouseName=lakehouse_properties.get("displayName"),
            targetType=ExecutionDataType.deltaTable,
            targetPath=self.tables_path,
            targetLakehouseIdentifier=lakehouse_properties.get("id"),
            targetLakehouseName=lakehouse_properties.get("displayName"),
        )

    def _get_internal_activity_name(self) -> str:
        return GC.NLP_ENRICHMENT_ACTIVITY_NAME
    
    def _execute(self, **kwargs) -> None:
        """
        Executes the NLPIngestionService by calling the Text Analytics for Health API on the input/source data   
        
        Keyword Args:
            transformation_fn (Callable, optional): The transformation function to be executed on the input data. Defaults to None.
        """
        self.run_nlp_transformation()

    def run_nlp_transformation(self) -> dict:
        """
        Run the NLP pipeline.

        Returns:
            dict: The NLP pipeline status.
        """
        Utils.validate_required_parameters({
            'nlp_api_endpoint': self.nlp_api_endpoint,
            'language_service_token': self.language_service_token,
        })
        
        nlp_manager = NLPManager(self.spark,
                                solution_name=self.solution_name,
                                workspace_name=self.workspace_name,
                                nlp_api_endpoint=self.nlp_api_endpoint,
                                nlp_credentials=self.language_service_token,
                                flatten_config_dir=self.nlp_config_dir,
                                flatten_config_name=self.nlp_config_name,
                                silver_database_path=self.tables_path,
                                nlp_columns_mapping=GC.NLP_COLUMNS_MAPPING,
                                enable_text_analytics_logs=self.enable_text_analytics_logs)

        nlp_manager.run_nlp_pipeline(
            table_name=self.nlp_source_table_name,
            document_limit=self.nlp_document_limit,
            collect_metrics_fn=self.collect_target_delta_table_operation_summary_metrics,
            collect_source_metrics_fn=self.collect_source_metrics_fn
        )
    
    def collect_source_metrics_fn(self, metrics: dict) -> None:
        """
        Collects the source data summary metrics.

        Args:
            metrics (dict): The metrics to be collected.
        """
        self.execution_metrics_collector.accumulate(
            accumulator_activity_id=self.get_execution_metrics_accumulator_activity_id(), 
            metrics=metrics
        )
