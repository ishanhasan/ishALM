# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------

class DaxModelExecutionConfig:
    """
    A class for the DAX model execution configuration.
    """
    def __init__(self, use_case_name: str | None, openai_model: dict | None, table_schema: str | None, dax_input: str | None, multiple_records_for_array: bool = False):
        """
        Initializes the DaxModelExecutionConfig class.

        Args:
            use_case_name (str): The name of the use case.
            openai_model (dict): The OpenAI model configuration.
            table_schema (str): The file path to the schema file for the use case.
            dax_input (str, optional): The type of input for DAX (text or transcript). Defaults to 'text'.
            multiple_records_for_array (bool, optional): Whether the use case expects multiple records in an array format. Defaults to False.
        """
        self.use_case_name = use_case_name
        self.openai_model = openai_model
        self.table_schema = table_schema
        self.dax_input = dax_input
        self.multiple_records_for_array = multiple_records_for_array

    @staticmethod
    def from_json(json_data: dict) -> 'DaxModelExecutionConfig':
        """
        Create a DaxModelExecutionConfig object from a JSON dictionary.

        Args:
            json_data (dict): The JSON data representing the use case configuration.

        Returns:
            DaxModelExecutionConfig: An instance of the configuration class.
        """
        return DaxModelExecutionConfig(
            use_case_name=json_data.get("use_case_name"),
            openai_model=json_data.get("openai_model"),
            table_schema=json_data.get("table_schema"),
            dax_input=json_data.get("dax_input", "text"),
            multiple_records_for_array=json_data.get("multiple_records_for_array", False)
        )
    
    def get_model_name(self):
        return self.openai_model.get('configuration', {}).get('model_name')

    def get_schema_file_path(self, settings_file_dir: str) -> str:
        return os.path.join(settings_file_dir, self.table_schema)