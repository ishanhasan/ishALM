# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------

import re
import json
from typing import List, Type, TypeVar
import openai
from pydantic import BaseModel
from microsoft.fabric.hls.hds.ai_enrichments.core.base_classes.enrichment_model_client_base import EnrichmentModelClientBase
from microsoft.fabric.hls.hds.ai_enrichments.core.clients.models.enrichment_api_response import EnrichmentAPIResponse
from microsoft.fabric.hls.hds.ai_enrichments.core.errors.enrichment_value_error import EnrichmentValueError
from microsoft.fabric.hls.hds.ai_enrichments.core.errors.model_configuration_error import ModelConfigurationError
from microsoft.fabric.hls.hds.openai.constants import OpenAIConstants
from microsoft.fabric.hls.hds.openai.data_models.openai_model_response import OpenAIModelResponse
from microsoft.fabric.hls.hds.openai.data_models.openai_model_settings import OpenAIModelSettings
from microsoft.fabric.hls.hds.ai_enrichments.core.clients.openai_client.utils.openai_client_utils import OpenAIClientUtils as OpenAIUtils
from microsoft.fabric.hls.hds.ai_enrichments.core.constants.ai_enrichments_logging_constants import AIEnrichmentsLoggingConstants as ELC



T = TypeVar("T", bound=BaseModel)

class OpenAIClientOrchestrator(EnrichmentModelClientBase):
    """
    A class for interacting with the OpenAI API.
    """

    def create(self, **kwargs) -> None:
        """
        Initialize the OpenAIOrchestrator with the given configuration.

        Args:
            spark (SparkSession): The SparkSession object.
            open_ai_conn_config (OpenAIConnectionConfig): The configuration object containing the endpoint, API key, API version, model name, and other options.
            openai_settings (OpenAIModelSettings, optional): The OpenAIModelSettings object containing additional settings. Defaults to None.
        """
        self.openai_settings = kwargs.get("openai_settings") or OpenAIModelSettings()
        open_ai_conn_config = kwargs.get("open_ai_conn_config")
        system_message = kwargs.get("system_message")
        examples = kwargs.get("examples")
        self._initialize_chat_completion_params(open_ai_conn_config.model_name, open_ai_conn_config.open_ai_config_options)
        self.open_ai_conn_config = open_ai_conn_config
        self.openai_conn = openai.AzureOpenAI(
            azure_endpoint=open_ai_conn_config.azure_endpoint,
            api_key=open_ai_conn_config.api_key,
            api_version=open_ai_conn_config.api_version
        )
        if not self._validate_api_key():
            raise ModelConfigurationError(ELC.OPENAI_ENRICHMENT_INVALID_API_KEY)
        self.system_instructions = OpenAIUtils.create_system_instructions(system_message, examples)

    def execute(self, **kwargs) -> EnrichmentAPIResponse:
        """
        Execute the OpenAI client with the given parameters.

        Args:
            user_query (str): The user query.
            response_model (Type[T]): The response model to validate the response.

        Returns:
            EnrichmentAPIResponse: The response from the OpenAI API.
        """
        try:
            user_query = kwargs.get('user_query')
            response_model = kwargs.get('response_model')
            if not user_query or not response_model:
                raise EnrichmentValueError(ELC.AI_ENRICHMENT_CLIENT_EXECUTION_ERROR)
            response = self.parse_completion_json(
                user_query=user_query,
                response_model=response_model
            )
            return EnrichmentAPIResponse(data=response)
        except Exception as e:
            self._logger.error(f"Error executing request: {e}")
            return EnrichmentAPIResponse(error_message=str(e))

    def validate_openai_connection_config(self) -> bool:
        """
        Validate the OpenAI connection configuration.

        Returns:
            bool: True if the configuration is valid, False otherwise.
        """
        return OpenAIUtils.validate_open_ai_config(self.open_ai_conn_config)

    def _validate_api_key(self) -> bool:
        """
        Validate the API key by listing assistants.

        Returns:
            bool: True if the API key is valid, False otherwise.
        """
        try:
            self.list_assistants()
        except Exception as e:
            self._logger.error(e)
            return False
        return True

    def get_completion_text(self, user_query: str, user_input: str, output_format_as_json: bool = False, schema_format: dict = None) -> str:
        """
        Generate text using the given prompt and provided or default values.

        Args:
            user_query (str): User query to be used as a prompt.
            user_input (str): User additional input to be used as a prompt.
            output_format_as_json (bool, optional): If True, the output will be formatted as JSON.
            schema_format (dict, optional): Schema of the JSON output.

        Returns:
            str: Completion text generated by the OpenAI model based on the given prompt.
        """
        if "messages" not in self.chat_completion_params:
            return "Error: chat_completion_params['messages'] is not set."
        
        tools = []
        response_format = None
        
        if output_format_as_json:
            tools, response_format = OpenAIUtils.prepare_tools_and_format(output_format_as_json, schema_format)
        try:
            self.chat_completion_params['messages'] = OpenAIUtils.create_messages(user_query, list(self.system_instructions))
            if tools:
                self.chat_completion_params['tools'] = tools
            if response_format:
                self.chat_completion_params['response_format'] = response_format

            chat_completion = self.openai_conn.chat.completions.create(**self.chat_completion_params)
            result = OpenAIUtils.process_completion_message(chat_completion, OpenAIConstants.DEFAULT_OPEN_AI_TOOL_JSON)
        except Exception as error:
            result = f'Error generating text: {error}'
        return result

    def parse_completion_json(self, user_query: str, response_model: Type[T]) -> OpenAIModelResponse:
        """
        Parse the completion JSON using the given user query and response model.

        Args:
            user_query (str): The user query.
            response_model (Type[T]): The Pydantic model to be used for validation.

        Returns:
            OpenAIModelResponse: Completion text in JSON format validated by the given response model.
        """
        self.chat_completion_params["messages"] = OpenAIUtils.create_messages(user_query, list(self.system_instructions))
        self.chat_completion_params["response_format"] = response_model
        parsed_chat_completion = self.openai_conn.beta.chat.completions.parse(**self.chat_completion_params)
        total_tokens = parsed_chat_completion.usage.total_tokens
        self._logger.info(f"{ELC.OPENAI_DATA_ENRICHMENT_TOKENS_USAGE_INFO_MSG.format(token_count=total_tokens)}")
        completion_result = OpenAIUtils.process_completion_message(parsed_chat_completion)
        if completion_result is None:
            self._logger.warning(f"{ELC.OPENAI_DATA_OUTPUT_NONE_WARNING}")
        formatted_json = json.loads(completion_result)
        return formatted_json

    def list_assistants(self, order: str = "desc", limit: int = 20) -> List:
        """
        List all existing assistants.

        Args:
            order (str, optional): The order in which to list the assistants. Defaults to "desc".
            limit (int, optional): The maximum number of assistants to list. Defaults to 20.

        Returns:
            list: A list of existing assistants.
        """
        assistants = self.openai_conn.beta.assistants.list(
            order=order,
            limit=limit,
        )
        return assistants.data

    def create_new_assistant(self, assistant_name: str, system_instructions: str, model_name: str):
        """
        Create a new assistant with the given name, system instructions, and model name.

        Args:
            assistant_name (str): The name of the assistant.
            system_instructions (str): The system instruction message.
            model_name (str): The name of the model to be used.

        Returns:
            assistant: The newly created assistant object, or None if an error occurred.
        """
        try:
            assistant = self.openai_conn.beta.assistants.create(
                instructions=system_instructions,
                model=model_name,
                tools=[{"type": OpenAIConstants.ASSISTANT_TYPE}],
                name=assistant_name
            )
            return assistant
        except Exception as ex:
            self._logger.error(message=str(ex))
            raise ex

    def create_thread(self):
        """
        Creates a new thread.

        Returns:
            thread: The newly created thread object, or None if an error occurred.
        """
        try:
            thread = self.openai_conn.beta.threads.create()
            return thread
        except Exception as ex:
            self._logger.error(message=str(ex))
            return None

    def create_run(self, thread, assistant, data: str):
        """
        Runs the assistant with the provided data and returns the content text of the messages.

        Args:
            thread: The thread object.
            assistant: The assistant object.
            data (str): The input data for the assistant to process.

        Returns:
            str: The content text of the messages.
        """
        self.openai_conn.beta.threads.messages.create(
            thread_id=thread.id,
            role="user",
            content=data
        )
        assistant_run = self.openai_conn.beta.threads.runs.create(
            thread_id=thread.id,
            assistant_id=assistant.id
        )
        return assistant_run

    def list_thread_messages(self, thread):
        """
        Get the messages in the specified thread.

        Args:
            thread (Thread): The thread object.

        Returns:
            list: A list of messages in the thread.
        """
        try:
            messages = self.openai_conn.beta.threads.messages.list(
                thread_id=thread.id
            )
            return messages
        except Exception as ex:
            self._logger.error(message=str(ex))
            return None

    def _initialize_chat_completion_params(self, model_name: str, openai_config_options: dict):
        """
        Initialize the chat completion parameters with the given model name and configuration options.

        Args:
            model_name (str): The name of the model.
            openai_config_options (dict): The configuration options for the OpenAI model.
        """
        openai_config_attributes = openai_config_options or {}
        openai_settings = {**vars(self.openai_settings), **openai_config_attributes}
        self.chat_completion_params = {
            "model": model_name,
            "temperature": openai_settings.get("temperature"),
            "top_p": openai_settings.get("top_p"),
            "frequency_penalty": openai_settings.get("frequency_penalty"),
            "presence_penalty": openai_settings.get("presence_penalty"),
            "stop": openai_settings.get("stop"),
            "response_format": openai_settings.get("response_format")
        }

    def _extract_error_info(self, error_text: str):
        """
        Extracts the error code and recommended wait time from the provided error text.

        Args:
            error_text (str): The full error message that may contain the error code and wait time.

        Returns:
            tuple: 
                - str: The extracted error code or None if not found.
                - int: The number of seconds to wait before retrying or None if not found.
        """
        try:
            error_code_pattern = r"Error code: (\d+)"
            retry_seconds_pattern = r"retry after (\d+) seconds"

            def _search_pattern(pattern):
                match = re.search(pattern, error_text)
                return match.group(1) if match else None

            error_code_match = _search_pattern(error_code_pattern)
            retry_seconds_match = _search_pattern(retry_seconds_pattern)
            retry_seconds = int(retry_seconds_match) if retry_seconds_match else 0
            return error_code_match, retry_seconds
        except Exception as e:
            self._logger.error(f"Error extracting error info: {e}")
            return None, None
